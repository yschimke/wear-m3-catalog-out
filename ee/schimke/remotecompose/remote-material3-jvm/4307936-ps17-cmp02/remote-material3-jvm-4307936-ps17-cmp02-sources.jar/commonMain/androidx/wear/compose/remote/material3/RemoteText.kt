/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.wear.compose.remote.material3

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.compose.layout.RemoteComposable
import androidx.compose.remote.creation.compose.modifier.RemoteModifier
import androidx.compose.remote.creation.compose.state.RemoteColor
import androidx.compose.remote.creation.compose.state.RemoteString
import androidx.compose.remote.creation.compose.state.RemoteTextUnit
import androidx.compose.remote.creation.compose.text.RemoteFontFamily
import androidx.compose.remote.creation.compose.text.RemoteTextStyle
import androidx.compose.remote.foundation.text.RemoteBasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.wear.compose.material3.LocalTextConfiguration

/**
 * High level element that displays text and provides semantics / accessibility information.
 *
 * For ease of use, commonly used parameters from [androidx.compose.ui.text.TextStyle] are also
 * present here. The order of precedence is as follows:
 * - If a parameter is explicitly set here (i.e, it is _not_ `null` or
 *   [androidx.compose.ui.unit.TextUnit.Unspecified]), then this parameter will always be used.
 * - If a parameter is _not_ set, (`null` or [androidx.compose.ui.unit.TextUnit.Unspecified]), then
 *   the corresponding value from [style] will be used instead.
 *
 * @param text The text to be displayed.
 * @param modifier [Modifier] to apply to this layout node.
 * @param color [Color] to apply to the text.
 * @param fontSize The size of glyphs to use when painting the text. See
 *   [androidx.compose.ui.text.TextStyle.fontSize].
 * @param fontStyle The typeface variant to use when drawing the letters (e.g., italic). See
 *   [androidx.compose.ui.text.TextStyle.fontStyle].
 * @param fontWeight The typeface thickness to use when painting the text (e.g., [FontWeight.Bold]).
 * @param fontFamily The font family to be used when rendering the text. See
 *   [androidx.compose.ui.text.TextStyle.fontFamily].
 * @param textAlign The alignment of the text within the lines of the paragraph. See
 *   [androidx.compose.ui.text.TextStyle.textAlign].
 * @param overflow How visual overflow should be handled.
 * @param maxLines An optional maximum number of lines for the text to span.
 * @param style Style configuration for the text such as color, font, line height etc.
 * @param fontVariationSettings The font variation settings to be applied to the text.
 */
@Composable
@RemoteComposable
public fun RemoteText(
    text: RemoteString,
    modifier: RemoteModifier = RemoteModifier,
    color: RemoteColor? = null,
    fontSize: RemoteTextUnit? = null,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: RemoteFontFamily? = null,
    textAlign: TextAlign? = LocalTextConfiguration.current.textAlign,
    overflow: TextOverflow = LocalTextConfiguration.current.overflow,
    maxLines: Int = LocalTextConfiguration.current.maxLines,
    style: RemoteTextStyle = LocalRemoteTextStyle.current,
    fontVariationSettings: FontVariation.Settings? = null,
) {
    val color = color ?: style.color ?: LocalRemoteContentColor.current
    RemoteBasicText(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        textAlign = textAlign,
        overflow = overflow,
        maxLines = maxLines,
        style = style,
        fontVariationSettings = fontVariationSettings,
    )
}

/**
 * CompositionLocal containing the preferred [RemoteTextStyle] that will be used by [RemoteText]
 * components by default. To set the value for this CompositionLocal, see [ProvideRemoteTextStyle]
 * which will merge any missing [RemoteTextStyle] properties with the existing [RemoteTextStyle] set
 * in this CompositionLocal.
 *
 * @see ProvideRemoteTextStyle
 */
public val LocalRemoteTextStyle: ProvidableCompositionLocal<RemoteTextStyle> =
    staticCompositionLocalOf {
        RemoteTextStyle()
    }
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP) get

/**
 * This function is used to set the current value of [LocalRemoteTextStyle], merging the given style
 * with the current style values for any missing attributes. Any [RemoteText] components included in
 * this component's [content] will be styled with this style unless styled explicitly.
 *
 * @see LocalRemoteTextStyle
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@Composable
public fun ProvideRemoteTextStyle(
    value: RemoteTextStyle,
    content: @RemoteComposable @Composable () -> Unit,
) {
    val mergedStyle = LocalRemoteTextStyle.current.merge(value)
    CompositionLocalProvider(LocalRemoteTextStyle provides mergedStyle, content = content)
}
