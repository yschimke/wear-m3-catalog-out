/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT_ARRAY;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Limits;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.operations.layout.Container;
import androidx.compose.remote.core.operations.loom.LoomWireBuffer;
import androidx.compose.remote.core.operations.utilities.AnimatedFloatExpression;
import androidx.compose.remote.core.operations.utilities.CollectionsAccess;
import androidx.compose.remote.core.operations.utilities.NanMap;
import androidx.compose.remote.core.serialize.MapSerializer;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * This provides the mechanism to evolve the particles It consist of a restart equation and a list
 * of equations particle restarts if restart equation > 0
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ParticlesLoop extends PaintOperation implements VariableSupport, Container {
    private static final int OP_CODE = Operations.PARTICLE_LOOP;
    private static final String CLASS_NAME = "ParticlesLoop";
    private int mId;
    private final float[] mRestart;
    private final float[] mOutRestart;
    private final float[][] mEquations;
    private final float[][] mOutEquations;
    private int[] mVarId;
    private float[][] mParticles;
    ParticlesCreate mParticlesSource;

    @NonNull
    @Override
    public ArrayList<Operation> getList() {
        return mList;
    }

    @NonNull private final ArrayList<Operation> mList = new ArrayList<>();

    @NonNull AnimatedFloatExpression mExp = new AnimatedFloatExpression();

    /**
     * Create a new ParticlesLoop operation
     *
     * @param id of the create
     * @param restart the restart equation kills and restart when positive
     * @param values the loop equations
     */
    public ParticlesLoop(int id, float @Nullable [] restart, float @NonNull [][] values) {
        mId = id;
        mRestart = restart;
        if (restart != null) {
            mOutRestart = new float[restart.length];
            System.arraycopy(restart, 0, mOutRestart, 0, restart.length);
        } else {
            mOutRestart = null;
        }

        mEquations = values;
        mOutEquations = new float[values.length][];
        for (int i = 0; i < values.length; i++) {
            mOutEquations[i] = new float[values[i].length];
            System.arraycopy(values[i], 0, mOutEquations[i], 0, values[i].length);
        }
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        if (mOutRestart != null) {
            for (int i = 0; i < mRestart.length; i++) {
                float v = mRestart[i];
                mOutRestart[i] =
                        (Float.isNaN(v)
                                        && !AnimatedFloatExpression.isMathOperator(v)
                                        && !NanMap.isDataVariable(v))
                                ? context.getFloat(Utils.idFromNan(v))
                                : v;
            }
        }
        for (int i = 0; i < mEquations.length; i++) {
            float[] mEquation = mEquations[i];
            for (int j = 0; j < mEquation.length; j++) {
                float v = mEquation[j];
                mOutEquations[i][j] =
                        (Float.isNaN(v)
                                        && !AnimatedFloatExpression.isMathOperator(v)
                                        && !NanMap.isDataVariable(v))
                                ? context.getFloat(Utils.idFromNan(v))
                                : v;
            }
        }
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        mParticlesSource = (ParticlesCreate) context.getObject(mId);
        if (mParticlesSource != null) {
            mParticles = mParticlesSource.getParticles();
            mVarId = mParticlesSource.getVariableIds();
        }
        if (mRestart != null) {
            for (int i = 0; i < mRestart.length; i++) {
                float v = mRestart[i];
                if (Float.isNaN(v)
                        && !AnimatedFloatExpression.isMathOperator(v)
                        && !NanMap.isDataVariable(v)) {
                    context.listensTo(Utils.idFromNan(v), this);
                }
            }
        }
        for (int i = 0; i < mEquations.length; i++) {
            float[] mEquation = mEquations[i];
            for (float v : mEquation) {
                if (Float.isNaN(v)
                        && !AnimatedFloatExpression.isMathOperator(v)
                        && !NanMap.isDataVariable(v)) {
                    context.listensTo(Utils.idFromNan(v), this);
                }
            }
        }
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mId, mRestart, mEquations);
    }

    @NonNull
    @Override
    public String toString() {
        return "ParticlesLoop[" + Utils.idString(mId) + "] ";
    }

    /**
     * Write the operation on the buffer
     *
     * @param buffer the buffer to write to
     * @param id the id of the particle system
     * @param restart the restart equation
     * @param equations the equations to evolve the particles
     */
    public static void apply(
            @NonNull WireBuffer buffer,
            int id,
            float @Nullable [] restart,
            float @NonNull [][] equations) {
        buffer.start(OP_CODE);
        buffer.writeInt(id);
        if (restart != null) {
            buffer.writeInt(restart.length);
            for (int i = 0; i < restart.length; i++) {
                buffer.writeFloat(restart[i]);
            }
        } else {
            buffer.writeInt(0);
        }
        buffer.writeInt(equations.length);
        for (int i = 0; i < equations.length; i++) {
            buffer.writeInt(equations[i].length);
            for (int j = 0; j < equations[i].length; j++) {
                buffer.writeFloat(equations[i][j]);
            }
        }
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to mapping context for remapping
     *     IDs
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.readId();
        int restartLen = buffer.readInt();
        float[] restart = null;
        if (restartLen > 0) {
            if (restartLen > Limits.MAX_EXPRESSION_SIZE) {
                throw new RuntimeException(
                        restartLen + " map entries more than max = " + Limits.MAX_EXPRESSION_SIZE);
            }
            restart = new float[restartLen];
            for (int i = 0; i < restartLen; i++) {
                float v = buffer.readFloat();
                if (Float.isNaN(v)
                        && !AnimatedFloatExpression.isMathOperator(v)
                        && !NanMap.isDataVariable(v)) {
                    // Manual remapping since we already read it
                    if (buffer instanceof LoomWireBuffer) {
                        restart[i] = ((LoomWireBuffer) buffer).getRemapContext().resolveNanId(v);
                    } else {
                        restart[i] = v;
                    }
                } else {
                    restart[i] = v;
                }
            }
        }

        int varLen = buffer.readInt();
        if (varLen > Limits.MAX_PARTICLE_FLOAT_ARRAY_SIZE) {
            throw new RuntimeException(
                    varLen
                            + " map entries more than max = "
                            + Limits.MAX_PARTICLE_FLOAT_ARRAY_SIZE);
        }

        float[][] equations = new float[varLen][];
        for (int i = 0; i < varLen; i++) {

            int equLen = buffer.readInt();
            if (equLen > Limits.MAX_EXPRESSION_SIZE) {
                throw new RuntimeException(
                        equLen + " map entries more than max = " + Limits.MAX_EXPRESSION_SIZE);
            }
            equations[i] = new float[equLen];
            for (int j = 0; j < equations[i].length; j++) {
                float v = buffer.readFloat();
                if (Float.isNaN(v)
                        && !AnimatedFloatExpression.isMathOperator(v)
                        && !NanMap.isDataVariable(v)) {
                    // Manual remapping since we already read it
                    if (buffer instanceof LoomWireBuffer) {
                        equations[i][j] =
                                ((LoomWireBuffer) buffer).getRemapContext().resolveNanId(v);
                    } else {
                        equations[i][j] = v;
                    }
                } else {
                    equations[i][j] = v;
                }
            }
        }
        ParticlesLoop data = new ParticlesLoop(id, restart, equations);
        operations.add(data);
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Animation & Particles Operations", OP_CODE, CLASS_NAME)
                .description("Update and recycle particles in a system")
                .field(DocumentedOperation.INT, "id", "The ID of the particle system")
                .field(
                        INT,
                        "restartLen",
                        "The length of the restart equation (recycles particle if > 0)")
                .field(FLOAT_ARRAY, "restartEquation", "The restart equation (RPN)")
                .field(INT, "varCount", "The number of update equations")
                .field(INT, "equLen[0..n]", "The length of each update equation")
                .field(FLOAT_ARRAY, "equations[0..n]", "The update equations (RPN)");
    }

    @Override
    public void paint(@NonNull PaintContext context) {
        RemoteContext remoteContext = context.getContext();
        CollectionsAccess ca = Objects.requireNonNull(remoteContext.getCollectionsAccess());

        for (int i = 0; i < mParticles.length; i++) {
            // Save the values to context TODO hand code the update
            for (int j = 0; j < mParticles[i].length; j++) {
                remoteContext.loadFloat(mVarId[j], mParticles[i][j]);
                updateVariables(remoteContext);
            }
            // Evaluate the update function
            for (int j = 0; j < mParticles[i].length; j++) {
                mParticles[i][j] = mExp.eval(ca, mOutEquations[j], mOutEquations[j].length);
                remoteContext.loadFloat(mVarId[j], mParticles[i][j]);
            }
            // test for reset
            if (mOutRestart != null) {
                for (int k = 0; k < mRestart.length; k++) {
                    float v = mRestart[k];
                    mOutRestart[k] =
                            (Float.isNaN(v)
                                            && !AnimatedFloatExpression.isMathOperator(v)
                                            && !NanMap.isDataVariable(v))
                                    ? remoteContext.getFloat(Utils.idFromNan(v))
                                    : v;
                }
                if (mExp.eval(ca, mOutRestart, mOutRestart.length) > 0) {
                    mParticlesSource.initializeParticle(i);
                }
            }

            for (Operation op : mList) {
                if (op instanceof VariableSupport) {
                    ((VariableSupport) op).updateVariables(context.getContext());
                }

                remoteContext.incrementOpCount();
                op.apply(context.getContext());
            }
        }
        context.needsRepaint();
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer.addType(CLASS_NAME).add("id", mId);
    }
}
