/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteComposeOperation;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.semantics.AccessibleComponent;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Add a click area to the document */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ClickArea extends Operation
        implements RemoteComposeOperation,
                AccessibleComponent,
                VariableSupport,
                VariableProvider,
                Serializable,
                ComponentData {
    private static final int OP_CODE = Operations.CLICK_AREA;
    private static final String CLASS_NAME = "ClickArea";
    int mId;
    int mContentDescription;
    float mLeft;
    float mTop;
    float mRight;
    float mBottom;
    float mOutLeft;
    float mOutTop;
    float mOutRight;
    float mOutBottom;
    int mMetadata;

    @Override
    public int getId() {
        return mId;
    }

    @Override
    public void setId(int id) {
        mId = id;
    }

    /**
     * Add a click area to the document
     *
     * @param id the id of the click area, which will be reported in the listener callback on the
     *     player
     * @param contentDescription the content description (used for accessibility, as a textId)
     * @param left left coordinate of the area bounds
     * @param top top coordinate of the area bounds
     * @param right right coordinate of the area bounds
     * @param bottom bottom coordinate of the area bounds
     * @param metadata associated metadata, user-provided (as a textId, pointing to a string)
     */
    public ClickArea(
            int id,
            int contentDescription,
            float left,
            float top,
            float right,
            float bottom,
            int metadata) {
        this.mId = id;
        this.mContentDescription = contentDescription;
        mOutLeft = mLeft = left;
        mOutTop = mTop = top;
        mOutRight = mRight = right;
        mOutBottom = mBottom = bottom;
        mMetadata = metadata;
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        if (Float.isNaN(mLeft)) {
            context.listensTo(Utils.idFromNan(mLeft), this);
        }
        if (Float.isNaN(mTop)) {
            context.listensTo(Utils.idFromNan(mTop), this);
        }
        if (Float.isNaN(mRight)) {
            context.listensTo(Utils.idFromNan(mRight), this);
        }
        if (Float.isNaN(mBottom)) {
            context.listensTo(Utils.idFromNan(mBottom), this);
        }
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        mOutLeft = Float.isNaN(mLeft) ? context.getFloat(Utils.idFromNan(mLeft)) : mLeft;
        mOutTop = Float.isNaN(mTop) ? context.getFloat(Utils.idFromNan(mTop)) : mTop;
        mRight = Float.isNaN(mRight) ? context.getFloat(Utils.idFromNan(mRight)) : mRight;
        mOutBottom = Float.isNaN(mBottom) ? context.getFloat(Utils.idFromNan(mBottom)) : mBottom;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mId, mContentDescription, mLeft, mTop, mRight, mBottom, mMetadata);
    }

    @NonNull
    @Override
    public String toString() {
        return "CLICK_AREA <"
                + mId
                + " <"
                + mContentDescription
                + "> "
                + "<"
                + mMetadata
                + ">+"
                + mLeft
                + " "
                + mTop
                + " "
                + mRight
                + " "
                + mBottom
                + "+"
                + " ("
                + (mRight - mLeft)
                + " x "
                + (mBottom - mTop)
                + " }";
    }

    @Override
    public void apply(@NonNull RemoteContext context) {
        context.addClickArea(
                mId, mContentDescription, mOutLeft, mOutTop, mOutRight, mOutBottom, mMetadata);
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    @Override
    public @NonNull Integer getContentDescriptionId() {
        return mContentDescription;
    }

    /**
     * @param buffer
     * @param id
     * @param contentDescription
     * @param left
     * @param top
     * @param right
     * @param bottom
     * @param metadata
     */
    public static void apply(
            @NonNull WireBuffer buffer,
            int id,
            int contentDescription,
            float left,
            float top,
            float right,
            float bottom,
            int metadata) {
        buffer.start(OP_CODE);
        buffer.writeInt(id);
        buffer.writeInt(contentDescription);
        buffer.writeFloat(left);
        buffer.writeFloat(top);
        buffer.writeFloat(right);
        buffer.writeFloat(bottom);
        buffer.writeInt(metadata);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.declareId();
        int contentDescription = buffer.readId();
        float left = buffer.readNanId();
        float top = buffer.readNanId();
        float right = buffer.readNanId();
        float bottom = buffer.readNanId();
        int metadata = buffer.readId();
        ClickArea clickArea =
                new ClickArea(id, contentDescription, left, top, right, bottom, metadata);
        operations.add(clickArea);
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Protocol Operations", OP_CODE, CLASS_NAME)
                .additionalDocumentation("click_area")
                .description("Define a region you can click on")
                .field(DocumentedOperation.INT, "id", "The id of the click area")
                .field(
                        DocumentedOperation.INT,
                        "contentDescription",
                        "The content description (as a textId)")
                .field(DocumentedOperation.FLOAT, "left", "The left side of the region")
                .field(DocumentedOperation.FLOAT, "top", "The top of the region")
                .field(DocumentedOperation.FLOAT, "right", "The right side of the region")
                .field(DocumentedOperation.FLOAT, "bottom", "The bottom of the region")
                .field(
                        DocumentedOperation.INT,
                        "metadata",
                        "User defined string (as a textId) accessible in callback");
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("id", mId)
                .add("contentDescriptionId", mContentDescription)
                .add("left", mLeft, mOutLeft)
                .add("top", mTop, mOutTop)
                .add("right", mRight, mOutRight)
                .add("bottom", mBottom, mOutBottom)
                .add("metadata", mMetadata);
    }
}
