/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT_ARRAY;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.operations.loom.LoomWireBuffer;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Arrays;
import java.util.List;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class PathData extends Operation implements VariableSupport, Serializable, VariableProvider {
    private static final int OP_CODE = Operations.DATA_PATH;
    private static final String CLASS_NAME = "PathData";
    private static final int MAX_PATH_LENGTH = 20000;
    int mInstanceId;
    float[] mFloatPath;
    float[] mOutputPath;
    int mWinding;
    private boolean mPathChanged = true;

    @Override
    public int getId() {
        return mInstanceId;
    }

    @Override
    public void setId(int id) {
        mInstanceId = id;
    }

    @SuppressWarnings("UnknownNullness") // Annotations on a primitive array are compile error.
    public PathData(int instanceId, float @NonNull [] floatPath, int winding) {
        mInstanceId = instanceId;
        mFloatPath = floatPath;
        mOutputPath = Arrays.copyOf(mFloatPath, mFloatPath.length);
        mWinding = winding;
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        for (int i = 0; i < mFloatPath.length; i++) {
            float v = mFloatPath[i];
            if (Utils.isVariable(v)) {
                float tmp = mOutputPath[i];
                mOutputPath[i] = Float.isNaN(v) ? context.getFloat(Utils.idFromNan(v)) : v;
                if (tmp != mOutputPath[i]) {
                    mPathChanged = true;
                }
            } else {
                mOutputPath[i] = v;
            }
        }
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        for (float v : mFloatPath) {
            if (Float.isNaN(v)) {
                context.listensTo(Utils.idFromNan(v), this);
            }
        }
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mInstanceId, mOutputPath);
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return pathString(mFloatPath);
    }

    @NonNull
    @Override
    public String toString() {
        return "PathData[" + mInstanceId + "] = " + "\"" + deepToString(" ") + "\"";
    }

    /**
     * public float[] getFloatPath(PaintContext context) { float[] ret = mRetFloats; // Assume
     * retFloats is declared elsewhere if (ret == null) { return mFloatPath; // Assume floatPath is
     * declared elsewhere } float[] localRef = mRef; // Assume ref is of type Float[] if (localRef
     * == null) { for (int i = 0; i < mFloatPath.length; i++) { ret[i] = mFloatPath[i]; } } else {
     * for (int i = 0; i < mFloatPath.length; i++) { float lr = localRef[i]; if (Float.isNaN(lr)) {
     * ret[i] = Utils.getActualValue(lr); } else { ret[i] = mFloatPath[i]; } } } return ret; }
     */
    public static final int MOVE = 10;

    public static final int LINE = 11;
    public static final int QUADRATIC = 12;
    public static final int CONIC = 13;
    public static final int CUBIC = 14;
    public static final int CLOSE = 15;
    public static final int DONE = 16;
    public static final float MOVE_NAN = Utils.asNan(MOVE);
    public static final float LINE_NAN = Utils.asNan(LINE);
    public static final float QUADRATIC_NAN = Utils.asNan(QUADRATIC);
    public static final float CONIC_NAN = Utils.asNan(CONIC);
    public static final float CUBIC_NAN = Utils.asNan(CUBIC);
    public static final float CLOSE_NAN = Utils.asNan(CLOSE);
    public static final float DONE_NAN = Utils.asNan(DONE);

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * add a create path operation
     *
     * @param buffer buffer to add to
     * @param id the id of the path
     * @param data the path
     */
    public static void apply(@NonNull WireBuffer buffer, int id, float @NonNull [] data) {
        buffer.start(Operations.DATA_PATH);
        buffer.writeInt(id);
        buffer.writeInt(data.length);
        for (float datum : data) {
            buffer.writeFloat(datum);
        }
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int imageId = buffer.readInt();
        int winding = imageId >> 24;
        imageId &= 0xffffff;
        // Since we need to resolve a modified int, we use the RemapContext directly
        // if available via the buffer.
        if (buffer instanceof LoomWireBuffer) {
            imageId = ((LoomWireBuffer) buffer).getRemapContext().resolveId(imageId);
        }

        int len = buffer.readInt();
        if (len > MAX_PATH_LENGTH) {
            throw new RuntimeException("Path too long");
        }
        float[] data = new float[len];
        for (int i = 0; i < data.length; i++) {
            float v = buffer.peekInt(); // Peeking as int to check NaN-ness
            if (Float.isNaN(Float.intBitsToFloat((int) v))) {
                float fv = buffer.readFloat();
                int vid = Utils.idFromNan(fv);
                if (vid > DONE) {
                    // Manual remapping since we already read it
                    if (buffer instanceof LoomWireBuffer) {
                        data[i] = ((LoomWireBuffer) buffer).getRemapContext().resolveNanId(fv);
                    } else {
                        data[i] = fv;
                    }
                } else {
                    data[i] = fv;
                }
            } else {
                data[i] = buffer.readFloat();
            }
        }
        operations.add(new PathData(imageId, data, winding));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Canvas Operations", OP_CODE, CLASS_NAME)
                .description("Define a complete static path")
                .field(DocumentedOperation.INT, "idAndWinding", "Encoded ID and winding rule")
                .field(INT, "length", "The number of elements in the path data")
                .field(FLOAT_ARRAY, "pathData", "The sequence of commands and coordinates");
    }

    /**
     * Render a path as a string
     *
     * @param path path as a array of floats
     * @return string describing the path
     */
    @NonNull
    public static String pathString(float @Nullable [] path) {
        if (path == null) {
            return "null";
        }
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < path.length; i++) {
            if (i != 0) {
                str.append(" ");
            }
            if (Float.isNaN(path[i])) {
                int id = Utils.idFromNan(path[i]); // Assume idFromNan is defined elsewhere
                if (id <= DONE) { // Assume DONE is a constant
                    switch (id) {
                        case MOVE:
                            str.append("M");
                            break;
                        case LINE:
                            str.append("L");
                            break;
                        case QUADRATIC:
                            str.append("Q");
                            break;
                        case CONIC:
                            str.append("R");
                            break;
                        case CUBIC:
                            str.append("C");
                            break;
                        case CLOSE:
                            str.append("Z");
                            break;
                        case DONE:
                            str.append(".");
                            break;
                        default:
                            str.append("[" + id + "]");
                            break;
                    }
                } else {
                    str.append("(" + id + ")");
                }
            } else {
                str.append(path[i]);
            }
        }
        return str.toString();
    }

    @Override
    public void apply(@NonNull RemoteContext context) {
        if (mPathChanged) {
            context.loadPathData(mInstanceId, mWinding, mOutputPath);
        }
        mPathChanged = false;
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer.addType(CLASS_NAME).add("id", mInstanceId).addPath("path", mFloatPath);
    }
}
