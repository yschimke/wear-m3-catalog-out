/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations.layout.modifiers;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.CoreDocument;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.operations.layout.ActionOperation;
import androidx.compose.remote.core.operations.layout.Component;
import androidx.compose.remote.core.operations.utilities.StringSerializer;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.SerializeTags;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Apply a value change on an integer variable. */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ValueIntegerExpressionChangeActionOperation extends Operation
        implements ActionOperation {
    private static final int OP_CODE = Operations.VALUE_INTEGER_EXPRESSION_CHANGE_ACTION;
    private static final String CLASS_NAME = "ValueIntegerExpressionChangeActionOperation";

    long mTargetValueId = -1;
    long mValueExpressionId = -1;

    public ValueIntegerExpressionChangeActionOperation(long id, long value) {
        mTargetValueId = id;
        mValueExpressionId = value;
    }

    @NonNull
    @Override
    public String toString() {
        return "ValueIntegerExpressionChangeActionOperation(" + mTargetValueId + ")";
    }

    /**
     * The name of the operation used during serialization
     *
     * @return the operation serialized name
     */
    @NonNull
    public String serializedName() {
        return "VALUE_INTEGER_EXPRESSION_CHANGE";
    }

    @Override
    public void serializeToString(int indent, @NonNull StringSerializer serializer) {
        serializer.append(
                indent, serializedName() + " = " + mTargetValueId + " -> " + mValueExpressionId);
    }

    @Override
    public void apply(@NonNull RemoteContext context) {}

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return (indent != null ? indent : "") + this;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mTargetValueId, mValueExpressionId);
    }

    @Override
    public void runAction(
            @NonNull RemoteContext context,
            @NonNull CoreDocument document,
            @NonNull Component component,
            float x,
            float y) {
        document.evaluateIntExpression(
                mValueExpressionId, (int) mTargetValueId, context);
    }

    /**
     * Write the operation to the buffer
     *
     * @param buffer a WireBuffer
     * @param valueId the long id pointing to an int value
     * @param value the value to set (long id)`
     */
    public static void apply(@NonNull WireBuffer buffer, long valueId, long value) {
        buffer.start(OP_CODE);
        buffer.writeLong(valueId);
        buffer.writeLong(value);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        long valueId = buffer.readLongNanId();
        long value = buffer.readLongNanId();
        operations.add(new ValueIntegerExpressionChangeActionOperation(valueId, value));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Actions & Events Operations", OP_CODE, CLASS_NAME)
                .description("Action that updates an integer variable via a dynamic expression")
                .field(
                        DocumentedOperation.LONG,
                        "targetValueId",
                        "The ID of the integer variable to update")
                .field(
                        DocumentedOperation.LONG,
                        "valueExpressionId",
                        "The ID of the expression to evaluate");
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addTags(SerializeTags.MODIFIER, SerializeTags.ACTION)
                .addType("ValueIntegerExpressionChangeActionOperation")
                .add("targetValueId", mTargetValueId)
                .add("valueExpressionId", mValueExpressionId);
    }
}
