/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;
import static androidx.compose.remote.core.operations.Utils.floatToString;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Operation to deal with Path data */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class PathTween extends PaintOperation
        implements VariableSupport, Serializable, VariableProvider, ComponentData {
    private static final int OP_CODE = Operations.PATH_TWEEN;
    private static final String CLASS_NAME = "PathTween";
    public int mOutId;
    public int mPathId1;
    public int mPathId2;
    public float mTween;
    public float mTweenOut;

    @Override
    public int getId() {
        return mOutId;
    }

    @Override
    public void setId(int id) {
        mOutId = id;
    }

    public PathTween(int outId, int pathId1, int pathId2, float tween) {
        this.mOutId = outId;
        this.mPathId1 = pathId1;
        this.mPathId2 = pathId2;
        this.mTween = tween;
        this.mTweenOut = mTween;
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        mTweenOut = Float.isNaN(mTween) ? context.getFloat(Utils.idFromNan(mTween)) : mTween;
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        if (Float.isNaN(mTween)) {
            context.listensTo(Utils.idFromNan(mTween), this);
        }
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mOutId, mPathId1, mPathId2, mTween);
    }

    @NonNull
    @Override
    public String toString() {
        return "PathTween["
                + mOutId
                + "] = ["
                + mPathId1
                + " ] + [ "
                + mPathId2
                + "], "
                + floatToString(mTween, mTweenOut);
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * Writes out the operation to the buffer
     *
     * @param buffer buffer to write to
     * @param outId id of the path
     * @param pathId1 source path 1
     * @param pathId2 source path 2
     * @param tween interpolate between two paths
     */
    public static void apply(
            @NonNull WireBuffer buffer, int outId, int pathId1, int pathId2, float tween) {
        buffer.start(OP_CODE);
        buffer.writeInt(outId);
        buffer.writeInt(pathId1);
        buffer.writeInt(pathId2);
        buffer.writeFloat(tween);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int outId1 = buffer.readId();
        int pathId1 = buffer.readId();
        int pathId2 = buffer.readId();
        float tween = buffer.readNanId();

        operations.add(new PathTween(outId1, pathId1, pathId2, tween));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Canvas Operations", OP_CODE, CLASS_NAME)
                .additionalDocumentation("path_tween")
                .description("Interpolate between two paths and store the result in a new path ID")
                .field(
                        DocumentedOperation.INT,
                        "outId",
                        "The ID of the resulting interpolated path")
                .field(INT, "pathId1", "The ID of the first source path")
                .field(INT, "pathId2", "The ID of the second source path")
                .field(FLOAT, "tween", "The interpolation factor [0..1]");
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    @Override
    public void paint(@NonNull PaintContext context) {
        context.tweenPath(mOutId, mPathId1, mPathId2, mTweenOut);
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("outId", mOutId)
                .add("pathId1", mPathId1)
                .add("pathId2", mPathId2)
                .add("tween", mTween, mTweenOut);
    }
}
