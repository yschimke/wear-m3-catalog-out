/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Operation convert int index of a list to text */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class TextLookupInt extends Operation
        implements VariableSupport, ComponentData, Serializable, VariableProvider {
    private static final int OP_CODE = Operations.TEXT_LOOKUP_INT;
    private static final String CLASS_NAME = "TextLookupInt";
    public int mTextId;
    public int mDataSetId;
    public int mOutIndex;
    public int mIndex;

    @Override
    public int getId() {
        return mTextId;
    }

    @Override
    public void setId(int id) {
        mTextId = id;
    }

    public TextLookupInt(int textId, int dataSetId, int indexId) {
        this.mTextId = textId;
        this.mDataSetId = dataSetId;
        this.mOutIndex = this.mIndex = indexId;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mTextId, mDataSetId, mIndex);
    }

    @NonNull
    @Override
    public String toString() {
        return "TextLookupInt["
                + Utils.idString(mTextId)
                + "] = "
                + Utils.idString(mDataSetId)
                + " "
                + mIndex;
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        mOutIndex = context.getInteger(mIndex);
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        context.listensTo(mIndex, this);
        context.listensTo(mDataSetId, this);
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * Writes out the operation to the buffer
     *
     * @param buffer buffer to write to
     * @param textId the id of the output text
     * @param dataSet float pointer to the array/list to turn int a string
     * @param indexId index of element to return
     */
    public static void apply(@NonNull WireBuffer buffer, int textId, int dataSet, int indexId) {
        buffer.start(OP_CODE);
        buffer.writeInt(textId);
        buffer.writeInt(dataSet);
        buffer.writeInt(indexId);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.declareId();
        int listId = buffer.readId();
        int indexId = buffer.readId();
        operations.add(new TextLookupInt(id, listId, indexId));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Text Operations", OP_CODE, CLASS_NAME)
                .description("Look up a string from a collection via an integer index variable")
                .field(DocumentedOperation.INT, "textId", "The ID of the resulting text")
                .field(INT, "dataSetId", "The ID of the string collection")
                .field(INT, "indexId", "The ID of the integer index variable");
    }

    @Override
    public void apply(@NonNull RemoteContext context) {
        int id = context.getCollectionsAccess().getId(mDataSetId, (int) mOutIndex);
        context.loadText(mTextId, context.getText(id));
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("textId", mTextId)
                .add("dataSetId", mDataSetId)
                .add("indexId", mIndex, mOutIndex);
    }
}
