/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations.layout;

import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.SerializableToString;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.operations.Header;
import androidx.compose.remote.core.operations.layout.animation.RootAnimateMeasure;
import androidx.compose.remote.core.operations.layout.measure.ComponentMeasure;
import androidx.compose.remote.core.operations.layout.measure.ComponentMeasurePool;
import androidx.compose.remote.core.operations.layout.measure.FlatMeasurePass;
import androidx.compose.remote.core.operations.layout.measure.Measurable;
import androidx.compose.remote.core.operations.layout.measure.MeasurePass;
import androidx.compose.remote.core.operations.layout.modifiers.ComponentModifiers;
import androidx.compose.remote.core.operations.layout.utils.DebugLog;
import androidx.compose.remote.core.operations.utilities.StringSerializer;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.SerializeTags;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;

/** Represents the root layout component. Entry point to the component tree layout/paint. */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class RootLayoutComponent extends Component {
    private int mCurrentId = -1;
    private boolean mHasTouchListeners = false;
    protected float mLastReportedOriginX = Float.NaN;
    protected float mLastReportedOriginY = Float.NaN;
    private MeasurePass mMeasurePass = null;

    private @NonNull MeasurePass getMeasurePass(@NonNull RemoteContext context) {
        boolean useFlat =
                context.getDocument() != null && context.getDocument().isFlatMeasurePassEnabled();
        if (mMeasurePass == null
                || (useFlat && !(mMeasurePass instanceof FlatMeasurePass))
                || (!useFlat && (mMeasurePass instanceof FlatMeasurePass))) {
            if (useFlat) {
                int totalComponents = context.getDocument() != null
                        ? context.getDocument().getComponentCount() : 16;
                mMeasurePass = new FlatMeasurePass(totalComponents);
            } else {
                mMeasurePass = new MeasurePass();
            }
        }
        return mMeasurePass;
    }

    private final java.util.ArrayList<Component> mDirtyBoundaries = new java.util.ArrayList<>();

    /** Register a dirty boundary component for incremental measurement. */
    public void registerDirtyBoundary(@NonNull Component boundary) {
        if (!mDirtyBoundaries.contains(boundary)) {
            mDirtyBoundaries.add(boundary);
        }
    }

    /** Clear all registered dirty boundary components. */
    public void clearDirtyBoundaries() {
        mDirtyBoundaries.clear();
    }

    private void resetSubTreeMeasureState(
            @NonNull Component component, @NonNull MeasurePass measure) {
        ComponentMeasure m = measure.get(component);
        m.setVisibility(component.mVisibility);
        m.clearCache();

        for (Operation op : component.getList()) {
            if (op instanceof Component) {
                resetSubTreeMeasureState((Component) op, measure);
            }
        }
    }

    /** Perform a partial layout pass on registered dirty boundaries. */
    public void performPartialLayoutPass(@NonNull RemoteContext context) {
        if (mDirtyBoundaries.isEmpty()) {
            return;
        }
        MeasurePass measurePass = getMeasurePass(context);
        measurePass.setContext(context);
        for (Component boundary : mDirtyBoundaries) {
            if (boundary.mNeedsMeasure) {
                resetSubTreeMeasureState(boundary, measurePass);

                float w = boundary.getWidth();
                float h = boundary.getHeight();
                boundary.measure(context.getPaintContext(), w, w, h, h, measurePass);
                boundary.layout(context, measurePass);
            }
        }
        mDirtyBoundaries.clear();
        measurePass.setContext(null);
    }

    public RootLayoutComponent(
            int componentId,
            float x,
            float y,
            float width,
            float height,
            @Nullable Component parent,
            int animationId) {
        super(parent, componentId, animationId, x, y, width, height);
    }

    public RootLayoutComponent(
            int componentId,
            float x,
            float y,
            float width,
            float height,
            @Nullable Component parent) {
        super(parent, componentId, -1, x, y, width, height);
    }

    public RootLayoutComponent(int componentId) {
        super(null, componentId, -1, 0, 0, 0, 0);
    }

    @NonNull
    @Override
    public String toString() {
        return "ROOT "
                + mComponentId
                + " ("
                + mX
                + ", "
                + mY
                + " - "
                + mWidth
                + " x "
                + mHeight
                + ") "
                + Visibility.toString(mVisibility);
    }

    @Override
    public void serializeToString(int indent, @NonNull StringSerializer serializer) {
        serializer.append(
                indent,
                "ROOT ["
                        + mComponentId
                        + ":"
                        + mAnimationId
                        + "] = ["
                        + mX
                        + ", "
                        + mY
                        + ", "
                        + mWidth
                        + ", "
                        + mHeight
                        + "] "
                        + Visibility.toString(mVisibility));
    }

    /**
     * Set the flag to traverse the tree when touch events happen
     *
     * @param value true to indicate that the tree has touch listeners
     */
    public void setHasTouchListeners(boolean value) {
        mHasTouchListeners = value;
    }

    /**
     * Traverse the hierarchy and assign generated ids to component without ids. Most components
     * would already have ids assigned during the document creation, but this allow us to take care
     * of any components added during the inflation.
     *
     * @param lastId the last known generated id
     */
    public void assignIds(int lastId) {
        mCurrentId = lastId;
        assignId(this);
    }

    private void assignId(@NonNull Component component) {
        if (component.getId() == -1) {
            mCurrentId--;
            component.setId(mCurrentId);
        }
        for (Operation op : component.getList()) {
            if (op instanceof Component) {
                assignId((Component) op);
            }
        }
    }

    @Override
    public boolean needsMeasure() {
        return mNeedsMeasure || !mDirtyBoundaries.isEmpty();
    }

    /** This will measure then layout the tree of components */
    public void layout(@NonNull RemoteContext context) {
        if (!mNeedsMeasure) {
            if (!mDirtyBoundaries.isEmpty()) {
                performPartialLayoutPass(context);
            }
            return;
        }
        if (context.isLayoutDebug()) {
            DebugLog.clear();
        }
        mNeedsMeasure = false;
        context.mLastComponent = this;
        float newWidth = context.mWidth;
        float newHeight = context.mHeight;
        context.mViewportWidth = newWidth;
        context.mViewportHeight = newHeight;

        MeasurePass measurePass = getMeasurePass(context);
        measurePass.setContext(context);
        measurePass.clear();
        ComponentMeasure self = measurePass.get(this);
        self.setX(0f);
        self.setY(0f);
        self.setW(mWidth);
        self.setH(mHeight);

        for (Operation op : mList) {
            if (op instanceof Measurable) {
                Measurable m = (Measurable) op;
                m.measure(context.getPaintContext(), 0f, newWidth, 0f, newHeight, measurePass);
                m.layout(context, measurePass);
            }
        }

        // Before calling super.layout, we need to ensure 'self' has the *target* state.
        self = measurePass.get(this);
        self.setW(newWidth);
        self.setH(newHeight);

        layout(context, measurePass);
        mDirtyBoundaries.clear();
        measurePass.setContext(null);
        if (context.isLayoutDebug()) {
            DebugLog.display();
        }
    }

    /** Measure the document and layout the components */
    public void measure(
            @NonNull RemoteContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight) {
        mNeedsMeasure = false;
        context.mLastComponent = this;
        float newWidth = context.mWidth;
        float newHeight = context.mHeight;
        context.mViewportWidth = newWidth;
        context.mViewportHeight = newHeight;

        MeasurePass measurePass = getMeasurePass(context);
        measurePass.setContext(context);
        measurePass.clear();
        ComponentMeasure self = measurePass.get(this);
        self.setX(0f);
        self.setY(0f);
        self.setW(mWidth);
        self.setH(mHeight);

        LayoutComponent firstComponent = null;
        for (Operation op : mList) {
            if (op instanceof Measurable) {
                Measurable m = (Measurable) op;
                if (firstComponent == null && op instanceof LayoutComponent) {
                    firstComponent = (LayoutComponent) op;
                }
                m.measure(
                        context.getPaintContext(),
                        minWidth,
                        maxWidth,
                        minHeight,
                        maxHeight,
                        measurePass);
                m.layout(context, measurePass);
            }
        }
        if (firstComponent != null) {
            setWidth(firstComponent.getWidth());
            setHeight(firstComponent.getHeight());
        }

        self = measurePass.get(this);
        self.setW(mWidth);
        self.setH(mHeight);

        layout(context, measurePass);
        mDirtyBoundaries.clear();
        measurePass.setContext(null);
    }

    @Override
    public void layout(@NonNull RemoteContext context, @NonNull MeasurePass measure) {
        ComponentMeasure m = measure.get(this);
        if (mFirstLayout) {
            mX = 0f;
            mY = 0f;
            mLastReportedOriginX = context.getDocument().getOriginX();
            mLastReportedOriginY = context.getDocument().getOriginY();
        }
        if (!mFirstLayout
                && context.isAnimationEnabled()
                && mAnimationSpec.isAnimationEnabled()
                && m.getAllowsAnimation()) {
            if (mAnimateMeasure == null) {
                ComponentMeasurePool pool = context.getComponentMeasurePool();
                ComponentMeasure origin =
                        pool.obtain(mComponentId, mX, mY, mWidth, mHeight, mVisibility);
                ComponentMeasure target =
                        pool.obtain(
                                mComponentId,
                                m.getX(),
                                m.getY(),
                                m.getW(),
                                m.getH(),
                                m.getVisibility());
                float targetOriginX = context.getDocument().getOriginX();
                float targetOriginY = context.getDocument().getOriginY();
                float lastOriginX = mLastReportedOriginX;
                float lastOriginY = mLastReportedOriginY;
                boolean sizeChanged = mWidth != m.getW() || mHeight != m.getH();
                boolean originChanged =
                        !Float.isNaN(lastOriginX)
                                && (lastOriginX != targetOriginX || lastOriginY != targetOriginY);

                if (sizeChanged && originChanged && context.useFeature(Header.FEATURE_LT_RESIZE)) {
                    mAnimateMeasure =
                            new RootAnimateMeasure(
                                    context.currentTime,
                                    this,
                                    origin,
                                    target,
                                    lastOriginX,
                                    lastOriginY,
                                    targetOriginX,
                                    targetOriginY,
                                    mAnimationSpec.getMotionDuration(),
                                    mAnimationSpec.getVisibilityDuration(),
                                    mAnimationSpec.getEnterAnimation(),
                                    mAnimationSpec.getExitAnimation(),
                                    mAnimationSpec.getMotionEasingType(),
                                    mAnimationSpec.getVisibilityEasingType());
                } else {
                    mLastReportedOriginX = targetOriginX;
                    mLastReportedOriginY = targetOriginY;
                    pool.recycle(origin);
                    pool.recycle(target);
                }
            }
        }
        super.layout(context, measure);
    }

    @Override
    public void paint(@NonNull PaintContext context) {
        float originX = context.getContext().getDocument().getOriginX();
        float originY = context.getContext().getDocument().getOriginY();
        if (applyAnimationAsNeeded(context)) {
            mLastReportedOriginX = originX;
            mLastReportedOriginY = originY;
            return;
        }
        if (isGone() || isInvisible()) {
            return;
        }
        mNeedsRepaint = false;
        RemoteContext remoteContext = context.getContext();
        remoteContext.mLastComponent = this;

        context.save();

        if (mX != 0f || mY != 0f) {
            context.translate(mX, mY);
        }

        if (mParent == null) { // root layout
            context.clipRect(0f, 0f, mWidth, mHeight);
        }

        for (Operation op : mList) {
            if (op instanceof PaintOperation) {
                ((PaintOperation) op).paint(context);
                remoteContext.incrementOpCount();
            }
        }

        context.restore();
        mLastReportedOriginX = originX;
        mLastReportedOriginY = originY;
    }

    /**
     * Display the component hierarchy
     *
     * @return a formatted string containing the component hierarchy
     */
    @NonNull
    public String displayHierarchy() {
        StringSerializer serializer = new StringSerializer();
        displayHierarchy(this, 0, serializer);
        return serializer.toString();
    }

    /**
     * Display the component hierarchy
     *
     * @param component  the current component
     * @param indent     the current indentation level
     * @param serializer the serializer we write to
     */
    public void displayHierarchy(
            @NonNull Component component, int indent, @NonNull StringSerializer serializer) {
        component.serializeToString(indent, serializer);
        for (Operation c : component.mList) {
            if (c instanceof ComponentModifiers) {
                ((ComponentModifiers) c).serializeToString(indent + 1, serializer);
            } else if (c instanceof Component) {
                displayHierarchy((Component) c, indent + 1, serializer);
            } else if (c instanceof SerializableToString) {
                ((SerializableToString) c).serializeToString(indent + 1, serializer);
            }
        }
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return "RootLayout";
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return Operations.LAYOUT_ROOT;
    }

    /** Write the operation on the buffer */
    public static void apply(@NonNull WireBuffer buffer, int componentId) {
        buffer.start(Operations.LAYOUT_ROOT);
        buffer.writeInt(componentId);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer     the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int componentId = buffer.declareId();
        operations.add(new RootLayoutComponent(componentId, 0, 0, 0, 0, null, -1));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Layout Operations", id(), name())
                .field(INT, "componentId", "Unique ID for this component")
                .description(
                        "Root element for a document. Other components / layout managers are"
                                + " children in the component tree starting from"
                                + " this Root component.");
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mComponentId);
    }

    /**
     * Returns true if we have components with a touch listener
     *
     * @return true if listeners, false otherwise
     */
    public boolean getHasTouchListeners() {
        return mHasTouchListeners;
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        super.serialize(serializer);
        serializer.addTags(SerializeTags.COMPONENT);
        serializer.addType("RootLayoutComponent");
    }
}
