/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.Limits.MAX_PARTICLE_COUNT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT_ARRAY;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;
import static androidx.compose.remote.core.operations.utilities.AnimatedFloatExpression.VAR1;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.operations.loom.LoomWireBuffer;
import androidx.compose.remote.core.operations.utilities.AnimatedFloatExpression;
import androidx.compose.remote.core.operations.utilities.NanMap;
import androidx.compose.remote.core.serialize.MapSerializer;

import org.jspecify.annotations.NonNull;

import java.util.Arrays;
import java.util.List;

/**
 * This creates a particle system. which consist of id, particleCount, array of id's and equations
 * for constructing the particles
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ParticlesCreate extends PaintOperation implements VariableSupport, VariableProvider {
    private static final int OP_CODE = Operations.PARTICLE_DEFINE;
    private static final String CLASS_NAME = "ParticlesCreate";
    private int mId;
    private final float[][] mEquations;
    private final float[][] mOutEquations;
    private final float[][] mParticles;
    private final int[] mIndexeVars; // the elements in mEquations that INDEXES
    private final int mParticleCount;
    private final int[] mVarId;
    private static final int MAX_FLOAT_ARRAY = 2000;
    private static final int MAX_EQU_LENGTH = 32;
    @NonNull AnimatedFloatExpression mExp = new AnimatedFloatExpression();

    @Override
    public int getId() {
        return mId;
    }

    @Override
    public void setId(int id) {
        mId = id;
    }

    public ParticlesCreate(
            int id, int @NonNull [] varId, float @NonNull [][] values, int particleCount) {
        mId = id;
        mVarId = varId;
        mEquations = values;
        mParticleCount = particleCount;
        mOutEquations = new float[values.length][];
        for (int i = 0; i < values.length; i++) {
            mOutEquations[i] = new float[values[i].length];
            System.arraycopy(values[i], 0, mOutEquations[i], 0, values[i].length);
        }
        mParticles = new float[particleCount][varId.length];

        int[] index = new int[20];
        int indexes = 0;
        int var1Int = Float.floatToRawIntBits(VAR1);
        for (int j = 0; j < mEquations.length; j++) {
            for (int k = 0; k < mEquations[j].length; k++) {
                if (Float.isNaN(mEquations[j][k])
                        && Float.floatToRawIntBits(mEquations[j][k]) == var1Int) {
                    index[indexes++] = j * mEquations.length + k;
                }
            }
        }
        mIndexeVars = Arrays.copyOf(index, indexes);
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        for (int i = 0; i < mEquations.length; i++) {

            for (int j = 0; j < mEquations[i].length; j++) {
                float v = mEquations[i][j];
                mOutEquations[i][j] =
                        (Float.isNaN(v)
                                        && !AnimatedFloatExpression.isMathOperator(v)
                                        && !NanMap.isDataVariable(v))
                                ? context.getFloat(Utils.idFromNan(v))
                                : v;
            }
        }
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        context.putObject(mId, this); // T
        for (int i = 0; i < mEquations.length; i++) {
            float[] mEquation = mEquations[i];
            for (float v : mEquation) {
                if (Float.isNaN(v)
                        && !AnimatedFloatExpression.isMathOperator(v)
                        && !NanMap.isDataVariable(v)) {
                    context.listensTo(Utils.idFromNan(v), this);
                }
            }
        }
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mId, mVarId, mEquations, mParticleCount);
    }

    @NonNull
    @Override
    public String toString() {
        String str = "ParticlesCreate[" + Utils.idString(mId) + "] ";
        for (int j = 0; j < mVarId.length; j++) {
            str += "[" + mVarId[j] + "] ";
            float[] equation = mEquations[j];
            String[] labels = new String[equation.length];
            for (int i = 0; i < equation.length; i++) {
                if (Float.isNaN(equation[i])) {
                    labels[i] = "[" + Utils.idStringFromNan(equation[i]) + "]";
                }
            }
            str += AnimatedFloatExpression.toString(equation, labels) + "\n";
        }

        return str;
    }

    /** Write the operation on the buffer */
    public static void apply(
            @NonNull WireBuffer buffer,
            int id,
            int @NonNull [] varId,
            float @NonNull [][] equations,
            int particleCount) {
        buffer.start(OP_CODE);
        buffer.writeInt(id);
        buffer.writeInt(particleCount);
        buffer.writeInt(varId.length);
        for (int i = 0; i < varId.length; i++) {
            buffer.writeInt(varId[i]);
            buffer.writeInt(equations[i].length);
            for (int j = 0; j < equations[i].length; j++) {
                buffer.writeFloat(equations[i][j]);
            }
        }
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.readId();
        int particleCount = buffer.readInt();
        if (MAX_PARTICLE_COUNT < particleCount) {
            throw new RuntimeException(
                    particleCount + " particles more than max = " + MAX_PARTICLE_COUNT);
        }
        int varLen = buffer.readInt();
        if (varLen > MAX_FLOAT_ARRAY) {
            throw new RuntimeException(varLen + " map entries more than max = " + MAX_FLOAT_ARRAY);
        }
        int[] varId = new int[varLen];
        float[][] equations = new float[varLen][];
        for (int i = 0; i < varId.length; i++) {
            varId[i] = buffer.readId();
            int equLen = buffer.readInt();
            if (equLen > MAX_EQU_LENGTH) {
                throw new RuntimeException(
                        equLen + " map entries more than max = " + MAX_FLOAT_ARRAY);
            }
            equations[i] = new float[equLen];
            for (int j = 0; j < equations[i].length; j++) {
                float v = buffer.readFloat();
                if (Float.isNaN(v)
                        && !AnimatedFloatExpression.isMathOperator(v)
                        && !NanMap.isDataVariable(v)) {
                    // Manual remapping since we already read it
                    if (buffer instanceof LoomWireBuffer) {
                        equations[i][j] =
                                ((LoomWireBuffer) buffer).getRemapContext().resolveNanId(v);
                    } else {
                        equations[i][j] = v;
                    }
                } else {
                    equations[i][j] = v;
                }
            }
        }
        ParticlesCreate data = new ParticlesCreate(id, varId, equations, particleCount);
        operations.add(data);
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Animation & Particles Operations", OP_CODE, CLASS_NAME)
                .additionalDocumentation("particles_create")
                .description("Create a particle system")
                .field(DocumentedOperation.INT, "id", "The ID of the particle system")
                .field(INT, "particleCount", "Number of particles to create")
                .field(INT, "varCount", "Number of variables associated with each particle")
                .field(INT, "varId[0..n]", "The ID of each associated variable")
                .field(
                        INT,
                        "equLen[0..n]",
                        "The length of the initialization equation for each variable")
                .field(FLOAT_ARRAY, "equations[0..n]", "The initialization equations (RPN)");
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    @Override
    public void paint(@NonNull PaintContext context) {
        for (int i = 0; i < mParticles.length; i++) {
            initializeParticle(i);
        }
    }

    void initializeParticle(int pNo) {
        for (int j = 0; j < mParticles[pNo].length; j++) {
            for (int k = 0; k < mIndexeVars.length; k++) {
                int pos = mIndexeVars[k];
                int jIndex = pos / mOutEquations.length;
                int kIndex = pos % mOutEquations.length;
                mOutEquations[jIndex][kIndex] = pNo;
            }
            mParticles[pNo][j] = mExp.eval(mOutEquations[j], mOutEquations[j].length);
        }
    }

    public float @NonNull [][] getParticles() {
        return mParticles;
    }

    public int @NonNull [] getVariableIds() {
        return mVarId;
    }

    public float @NonNull [][] getEquations() {
        return mOutEquations;
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {}
}
