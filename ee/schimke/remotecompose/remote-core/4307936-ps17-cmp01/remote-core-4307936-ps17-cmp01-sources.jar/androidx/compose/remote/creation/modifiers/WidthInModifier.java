/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.creation.modifiers;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.creation.RemoteComposeWriter;

import org.jspecify.annotations.NonNull;

/** Width modifier */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class WidthInModifier implements RecordingModifier.Element {

    int mType;
    float mMin;
    float mMax;

    public WidthInModifier(float min, float max) {
        mMin = min;
        mMax = max;
        mType = -1;
    }

    public WidthInModifier(int type, float min, float max) {
        mType = type;
        mMin = min;
        mMax = max;
    }

    @Override
    public void write(@NonNull RemoteComposeWriter writer) {
        if (mType == -1) {
            writer.addWidthInModifierOperation(mMin, mMax);
        } else {
            writer.addDimensionConstraintsModifierOperation(mType, mMin, mMax);
        }
    }

    public float getMin() {
        return mMin;
    }

    public float getMax() {
        return mMax;
    }
}
