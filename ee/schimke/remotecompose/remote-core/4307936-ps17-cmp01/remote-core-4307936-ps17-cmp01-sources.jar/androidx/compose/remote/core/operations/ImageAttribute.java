/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.REPEATED_INT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.SHORT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.serialize.MapSerializer;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;

/** Operation to extract meta Attributes from image data objects */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ImageAttribute extends PaintOperation {
    private static final int OP_CODE = Operations.ATTRIBUTE_IMAGE;
    private static final String CLASS_NAME = "ImageAttribute";
    private final int @Nullable [] mArgs;
    public int mId;
    int mImageId;
    short mType;

    public static final short IMAGE_WIDTH = 0;
    public static final short IMAGE_HEIGHT = 1;

    /**
     * Create a new ImageAttribute operation
     *
     * @param id the id to store the attribute
     * @param imageId the id of the image
     * @param type the type of value to return
     * @param args support for additional arguments (currently none)
     */
    public ImageAttribute(int id, int imageId, short type, int @Nullable [] args) {
        this.mId = id;
        this.mImageId = imageId;
        this.mType = type;
        this.mArgs = args;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mId, mImageId, mType, mArgs);
    }

    @Override
    public @NonNull String toString() {
        return "ImageAttribute[" + mId + "] = " + mImageId + " " + mType;
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    public static @NonNull String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * Writes out the operation to the buffer
     *
     * @param buffer write command to this buffer
     * @param id the id
     * @param imageId the id of the image
     * @param type the type of value
     * @param args the value of the float
     */
    public static void apply(
            @NonNull WireBuffer buffer, int id, int imageId, short type, int @Nullable [] args) {
        buffer.start(OP_CODE);
        buffer.writeInt(id);
        buffer.writeInt(imageId);
        buffer.writeShort(type);
        if (args == null) {
            buffer.writeShort((short) 0);
        } else {
            buffer.writeShort((short) args.length);
            for (int i = 0; i < args.length; i++) {
                buffer.writeInt(args[i]);
            }
        }
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.readId();
        int imageId = buffer.readId();
        short type = (short) buffer.readShort();
        short len = (short) buffer.readShort();
        int[] args = new int[len];
        for (int i = 0; i < args.length; i++) {
            args[i] = buffer.readId();
        }
        operations.add(new ImageAttribute(id, imageId, type, args));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Logic & Expressions Operations", OP_CODE, CLASS_NAME)
                .description("Extract image-related properties (width, height)")
                .field(INT, "id", "The ID of the float variable to store the result")
                .field(INT, "imageId", "The ID of the image variable to extract from")
                .field(SHORT, "type", "The type of property to extract (0=WIDTH, 1=HEIGHT)")
                .field(SHORT, "argsLength", "The number of additional arguments")
                .field(REPEATED_INT, "args", "The additional arguments");
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    @Override
    public void paint(@NonNull PaintContext context) {
        BitmapData bitmapData = (BitmapData) context.getContext().getObject(mImageId);
        switch (mType) {
            case IMAGE_WIDTH:
                context.getContext().loadFloat(mId, bitmapData.getWidth());
                break;
            case IMAGE_HEIGHT:
                context.getContext().loadFloat(mId, bitmapData.getHeight());
                break;
        }
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("id", mId)
                .add("imageId", mImageId)
                .add("args", Collections.singletonList(mArgs))
                .addType(typeToString());
    }

    private String typeToString() {
        switch (mType) {
            case IMAGE_WIDTH:
                return "IMAGE_WIDTH";
            case IMAGE_HEIGHT:
                return "IMAGE_HEIGHT";
            default:
                return "INVALID_TYPE";
        }
    }
}
