/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.operations.Utils.floatToString;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;

/** Base class for draw commands that take 4 floats */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public abstract class DrawBase4 extends PaintOperation implements VariableSupport, Serializable {
    @NonNull protected String mName = "DrawRectBase";
    protected float mX1;
    protected float mY1;
    protected float mX2;
    protected float mY2;
    protected float mX1Value;
    protected float mY1Value;
    protected float mX2Value;
    protected float mY2Value;

    public DrawBase4(float x1, float y1, float x2, float y2) {
        mX1Value = x1;
        mY1Value = y1;
        mX2Value = x2;
        mY2Value = y2;

        mX1 = x1;
        mY1 = y1;
        mX2 = x2;
        mY2 = y2;
    }

    public float getX1() {
        return mX1Value;
    }

    public float getY1() {
        return mY1Value;
    }

    public float getX2() {
        return mX2Value;
    }

    public float getY2() {
        return mY2Value;
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        mX1 = Float.isNaN(mX1Value) ? context.getFloat(Utils.idFromNan(mX1Value)) : mX1Value;
        mY1 = Float.isNaN(mY1Value) ? context.getFloat(Utils.idFromNan(mY1Value)) : mY1Value;
        mX2 = Float.isNaN(mX2Value) ? context.getFloat(Utils.idFromNan(mX2Value)) : mX2Value;
        mY2 = Float.isNaN(mY2Value) ? context.getFloat(Utils.idFromNan(mY2Value)) : mY2Value;
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        if (Float.isNaN(mX1Value)) {
            context.listensTo(Utils.idFromNan(mX1Value), this);
        }
        if (Float.isNaN(mY1Value)) {
            context.listensTo(Utils.idFromNan(mY1Value), this);
        }
        if (Float.isNaN(mX2Value)) {
            context.listensTo(Utils.idFromNan(mX2Value), this);
        }
        if (Float.isNaN(mY2Value)) {
            context.listensTo(Utils.idFromNan(mY2Value), this);
        }
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        write(buffer, mX1, mY1, mX2, mY2);
    }

    protected abstract void write(
            @NonNull WireBuffer buffer, float v1, float v2, float v3, float v4);

    protected interface Maker {
        DrawBase4 create(float v1, float v2, float v3, float v4);
    }

    @NonNull
    @Override
    public String toString() {
        return mName
                + " "
                + floatToString(mX1Value, mX1)
                + " "
                + floatToString(mY1Value, mY1)
                + " "
                + floatToString(mX2Value, mX2)
                + " "
                + floatToString(mY2Value, mY2);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations to add to
     * @param maker the maker of the operation
     */
    public static void read(
            @NonNull WireBuffer buffer, @NonNull List<Operation> operations, @NonNull Maker maker) {
        float v1 = buffer.readNanId();
        float v2 = buffer.readNanId();
        float v3 = buffer.readNanId();
        float v4 = buffer.readNanId();

        Operation op = maker.create(v1, v2, v3, v4);
        operations.add(op);
    }

    /**
     * Construct and Operation from the 3 variables.
     *
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @return
     */
    @Nullable
    public Operation construct(float x1, float y1, float x2, float y2) {
        return null;
    }

    /**
     * Writes out the operation to the buffer
     *
     * @param buffer
     * @param opCode
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     */
    protected static void write(
            @NonNull WireBuffer buffer, int opCode, float x1, float y1, float x2, float y2) {
        buffer.start(opCode);
        buffer.writeFloat(x1);
        buffer.writeFloat(y1);
        buffer.writeFloat(x2);
        buffer.writeFloat(y2);
    }

    protected @NonNull MapSerializer serialize(
            @NonNull MapSerializer serializer,
            @NonNull String x1Name,
            @NonNull String y1Name,
            @NonNull String x2Name,
            @NonNull String y2Name) {
        return serializer
                .add(x1Name, mX1Value, mX1)
                .add(y1Name, mY1Value, mY1)
                .add(x2Name, mX2Value, mX2)
                .add(y2Name, mY2Value, mY2);
    }
}
