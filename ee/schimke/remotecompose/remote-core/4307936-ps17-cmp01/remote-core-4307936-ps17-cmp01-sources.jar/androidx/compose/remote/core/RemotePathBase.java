/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.core;

import static androidx.compose.remote.core.operations.Utils.idFromNan;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.operations.PathData;
import androidx.compose.remote.core.operations.Utils;

import org.jspecify.annotations.NonNull;

import java.util.Arrays;

/** Common RemotePath implementation that manages the path buffer. */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class RemotePathBase implements RcPlatformServices.RcPathArrayCreator {
    private static final int DEFAULT_BUFFER_SIZE = 1024;
    int mMaxSize = DEFAULT_BUFFER_SIZE;
    float[] mPath = new float[mMaxSize];
    float mCx = 0, mCy = 0;
    int mSize = 0;

    public RemotePathBase(int bufferSize) {
        mMaxSize = bufferSize;
        mPath = new float[mMaxSize];
    }

    public RemotePathBase() {
        mPath = new float[mMaxSize];
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public RemotePathBase(@NonNull String pathData) {
        mPath = new float[mMaxSize];
        parsePathData(pathData);
    }

    /** Reset the path */
    public void reset() {
        mSize = 0;
    }

    public float getCurrentX() {
        return mCx;
    }

    public float getCurrentY() {
        return mCy;
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public int getSize() {
        return mSize;
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public float @NonNull [] getPath() {
        return mPath;
    }

    private void resize(int need) {
        if (mSize + need >= mMaxSize) {
            mMaxSize = Math.max(mMaxSize * 2, mSize + need);
            mPath = Arrays.copyOf(mPath, mMaxSize);
        }
    }

    /** reserve space TODO: Do we need this function? */
    public void incReserve(int extraPtCount) {
        mSize = 0;
    }

    /** Adds type to the path. */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public void add(int type) {
        resize(1);
        mPath[mSize++] = Utils.asNan(type);
    }

    /** Adds type, a1, a2 to the path. */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public void addMove(int type, float a1, float a2) {

        resize(3);
        mPath[mSize++] = Utils.asNan(type);
        mPath[mSize++] = a1;
        mPath[mSize++] = a2;
    }

    /** Adds type, a1, a2 to the path. */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public void add(int type, float a1, float a2) {

        resize(5);
        mPath[mSize++] = Utils.asNan(type);
        mSize += 2; // THIS IS FLAW in the encoding TODO FIX ON VERSIONING
        mPath[mSize++] = a1;
        mPath[mSize++] = a2;
    }

    /** Adds type, a1, a2, a3, a4 to the path. */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public void add(int type, float a1, float a2, float a3, float a4) {

        resize(7);

        mPath[mSize++] = Utils.asNan(type);
        mSize += 2; // THIS IS FLAW in the encoding TODO FIX ON VERSIONING

        mPath[mSize++] = a1;
        mPath[mSize++] = a2;
        mPath[mSize++] = a3;
        mPath[mSize++] = a4;
    }

    /** Adds type, a1, a2, a3, a4, a5 to the path. */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public void add(int type, float a1, float a2, float a3, float a4, float a5) {

        resize(8);
        mPath[mSize++] = Utils.asNan(type);
        mSize += 2; // THIS IS FLAW in the encoding TODO FIX ON VERSIONING

        mPath[mSize++] = a1;
        mPath[mSize++] = a2;
        mPath[mSize++] = a3;
        mPath[mSize++] = a4;
        mPath[mSize++] = a5;
    }

    /** Adds type, a1, a2, a3, a4, a5, a6 to the path. */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public void add(int type, float a1, float a2, float a3, float a4, float a5, float a6) {

        resize(9);
        mPath[mSize++] = Utils.asNan(type);
        mSize += 2; // THIS IS FLAW in the encoding TODO FIX ON VERSIONING

        mPath[mSize++] = a1;
        mPath[mSize++] = a2;
        mPath[mSize++] = a3;
        mPath[mSize++] = a4;
        mPath[mSize++] = a5;
        mPath[mSize++] = a6;
    }

    /**
     * Set the beginning of the next contour to the point (x,y).
     *
     * @param x The x-coordinate of the start of a new contour
     * @param y The y-coordinate of the start of a new contour
     */
    public void moveTo(float x, float y) {
        addMove(MOVE, x, y);
        mCx = x;
        mCy = y;
    }

    /**
     * Set the beginning of the next contour relative to the last point on the previous contour. If
     * there is no previous contour, this is treated the same as moveTo().
     *
     * @param dx The amount to add to the x-coordinate of the end of the previous contour, to
     *           specify the start of a new contour
     * @param dy The amount to add to the y-coordinate of the end of the previous contour, to
     *           specify the start of a new contour
     */
    public void rMoveTo(float dx, float dy) {
        mCx += dx;
        mCy += dy;
        addMove(MOVE, mCx, mCy);
    }

    /**
     * Add a quadratic bezier from the last point, approaching control point (x1,y1), and ending at
     * (x2,y2). If no moveTo() call has been made for this contour, the first point is automatically
     * set to (0,0).
     *
     * @param x1 The x-coordinate of the control point on a quadratic curve
     * @param y1 The y-coordinate of the control point on a quadratic curve
     * @param x2 The x-coordinate of the end point on a quadratic curve
     * @param y2 The y-coordinate of the end point on a quadratic curve
     */
    public void quadTo(float x1, float y1, float x2, float y2) {
        add(QUADRATIC, x1, y1, x2, y2);
        mCx = x2;
        mCy = y2;
    }

    /**
     * Same as quadTo, but the coordinates are considered relative to the last point on this
     * contour. If there is no previous point, then a moveTo(0,0) is inserted automatically.
     *
     * @param dx1 The amount to add to the x-coordinate of the last point on this contour, for the
     *            control point of a quadratic curve
     * @param dy1 The amount to add to the y-coordinate of the last point on this contour, for the
     *            control point of a quadratic curve
     * @param dx2 The amount to add to the x-coordinate of the last point on this contour, for the
     *            end point of a quadratic curve
     * @param dy2 The amount to add to the y-coordinate of the last point on this contour, for the
     *            end point of a quadratic curve
     */
    public void rQuadTo(float dx1, float dy1, float dx2, float dy2) {
        add(QUADRATIC, dx1 + mCx, dy1 + mCy, dx2 + mCx, dy2 + mCy);
        mCx += dx2;
        mCy += dy2;
    }

    /**
     * Add a quadratic bezier from the last point, approaching control point (x1,y1), and ending at
     * (x2,y2), weighted by <code>weight</code>. If no moveTo() call has been made for this contour,
     * the first point is automatically set to (0,0).
     *
     * <p>A weight of 1 is equivalent to calling {@link #quadTo(float, float, float, float)}. A
     * weight of 0 is equivalent to calling {@link #lineTo(float, float)} to <code>(x1, y1)</code>
     * followed by {@link #lineTo(float, float)} to <code>(x2, y2)</code>.
     *
     * @param x1     The x-coordinate of the control point on a conic curve
     * @param y1     The y-coordinate of the control point on a conic curve
     * @param x2     The x-coordinate of the end point on a conic curve
     * @param y2     The y-coordinate of the end point on a conic curve
     * @param weight The weight of the conic applied to the curve. A value of 1 is equivalent to a
     *               quadratic with the given control and anchor points and a value of 0 is
     *               equivalent to a
     *               line to the first and another line to the second point.
     */
    public void conicTo(float x1, float y1, float x2, float y2, float weight) {
        add(CONIC, x1, y1, x2, y2, weight);
        mCx = x2;
        mCy = y2;
    }

    /**
     * Same as conicTo, but the coordinates are considered relative to the last point on this
     * contour. If there is no previous point, then a moveTo(0,0) is inserted automatically.
     *
     * @param dx1    The amount to add to the x-coordinate of the last point on this contour, for
     *              the
     *               control point of a conic curve
     * @param dy1    The amount to add to the y-coordinate of the last point on this contour, for
     *              the
     *               control point of a conic curve
     * @param dx2    The amount to add to the x-coordinate of the last point on this contour, for
     *              the
     *               end point of a conic curve
     * @param dy2    The amount to add to the y-coordinate of the last point on this contour, for
     *              the
     *               end point of a conic curve
     * @param weight The weight of the conic applied to the curve. A value of 1 is equivalent to a
     *               quadratic with the given control and anchor points and a value of 0 is
     *               equivalent to a
     *               line to the first and another line to the second point.
     */
    public void rConicTo(float dx1, float dy1, float dx2, float dy2, float weight) {
        add(CONIC, dx1 + mCx, dy1 + mCy, dx2 + mCx, dy2 + mCy, weight);
        mCx += dx2;
        mCy += dy2;
    }

    /**
     * Add a line from the last point to the specified point (x,y). If no moveTo() call has been
     * made for this contour, the first point is automatically set to (0,0).
     *
     * @param x The x-coordinate of the end of a line
     * @param y The y-coordinate of the end of a line
     */
    public void lineTo(float x, float y) {
        add(LINE, x, y);
        mCx = x;
        mCy = y;
    }

    /**
     * Same as lineTo, but the coordinates are considered relative to the last point on this
     * contour. If there is no previous point, then a moveTo(0,0) is inserted automatically.
     *
     * @param dx The amount to add to the x-coordinate of the previous point on this contour, to
     *           specify a line
     * @param dy The amount to add to the y-coordinate of the previous point on this contour, to
     *           specify a line
     */
    public void rLineTo(float dx, float dy) {
        add(LINE, mCx = dx + mCx, mCy = dy + mCy);
    }

    /**
     * Add a cubic bezier from the last point, approaching control points (x1,y1) and (x2,y2), and
     * ending at (x3,y3). If no moveTo() call has been made for this contour, the first point is
     * automatically set to (0,0).
     *
     * @param x1 The x-coordinate of the 1st control point on a cubic curve
     * @param y1 The y-coordinate of the 1st control point on a cubic curve
     * @param x2 The x-coordinate of the 2nd control point on a cubic curve
     * @param y2 The y-coordinate of the 2nd control point on a cubic curve
     * @param x3 The x-coordinate of the end point on a cubic curve
     * @param y3 The y-coordinate of the end point on a cubic curve
     */
    public void cubicTo(float x1, float y1, float x2, float y2, float x3, float y3) {
        add(CUBIC, x1, y1, x2, y2, x3, y3);
        mCx = x3;
        mCy = y3;
    }

    /**
     * Same as cubicTo, but the coordinates are considered relative to the current point on this
     * contour. If there is no previous point, then a moveTo(0,0) is inserted automatically.
     */
    public void rCubicTo(float x1, float y1, float x2, float y2, float x3, float y3) {

        add(CUBIC, x1 + mCx, y1 + mCy, x2 + mCx, y2 + mCy, x3 + mCx, y3 + mCy);
        mCx += x3;
        mCy += y3;
    }

    /**
     * Close the current contour. If the current point is not equal to the first point of the
     * contour, a line segment is automatically added.
     */
    public void close() {
        add(CLOSE);
    }

    /**
     * Rewinds the path: clears any lines and curves from the path but keeps the internal data
     * structure for faster reuse.
     */
    public void rewind() {
        mSize = 0;
    }

    /**
     * Returns true if the path is empty (contains no lines or curves)
     *
     * @return true if the path is empty (contains no lines or curves)
     */
    public boolean isEmpty() {
        return mSize == 0;
    }

    /**
     * Add the specified arc to the path as a new contour.
     *
     * @param left        left most bounds of the oval
     * @param top         top most bounds of the oval
     * @param right       right most bounds of the oval
     * @param bottom      lowest bound of the oval
     * @param startAngle  Starting angle (in degrees) where the arc begins
     * @param sweepAngle  Sweep angle (in degrees) measured clockwise
     * @param forceMoveTo If true, always begin a new contour with the arc
     */
    public void arcTo(
            float left,
            float top,
            float right,
            float bottom,
            float startAngle,
            float sweepAngle,
            boolean forceMoveTo) {
        addArc(left, top, right, bottom, startAngle, sweepAngle, forceMoveTo);
    }

    /**
     * Add the specified arc to the path as a new contour by
     * decomposing it into cubic Bezier segments.
     *
     * @param left        left most bounds of the oval
     * @param top         top most bounds of the oval
     * @param right       right most bounds of the oval
     * @param bottom      lowest bound of the oval
     * @param startAngle  Starting angle (in degrees) where the arc begins
     * @param sweepAngle  Sweep angle (in degrees) measured clockwise
     * @param forceMoveTo If true, always begin a new contour with the arc
     */
    public void addArc(
            float left,
            float top,
            float right,
            float bottom,
            float startAngle,
            float sweepAngle,
            boolean forceMoveTo) {
        float rx = Math.abs(right - left) / 2.0f;
        float ry = Math.abs(bottom - top) / 2.0f;
        if (rx == 0 || ry == 0 || sweepAngle == 0) {
            return;
        }
        float cx = (left + right) / 2.0f;
        float cy = (top + bottom) / 2.0f;
        double startRad = Math.toRadians(startAngle);
        double sweepRad = Math.toRadians(sweepAngle);

        double startX = cx + rx * Math.cos(startRad);
        double startY = cy + ry * Math.sin(startRad);

        if (isEmpty() || forceMoveTo) {
            moveTo((float) startX, (float) startY);
        } else {
            lineTo((float) startX, (float) startY);
        }

        int segments = (int) Math.ceil(Math.abs(sweepRad) / (Math.PI / 2.0));
        if (segments == 0) {
            segments = 1;
        }

        for (int i = 0; i < segments; i++) {
            double s1 = startRad + i * sweepRad / segments;
            double s2 = startRad + (i + 1) * sweepRad / segments;

            double t = 4.0 / 3.0 * Math.tan((s2 - s1) / 4.0);

            double xstart = cx + rx * Math.cos(s1);
            double ystart = cy + ry * Math.sin(s1);

            double xend = cx + rx * Math.cos(s2);
            double yend = cy + ry * Math.sin(s2);

            double cp1x = xstart - t * rx * Math.sin(s1);
            double cp1y = ystart + t * ry * Math.cos(s1);

            double cp2x = xend + t * rx * Math.sin(s2);
            double cp2y = yend - t * ry * Math.cos(s2);

            cubicTo(
                    (float) cp1x,
                    (float) cp1y,
                    (float) cp2x,
                    (float) cp2y,
                    (float) xend,
                    (float) yend);
        }
    }

    /**
     * Add an elliptical arc from the current position to (x, y)
     * by decomposing it into cubic Bezier segments.
     *
     * @param rx       Radius in x
     * @param ry       Radius in y
     * @param angle    Rotation angle of ellipse in degrees
     * @param largeArc Whether to choose the large arc (>180 deg)
     * @param sweep    Whether to choose the clockwise arc
     * @param x        Destination x
     * @param y        Destination y
     */
    public void arcTo(
            float rx,
            float ry,
            float angle,
            boolean largeArc,
            boolean sweep,
            float x,
            float y) {
        arcTo(mCx, mCy, rx, ry, angle, largeArc, sweep, x, y);
    }

    /**
     * Add an elliptical arc from (x0, y0) to (x1, y1) by decomposing it into cubic Bezier segments.
     */
    public void arcTo(
            float x0,
            float y0,
            float rx,
            float ry,
            float angle,
            boolean largeArc,
            boolean sweep,
            float x1,
            float y1) {
        if (rx == 0 || ry == 0) {
            lineTo(x1, y1);
            return;
        }
        double alpha = Math.toRadians(angle);
        double cosAlpha = Math.cos(alpha);
        double sinAlpha = Math.sin(alpha);

        double dx = (x0 - x1) / 2.0;
        double dy = (y0 - y1) / 2.0;
        double x1p = cosAlpha * dx + sinAlpha * dy;
        double y1p = -sinAlpha * dx + cosAlpha * dy;

        double rxp = Math.abs(rx);
        double ryp = Math.abs(ry);
        double check = (x1p * x1p) / (rxp * rxp) + (y1p * y1p) / (ryp * ryp);
        if (check > 1.0) {
            double s = Math.sqrt(check);
            rxp *= s;
            ryp *= s;
        }

        double sign = (largeArc == sweep) ? -1.0 : 1.0;
        double numerator = (rxp * rxp * ryp * ryp)
                - (rxp * rxp * y1p * y1p) - (ryp * ryp * x1p * x1p);
        double denominator = (rxp * rxp * y1p * y1p) + (ryp * ryp * x1p * x1p);
        double root = Math.sqrt(Math.max(0.0, numerator / denominator));
        double cxp = sign * root * rxp * y1p / ryp;
        double cyp = -sign * root * ryp * x1p / rxp;

        double cx = cosAlpha * cxp - sinAlpha * cyp + (x0 + x1) / 2.0;
        double cy = sinAlpha * cxp + cosAlpha * cyp + (y0 + y1) / 2.0;

        double theta1 = Math.atan2((y1p - cyp) / ryp, (x1p - cxp) / rxp);
        double dTheta = Math.atan2((-y1p - cyp) / ryp, (-x1p - cxp) / rxp) - theta1;

        if (sweep && dTheta < 0) {
            dTheta += 2 * Math.PI;
        } else if (!sweep && dTheta > 0) {
            dTheta -= 2 * Math.PI;
        }

        int segments = (int) Math.ceil(Math.abs(dTheta) / (Math.PI / 2.0));
        if (segments == 0) {
            segments = 1;
        }

        for (int i = 0; i < segments; i++) {
            double s1 = theta1 + i * dTheta / segments;
            double s2 = theta1 + (i + 1) * dTheta / segments;

            double t = 4.0 / 3.0 * Math.tan((s2 - s1) / 4.0);

            double xstart = cosAlpha * rxp * Math.cos(s1) - sinAlpha * ryp * Math.sin(s1) + cx;
            double ystart = sinAlpha * rxp * Math.cos(s1) + cosAlpha * ryp * Math.sin(s1) + cy;

            double xend = cosAlpha * rxp * Math.cos(s2) - sinAlpha * ryp * Math.sin(s2) + cx;
            double yend = sinAlpha * rxp * Math.cos(s2) + cosAlpha * ryp * Math.sin(s2) + cy;

            double cp1x = xstart + t * (-cosAlpha * rxp * Math.sin(s1)
                    - sinAlpha * ryp * Math.cos(s1));
            double cp1y = ystart + t * (-sinAlpha * rxp * Math.sin(s1)
                    + cosAlpha * ryp * Math.cos(s1));

            double cp2x = xend - t * (-cosAlpha * rxp * Math.sin(s2)
                    - sinAlpha * ryp * Math.cos(s2));
            double cp2y = yend - t * (-sinAlpha * rxp * Math.sin(s2)
                    + cosAlpha * ryp * Math.cos(s2));

            cubicTo(
                    (float) cp1x,
                    (float) cp1y,
                    (float) cp2x,
                    (float) cp2y,
                    (float) xend,
                    (float) yend);
        }
    }

    private void parsePathData(@NonNull String pathData) {

        float[] cords = new float[6];

        String[] commands = pathData.split("(?=[MmZzLlHhVvCcSsQqTtAa])");
        for (String command : commands) {
            char cmd = command.charAt(0);
            String[] values = command.substring(1).trim().split("[,\\s]+");
            switch (cmd) {
                case 'M':
                    moveTo(Float.parseFloat(values[0]), Float.parseFloat(values[1]));
                    break;
                case 'L':
                    for (int i = 0; i < values.length; i += 2) {
                        lineTo(Float.parseFloat(values[i]), Float.parseFloat(values[i + 1]));
                    }
                    break;
                case 'H':
                    for (String value : values) {
                        lineTo(Float.parseFloat(value), cords[1]);
                    }
                    break;
                case 'C':
                    for (int i = 0; i < values.length; i += 6) {
                        cubicTo(
                                Float.parseFloat(values[i]), Float.parseFloat(values[i + 1]),
                                Float.parseFloat(values[i + 2]), Float.parseFloat(values[i + 3]),
                                Float.parseFloat(values[i + 4]), Float.parseFloat(values[i + 5]));
                    }

                    break;
                case 'S':
                    for (int i = 0; i < values.length; i += 4) {
                        cubicTo(
                                2 * cords[0] - cords[2],
                                2 * cords[1] - cords[3],
                                Float.parseFloat(values[i]),
                                Float.parseFloat(values[i + 1]),
                                Float.parseFloat(values[i + 2]),
                                Float.parseFloat(values[i + 3]));
                    }
                    break;
                case 'Q':
                    for (int i = 0; i < values.length; i += 4) {
                        quadTo(
                                Float.parseFloat(values[i]),
                                Float.parseFloat(values[i + 1]),
                                Float.parseFloat(values[i + 2]),
                                Float.parseFloat(values[i + 3]));
                    }
                    break;
                case 'A':
                case 'a':
                    for (int i = 0; i < values.length; i += 7) {
                        float rx = Float.parseFloat(values[i]);
                        float ry = Float.parseFloat(values[i + 1]);
                        float angle = Float.parseFloat(values[i + 2]);
                        boolean largeArc = Float.parseFloat(values[i + 3]) != 0f;
                        boolean sweep = Float.parseFloat(values[i + 4]) != 0f;
                        float x = Float.parseFloat(values[i + 5]);
                        float y = Float.parseFloat(values[i + 6]);
                        if (cmd == 'a') {
                            x += mCx;
                            y += mCy;
                        }
                        arcTo(rx, ry, angle, largeArc, sweep, x, y);
                    }
                    break;
                case 'Z':
                    close();
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported command: " + cmd);
            }
            if (cmd != 'Z' && cmd != 'H') {
                cords[0] = Float.parseFloat(values[values.length - 2]);
                cords[1] = Float.parseFloat(values[values.length - 1]);
                if (cmd == 'C' || cmd == 'S') {
                    cords[2] = Float.parseFloat(values[values.length - 4]);
                    cords[3] = Float.parseFloat(values[values.length - 3]);
                }
            }
        }
    }

    @Override
    public @NonNull String toString() {
        StringBuilder builder = new StringBuilder();
        int i = 0;
        float[] floatPath = mPath;
        while (i < mSize) {
            System.err.println(idFromNan(floatPath[i]));
            switch (idFromNan(floatPath[i])) {
                case PathData.MOVE:
                    i++;
                    builder.append("moveTo(" + floatPath[i + 0] + ", " + floatPath[i + 1] + " )\n");
                    i += 2;
                    break;
                case PathData.LINE:
                    i += 3;
                    builder.append("lineTo(" + floatPath[i + 0] + ", " + floatPath[i + 1] + " )\n");
                    i += 2;
                    break;
                case PathData.QUADRATIC:
                    i += 3;
                    builder.append(
                            "quadTo("
                                    + floatPath[i + 0]
                                    + ", "
                                    + floatPath[i + 1]
                                    + ", "
                                    + floatPath[i + 2]
                                    + ", "
                                    + floatPath[i + 3]
                                    + " )\n");
                    i += 4;
                    break;
                case PathData.CONIC:
                    i += 3;
                    builder.append(
                            "conicTo("
                                    + floatPath[i + 0]
                                    + ", "
                                    + floatPath[i + 1]
                                    + ", "
                                    + floatPath[i + 2]
                                    + ", "
                                    + floatPath[i + 3]
                                    + ", "
                                    + floatPath[i + 4]
                                    + " )\n");
                    i += 5;
                    break;
                case PathData.CUBIC:
                    i += 3;
                    builder.append(
                            "cubicTo( "
                                    + floatPath[i + 0]
                                    + ", "
                                    + floatPath[i + 1]
                                    + ", "
                                    + floatPath[i + 2]
                                    + ", "
                                    + floatPath[i + 3]
                                    + ", "
                                    + floatPath[i + 4]
                                    + ", "
                                    + floatPath[i + 5]
                                    + " )\n");
                    i += 6;
                    break;
                case PathData.CLOSE:
                    builder.append("close()\n");
                    i++;
                    break;
                case PathData.DONE:
                    builder.append("done()\n");
                    i++;
                    break;
                default:
                    System.err.println(" Odd command " + idFromNan(floatPath[i]));
                    return builder.toString();
            }
        }
        return builder.toString();
    }

    /**
     * creates a float Array of the same size as the mPath
     *
     * @return the array
     */
    @Override
    public float @NonNull [] createFloatArray() {
        return Arrays.copyOf(mPath, mSize);
    }

    public static final int MOVE = 10;
    public static final int LINE = 11;
    public static final int QUADRATIC = 12;
    public static final int CONIC = 13;
    public static final int CUBIC = 14;
    public static final int CLOSE = 15;
    public static final int DONE = 16;
    public static final float MOVE_NAN = Utils.asNan(MOVE);
    public static final float LINE_NAN = Utils.asNan(LINE);
    public static final float QUADRATIC_NAN = Utils.asNan(QUADRATIC);
    public static final float CONIC_NAN = Utils.asNan(CONIC);
    public static final float CUBIC_NAN = Utils.asNan(CUBIC);
    public static final float CLOSE_NAN = Utils.asNan(CLOSE);
    public static final float DONE_NAN = Utils.asNan(DONE);

    /*
       TODO make decisions on "missing" methods

        public void addArc(float left, float top, float right, float bottom, float startAngle,
         float sweepAngle, boolean forceMoveTo) {

        public void addRoundRect(RectF rect, float[] radii, Path.Direction dir) {
        public void addRect(RectF rect, Path.Direction dir) {
        public void setLastPoint(float dx, float dy) {
        public boolean isInterpolatable(Path otherPath) {
        public void addRoundRect(float left, float top, float right, float bottom,
         float[] radii, Path.Direction dir) {
        public boolean interpolate(Path otherPath, float t, Path interpolatedPath) {
        public void addOval(float left, float top, float right, float bottom, Path.Direction dir) {
        public void toggleInverseFillType() {
        public void addRoundRect(RectF rect, float rx, float ry, Path.Direction dir) {
        public boolean isRect(RectF rect) {
        public void addCircle(float x, float y, float radius, Path.Direction dir) {
        public float[] approximate(float acceptableError) {
        public void transform(Matrix matrix) {
        public boolean op(Path path1, Path path2, Path.Op op) {
        public void addRect(float left, float top, float right, float bottom, Path.Direction dir) {
        public void computeBounds(RectF bounds, boolean exact) {
        public int getGenerationId() {
        public void offset(float dx, float dy, Path dst) {
        public void addOval(RectF oval, Path.Direction dir) {
        public Path.FillType getFillType() {
        public void offset(float dx, float dy) {
        public boolean isInverseFillType() {

        public void addPath(Path src, float dx, float dy) {
        public void set(Path src) {
        public void setFillType(Path.FillType ft) {
        public void addPath(Path src, Matrix matrix) {
        public boolean op(Path path, Path.Op op) {
        public void addPath(Path src) {
        public void addRoundRect(float left, float top, float right, float bottom,
         float rx, float ry, Path.Direction dir) {
    */
}
