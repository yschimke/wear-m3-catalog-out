/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.SerializableToString;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.operations.utilities.StringSerializer;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ComponentValue extends Operation
        implements SerializableToString, Serializable, ComponentData, VariableProvider {
    private static final int OP_CODE = Operations.COMPONENT_VALUE;
    private static final String CLASS_NAME = "ComponentValue";

    public static final int WIDTH = 0;
    public static final int HEIGHT = 1;
    public static final int POS_X = 2;
    public static final int POS_Y = 3;
    public static final int POS_ROOT_X = 4;
    public static final int POS_ROOT_Y = 5;
    public static final int CONTENT_WIDTH = 6;
    public static final int CONTENT_HEIGHT = 7;

    private int mType = WIDTH;
    private int mComponentID = -1;
    private int mValueId = -1;

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    @NonNull
    @Override
    public String toString() {
        return CLASS_NAME + "(" + mType + ", " + mComponentID + ", " + mValueId + ")";
    }

    public int getType() {
        return mType;
    }

    public int getComponentId() {
        return mComponentID;
    }

    public int getValueId() {
        return mValueId;
    }

    public void setComponentId(int componentId) {
        mComponentID = componentId;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mType, mComponentID, mValueId);
    }

    @Override
    public void apply(@NonNull RemoteContext context) {
        // Nothing
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int type = buffer.readInt();
        int componentId = buffer.readId();
        int valueId = buffer.readId();
        ComponentValue op = new ComponentValue(type, componentId, valueId);
        operations.add(op);
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Logic & Expressions Operations", OP_CODE, CLASS_NAME)
                .description(
                        "Expose a component's layout property (width, height, etc.) as a variable")
                .field(DocumentedOperation.INT, "type", "The type of value to expose")
                .possibleValues("WIDTH", WIDTH)
                .possibleValues("HEIGHT", HEIGHT)
                .possibleValues("POS_X", POS_X)
                .possibleValues("POS_Y", POS_Y)
                .possibleValues("POS_ROOT_X", POS_ROOT_X)
                .possibleValues("POS_ROOT_Y", POS_ROOT_Y)
                .possibleValues("CONTENT_WIDTH", CONTENT_WIDTH)
                .possibleValues("CONTENT_HEIGHT", CONTENT_HEIGHT)
                .field(INT, "componentId", "The ID of the component to reference")
                .field(INT, "valueId", "The ID of the variable to store the value in");
    }

    @Override
    public int getId() {
        return mValueId;
    }

    @Override
    public void setId(int id) {
        mValueId = id;
    }

    public ComponentValue(int type, int componentId, int valueId) {
        mType = type;
        mComponentID = componentId;
        mValueId = valueId;
    }

    /**
     * Writes out the ComponentValue to the buffer
     *
     * @param buffer buffer to write to
     * @param type type of value (WIDTH or HEIGHT)
     * @param componentId component id to reference
     * @param valueId remote float used to represent the component value
     */
    public static void apply(@NonNull WireBuffer buffer, int type, int componentId, int valueId) {
        buffer.start(OP_CODE);
        buffer.writeInt(type);
        buffer.writeInt(componentId);
        buffer.writeInt(valueId);
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    @Override
    public void serializeToString(int indent, @NonNull StringSerializer serializer) {
        String type = "WIDTH";
        if (mType == HEIGHT) {
            type = "HEIGHT";
        }
        serializer.append(
                indent,
                CLASS_NAME
                        + " value "
                        + mValueId
                        + " set to "
                        + type
                        + " of Component "
                        + mComponentID);
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("valueId", mValueId)
                .add("componentValueType", typeToString(mType))
                .add("componentId", mComponentID);
    }

    private String typeToString(int type) {
        if (type == WIDTH) return "WIDTH";
        if (type == HEIGHT) return "HEIGHT";
        return "INVALID_TYPE";
    }
}
