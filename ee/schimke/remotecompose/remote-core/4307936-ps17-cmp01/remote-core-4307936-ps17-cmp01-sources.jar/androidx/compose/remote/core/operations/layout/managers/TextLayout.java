/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations.layout.managers;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.RcPlatformServices;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.operations.Utils;
import androidx.compose.remote.core.operations.layout.Component;
import androidx.compose.remote.core.operations.layout.measure.ComponentMeasure;
import androidx.compose.remote.core.operations.layout.measure.MeasurePass;
import androidx.compose.remote.core.operations.layout.measure.Size;
import androidx.compose.remote.core.operations.layout.modifiers.AlignByModifierOperation;
import androidx.compose.remote.core.operations.paint.PaintBundle;
import androidx.compose.remote.core.operations.utilities.StringSerializer;
import androidx.compose.remote.core.semantics.AccessibleComponent;
import androidx.compose.remote.core.serialize.MapSerializer;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;

/** Text component, referencing a text id */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class TextLayout extends LayoutManager implements VariableSupport, AccessibleComponent {

    public static final int TEXT_ALIGN_LEFT = 1;
    public static final int TEXT_ALIGN_RIGHT = 2;
    public static final int TEXT_ALIGN_CENTER = 3;
    public static final int TEXT_ALIGN_JUSTIFY = 4;
    public static final int TEXT_ALIGN_START = 5;
    public static final int TEXT_ALIGN_END = 6;

    public static final int OVERFLOW_CLIP = 1;
    public static final int OVERFLOW_VISIBLE = 2;
    public static final int OVERFLOW_ELLIPSIS = 3;
    public static final int OVERFLOW_START_ELLIPSIS = 4;
    public static final int OVERFLOW_MIDDLE_ELLIPSIS = 5;

    public static final int FLAG_IS_DYNAMIC_COLOR = 1;

    private static final boolean DEBUG = false;

    private final boolean mIsDynamicColorEnabled;

    private int mTextId = -1;
    private int mColor = 0;
    private int mColorValue = -1;
    private float mFontSize = 16f;
    private float mFontSizeValue = 16f;
    private int mFontStyle = 0;
    private float mFontWeight = 400f;
    private int mFontFamilyId = -1;
    private int mTextAlign = -1;
    private int mTextAlignValue = -1;
    private int mOverflow = 1;
    private int mMaxLines = Integer.MAX_VALUE;

    private int mType = -1;
    private float mTextX;
    private float mTextY;
    private float mTextW = -1;
    private float mTextH = -1;

    private float mBaseline = 0f;

    private final Size mCachedSize = new Size(0f, 0f);

    @Nullable private String mCachedString;
    @Nullable private String mNewString;

    RcPlatformServices.ComputedTextLayout mComputedTextLayout;

    @Nullable
    @Override
    public Integer getTextId() {
        return mTextId;
    }

    public float getFontSize() {
        return mFontSize;
    }

    public float getFontSizeValue() {
        return mFontSizeValue;
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        if (mTextId != -1) {
            context.listensTo(mTextId, this);
        }
        if (isAtLeastVersion7(context)) {
            if (Float.isNaN(mFontSize)) {
                context.listensTo(Utils.idFromNan(mFontSize), this);
            }
            if (mIsDynamicColorEnabled) {
                context.listensTo(mColor, this);
            }
        }
    }

    private static boolean isAtLeastVersion7(@NonNull RemoteContext context) {
        return context.supportsVersion(1, 1, 0);
    }

    private boolean isDynamicColorEnabled(int textAlign) {
        short flags = getFlagsFromTextAlign(textAlign);
        return (flags & FLAG_IS_DYNAMIC_COLOR) > 0;
    }

    private static short getFlagsFromTextAlign(int textAlign) {
        return (short) (textAlign >>> 16);
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        if (isAtLeastVersion7(context)) {
            mFontSizeValue =
                    Float.isNaN(mFontSize)
                            ? context.getFloat(Utils.idFromNan(mFontSize))
                            : mFontSize;

            mTextAlignValue = (short) (mTextAlign & 0xFFFF);
            if (mIsDynamicColorEnabled) {
                int prevColorValue = mColorValue;
                mColorValue = context.getColor(mColor);

                if (prevColorValue != mColorValue && mComputedTextLayout != null) {
                    // mComputedTextLayout caches the paint color
                    invalidateMeasure();
                }
            } else {
                mColorValue = mColor;
            }
        } else {
            mFontSizeValue = mFontSize;
            mColorValue = mColor;
            mTextAlignValue = mTextAlign;
        }
        String cachedString = context.getText(mTextId);
        if (cachedString != null && cachedString.equalsIgnoreCase(mCachedString)) {
            return;
        }
        mNewString = cachedString;
        if (mType == -1) {
            if (mFontFamilyId != -1) {
                String fontFamily = context.getText(mFontFamilyId);
                if (fontFamily != null) {
                    if (fontFamily.equalsIgnoreCase("default")) {
                        mType = 0;
                    } else if (fontFamily.equalsIgnoreCase("sans-serif")) {
                        mType = 1;
                    } else if (fontFamily.equalsIgnoreCase("serif")) {
                        mType = 2;
                    } else if (fontFamily.equalsIgnoreCase("monospace")) {
                        mType = 3;
                    }
                }
            }
            if (mType == -1) {
                mType = 0; // default
            }
        }

        if (mHorizontalScrollDelegate != null) {
            mHorizontalScrollDelegate.reset();
        }
        if (mVerticalScrollDelegate != null) {
            mVerticalScrollDelegate.reset();
        }
        invalidateMeasure();
    }

    public TextLayout(
            @Nullable Component parent,
            int componentId,
            int animationId,
            float x,
            float y,
            float width,
            float height,
            int textId,
            int color,
            float fontSize,
            int fontStyle,
            float fontWeight,
            int fontFamilyId,
            int textAlign,
            int overflow,
            int maxLines) {
        super(parent, componentId, animationId, x, y, width, height);
        mTextId = textId;
        mColor = color;
        mFontSize = fontSize;
        if (!Float.isNaN(mFontSize)) {
            mFontSizeValue = fontSize;
        }
        mIsDynamicColorEnabled = isDynamicColorEnabled(textAlign);
        if (!mIsDynamicColorEnabled) {
            mColorValue = color;
        }
        mFontStyle = fontStyle;
        mFontWeight = fontWeight;
        mFontFamilyId = fontFamilyId;
        mTextAlign = textAlign;
        mOverflow = overflow;
        mMaxLines = maxLines;
    }

    public TextLayout(
            @Nullable Component parent,
            int componentId,
            int animationId,
            int textId,
            int color,
            float fontSize,
            int fontStyle,
            float fontWeight,
            int fontFamilyId,
            int textAlign,
            int overflow,
            int maxLines) {
        this(
                parent,
                componentId,
                animationId,
                0,
                0,
                0,
                0,
                textId,
                color,
                fontSize,
                fontStyle,
                fontWeight,
                fontFamilyId,
                textAlign,
                overflow,
                maxLines);
    }

    @NonNull public PaintBundle mPaint = new PaintBundle();

    @Override
    public float getAlignValue(@NonNull PaintContext context, float line) {
        if (Float.isNaN(line)) {
            int id = Utils.idFromNan(line);
            if (id == AlignByModifierOperation.ID_FIRST_BASELINE) {
                return mBaseline;
            }
            if (id == AlignByModifierOperation.ID_LAST_BASELINE) {
                // TODO add support for last baseline
                return mBaseline;
            }
            if (Utils.isVariable(line)) {
                return context.getContext().getFloat(Utils.idFromNan(line));
            }
            // unrecognized line value
            return 0f;
        }
        return line;
    }

    @Override
    public void paintingComponent(@NonNull PaintContext context) {
        Component prev = context.getContext().mLastComponent;
        RemoteContext remoteContext = context.getContext();
        remoteContext.mLastComponent = this;

        context.save();
        context.translate(mX, mY);
        if (mGraphicsLayerModifier != null) {
            context.startGraphicsLayer((int) getWidth(), (int) getHeight());
            mCachedAttributes.clear();
            mGraphicsLayerModifier.fillInAttributes(mCachedAttributes);
            context.setGraphicsLayer(mCachedAttributes);
        }
        mComponentModifiers.paint(context);
        float tx = mPaddingLeft;
        float ty = mPaddingTop;
        context.translate(tx, ty);

        //////////////////////////////////////////////////////////
        // Text content
        //////////////////////////////////////////////////////////
        context.savePaint();
        mPaint.reset();
        mPaint.setStyle(PaintBundle.STYLE_FILL);
        mPaint.setColor(mColorValue);
        mPaint.setTextSize(mFontSizeValue);
        mPaint.setTextStyle(mType, (int) mFontWeight, mFontStyle == 1);
        context.replacePaint(mPaint);
        if (mCachedString == null) {
            return;
        }
        int length = mCachedString.length();
        float contentW = mWidth - mPaddingLeft - mPaddingRight;
        float px = 0f;
        switch (mTextAlignValue) {
            case TEXT_ALIGN_CENTER:
                px = (contentW - mTextW) / 2f;
                break;
            case TEXT_ALIGN_RIGHT:
            case TEXT_ALIGN_END:
                px = contentW - mTextW;
                break;
            case TEXT_ALIGN_LEFT:
            case TEXT_ALIGN_START:
            default:
                px = 0f;
        }

        if (mComputedTextLayout != null) {
            context.save();
            if (mOverflow != OVERFLOW_VISIBLE) {
                context.clipRect(
                        0f,
                        0f,
                        contentW,
                        mHeight - mPaddingTop - mPaddingBottom);
            }
            context.translate(getScrollX() + px, getScrollY());
            context.drawComplexText(mComputedTextLayout);
            context.restore();
        } else {
            px += mTextX;
            if (mTextW > contentW) {
                context.save();
                context.clipRect(
                        0f,
                        0f,
                        contentW,
                        mHeight - mPaddingTop - mPaddingBottom);
                context.translate(getScrollX(), getScrollY());
                context.drawTextRun(mTextId, 0, length, 0, 0, px, mTextY, false);
                context.restore();
            } else {
                context.drawTextRun(mTextId, 0, length, 0, 0, px, mTextY, false);
            }
        }
        if (DEBUG) {
            mPaint.setStyle(PaintBundle.STYLE_FILL_AND_STROKE);
            mPaint.setColor(1f, 1F, 1F, 1F);
            mPaint.setStrokeWidth(3f);
            context.applyPaint(mPaint);
            context.drawLine(0f, 0f, mWidth, mHeight);
            context.drawLine(0f, mHeight, mWidth, 0f);
            mPaint.setColor(1f, 0F, 0F, 1F);
            mPaint.setStrokeWidth(1f);
            context.applyPaint(mPaint);
            context.drawLine(0f, 0f, mWidth, mHeight);
            context.drawLine(0f, mHeight, mWidth, 0f);
        }
        context.restorePaint();
        //////////////////////////////////////////////////////////

        if (mGraphicsLayerModifier != null) {
            context.endGraphicsLayer();
        }

        context.translate(-tx, -ty);
        context.restore();
        context.getContext().mLastComponent = prev;
    }

    @NonNull
    @Override
    public String toString() {
        return "TEXT_LAYOUT ["
                + mComponentId
                + ":"
                + mAnimationId
                + "] ("
                + mX
                + ", "
                + mY
                + " - "
                + mWidth
                + " x "
                + mHeight
                + ") "
                + Visibility.toString(mVisibility);
    }

    @NonNull
    @Override
    protected String getSerializedName() {
        return "TEXT_LAYOUT";
    }

    @Override
    public void serializeToString(int indent, @NonNull StringSerializer serializer) {
        serializer.append(
                indent,
                getSerializedName()
                        + " ["
                        + mComponentId
                        + ":"
                        + mAnimationId
                        + "] = "
                        + "["
                        + mX
                        + ", "
                        + mY
                        + ", "
                        + mWidth
                        + ", "
                        + mHeight
                        + "] "
                        + Visibility.toString(mVisibility)
                        + " ("
                        + mTextId
                        + ":\""
                        + mCachedString
                        + "\")");
    }

    @Override
    public void computeSize(
            @NonNull PaintContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight,
            @NonNull MeasurePass measure) {
        super.computeSize(context, minWidth, maxWidth, minHeight, maxHeight, measure);
        computeWrapSize(
                context,
                minWidth,
                maxWidth,
                minHeight,
                maxHeight,
                true,
                true,
                measure,
                mCachedSize);
        ComponentMeasure m = measure.get(this);
        m.setW(mCachedSize.getWidth());
        m.setH(mCachedSize.getHeight());
    }

    @Override
    public void computeWrapSize(
            @NonNull PaintContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight,
            boolean horizontalWrap,
            boolean verticalWrap,
            @NonNull MeasurePass measure,
            @NonNull Size size) {
        context.savePaint();
        mPaint.reset();
        mPaint.setTextSize(mFontSizeValue);
        mPaint.setTextStyle(mType, (int) mFontWeight, mFontStyle == 1);
        mPaint.setColor(mColorValue);
        context.replacePaint(mPaint);
        float[] bounds = new float[4];
        if (mNewString != null && !mNewString.equals(mCachedString)) {
            mCachedString = mNewString;
        }
        if (mCachedString == null) {
            return;
        }

        boolean forceComplex = false;
        int flags = PaintContext.TEXT_MEASURE_FONT_HEIGHT | PaintContext.TEXT_MEASURE_SPACES;
        if (mMaxLines == 1
                && (mOverflow == OVERFLOW_START_ELLIPSIS
                        || mOverflow == OVERFLOW_MIDDLE_ELLIPSIS
                        || mOverflow == OVERFLOW_ELLIPSIS)) {
            flags |= PaintContext.TEXT_COMPLEX;
            // TODO: enable forceComplex = true;
        }
        if ((flags & PaintContext.TEXT_COMPLEX) != PaintContext.TEXT_COMPLEX) {
            for (int i = 0; i < mCachedString.length(); i++) {
                char c = mCachedString.charAt(i);
                if ((c == '\n') || (c == '\t')) {
                    flags |= PaintContext.TEXT_COMPLEX;
                    forceComplex = true;
                    break;
                }
            }
        }
        if (!forceComplex) {
            context.getTextBounds(mTextId, 0, mCachedString.length(), flags, bounds);
            mBaseline = -bounds[1];
        }
        if (forceComplex || (bounds[2] - bounds[1] > maxWidth && mMaxLines > 1 && maxWidth > 0f)) {
            mComputedTextLayout =
                    context.layoutComplexText(
                            mTextId,
                            0,
                            mCachedString.length(),
                            mTextAlign,
                            mOverflow,
                            mMaxLines,
                            maxWidth,
                            maxHeight,
                            0f,
                            0f,
                            1f,
                            0,
                            0,
                            0,
                            false,
                            false,
                            flags);
            if (mComputedTextLayout != null) {
                bounds[0] = 0f;
                bounds[1] = 0f;
                bounds[2] = mComputedTextLayout.getWidth();
                bounds[3] = mComputedTextLayout.getHeight();
            }
        } else {
            mComputedTextLayout = null;
        }
        context.restorePaint();
        float w = bounds[2] - bounds[0];
        float h = bounds[3] - bounds[1];
        size.setWidth(Math.min(maxWidth, w));
        mTextX = -bounds[0];
        size.setHeight(Math.min(maxHeight, h));
        mTextY = -bounds[1];
        mTextW = w;
        mTextH = h;
    }

    @Override
    public float minIntrinsicHeight(@NonNull RemoteContext context) {
        return mTextH;
    }

    @Override
    public float minIntrinsicWidth(@NonNull RemoteContext context) {
        return mTextW;
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return "TextLayout";
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return Operations.LAYOUT_TEXT;
    }

    /**
     * Write the operation in the buffer
     *
     * @param buffer the WireBuffer we write on
     * @param componentId the component id
     * @param animationId the animation id (-1 if not set)
     * @param textId the text id
     * @param color the text color
     * @param fontSize the font size
     * @param fontStyle the font style
     * @param fontWeight the font weight
     * @param fontFamilyId the font family id
     * @param textAlign the alignment rules
     */
    public static void apply(
            @NonNull WireBuffer buffer,
            int componentId,
            int animationId,
            int textId,
            int color,
            float fontSize,
            int fontStyle,
            float fontWeight,
            int fontFamilyId,
            int textAlign,
            int overflow,
            int maxLines) {
        buffer.start(id());
        buffer.writeInt(componentId);
        buffer.writeInt(animationId);
        buffer.writeInt(textId);
        buffer.writeInt(color);
        buffer.writeFloat(fontSize);
        buffer.writeInt(fontStyle);
        buffer.writeFloat(fontWeight);
        buffer.writeInt(fontFamilyId);
        buffer.writeInt(textAlign);
        buffer.writeInt(overflow);
        buffer.writeInt(maxLines);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int componentId = buffer.declareId();
        int animationId = buffer.declareId();
        int textId = buffer.readId();
        int color = buffer.readInt();
        float fontSize = buffer.readNanId();
        int fontStyle = buffer.readInt();
        float fontWeight = buffer.readNanId();
        int fontFamilyId = buffer.readId();
        int textAlign = buffer.readInt();
        int overflow = buffer.readInt();
        int maxLines = buffer.readInt();
        operations.add(
                new TextLayout(
                        null,
                        componentId,
                        animationId,
                        textId,
                        color,
                        fontSize,
                        fontStyle,
                        fontWeight,
                        fontFamilyId,
                        textAlign,
                        overflow,
                        maxLines));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Text Operations", id(), name())
                .description("Text layout implementation")
                .field(INT, "componentId", "Unique ID for this component")
                .field(INT, "animationId", "ID used to match components for animation purposes")
                .field(INT, "textId", "The ID of the text to display")
                .field(INT, "color", "The text color (ARGB)")
                .field(FLOAT, "fontSize", "The font size in pixels")
                .field(INT, "fontStyle", "The font style (0=normal, 1=italic)")
                .field(FLOAT, "fontWeight", "The font weight [1..1000]")
                .field(INT, "fontFamilyId", "The ID of the font family name string")
                .field(INT, "textAlign", "The text alignment and flags")
                .field(INT, "overflow", "The overflow strategy")
                .field(INT, "maxLines", "The maximum number of lines");
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(
                buffer,
                mComponentId,
                mAnimationId,
                mTextId,
                mColor,
                mFontSize,
                mFontStyle,
                mFontWeight,
                mFontFamilyId,
                mTextAlign,
                mOverflow,
                mMaxLines);
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        super.serialize(serializer);
        serializer.add("textId", mTextId);
        short flags = getFlagsFromTextAlign(mTextAlign);
        serializer.add("flags", flags);
        if (mIsDynamicColorEnabled) {
            serializer.add("color", (float) mColor, (float) mColorValue);
        } else {
            serializer.add("color", Utils.colorInt(mColorValue));
        }
        serializer.add("fontSize", mFontSize, mFontSizeValue);
        serializer.add("fontStyle", mFontStyle);
        serializer.add("fontWeight", mFontWeight);
        serializer.add("fontFamilyId", mFontFamilyId);
        serializer.add("textAlign", mTextAlign);
        serializer.add("overflow", mOverflow);
        serializer.add("maxLines", mMaxLines);
    }
}
