/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations.layout.managers;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.CoreDocument;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.operations.Header;
import androidx.compose.remote.core.operations.layout.Component;
import androidx.compose.remote.core.operations.layout.LayoutComponent;
import androidx.compose.remote.core.operations.layout.measure.ComponentMeasure;
import androidx.compose.remote.core.operations.layout.measure.MeasurePass;
import androidx.compose.remote.core.operations.layout.measure.Size;
import androidx.compose.remote.core.operations.layout.modifiers.CollapsiblePriorityModifierOperation;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class CollapsibleRowLayout extends RowLayout {

    public CollapsibleRowLayout(
            @Nullable Component parent,
            int componentId,
            int animationId,
            float x,
            float y,
            float width,
            float height,
            int horizontalPositioning,
            int verticalPositioning,
            float spacedBy) {
        super(
                parent,
                componentId,
                animationId,
                x,
                y,
                width,
                height,
                horizontalPositioning,
                verticalPositioning,
                spacedBy);
    }

    public CollapsibleRowLayout(
            @Nullable Component parent,
            int componentId,
            int animationId,
            int horizontalPositioning,
            int verticalPositioning,
            float spacedBy) {
        super(
                parent,
                componentId,
                animationId,
                horizontalPositioning,
                verticalPositioning,
                spacedBy);
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Layout Managers", id(), "CollapsibleRow")
                .additionalDocumentation("collapsible_row")
                .description("A row layout that can hide children if space is insufficient")
                .field(INT, "componentId", "Unique ID for this component")
                .field(INT, "animationId", "ID for animation purposes")
                .field(INT, "horizontalPositioning", "Horizontal positioning value")
                .field(INT, "verticalPositioning", "Vertical positioning value")
                .field(FLOAT, "spacedBy", "Horizontal spacing between components");
    }

    @NonNull
    @Override
    protected String getSerializedName() {
        return "COLLAPSIBLE_ROW";
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return Operations.LAYOUT_COLLAPSIBLE_ROW;
    }

    /**
     * Write the operation to the buffer
     *
     * @param buffer wire buffer
     * @param componentId component id
     * @param animationId animation id (-1 if not set)
     * @param horizontalPositioning horizontal positioning rules
     * @param verticalPositioning vertical positioning rules
     * @param spacedBy spaced by value
     */
    public static void apply(
            @NonNull WireBuffer buffer,
            int componentId,
            int animationId,
            int horizontalPositioning,
            int verticalPositioning,
            float spacedBy) {
        buffer.start(id());
        buffer.writeInt(componentId);
        buffer.writeInt(animationId);
        buffer.writeInt(horizontalPositioning);
        buffer.writeInt(verticalPositioning);
        buffer.writeFloat(spacedBy);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int componentId = buffer.declareId();
        int animationId = buffer.declareId();
        int horizontalPositioning = buffer.readInt();
        int verticalPositioning = buffer.readInt();
        float spacedBy = buffer.readFloat();
        operations.add(
                new CollapsibleRowLayout(
                        null,
                        componentId,
                        animationId,
                        horizontalPositioning,
                        verticalPositioning,
                        spacedBy));
    }

    @Override
    public float minIntrinsicHeight(@NonNull RemoteContext context) {
        float height = computeModifierDefinedHeight(context, true);
        if (mHeightModifier != null && mHeightModifier.isExact()) {
            return height;
        }
        if (!mChildrenComponents.isEmpty()) {
            Component c;
            if (context.useFeature(Header.FEATURE_PRIORITY_FIX)) {
                c =
                        CollapsiblePriority.findLastStanding(
                                mChildrenComponents, CollapsiblePriority.HORIZONTAL);
            } else {
                c = mChildrenComponents.get(0);
            }
            if (c != null) {
                height += c.minIntrinsicHeight(context);
            }
        }
        return height;
    }

    @Override
    public float minIntrinsicWidth(@NonNull RemoteContext context) {
        float width = computeModifierDefinedWidth(context, true);
        if (mWidthModifier != null && mWidthModifier.isExact()) {
            return width;
        }
        if (!mChildrenComponents.isEmpty()) {
            Component c;
            if (context.useFeature(Header.FEATURE_PRIORITY_FIX)) {
                c =
                        CollapsiblePriority.findLastStanding(
                                mChildrenComponents, CollapsiblePriority.HORIZONTAL);
            } else {
                c = mChildrenComponents.get(0);
            }
            if (c != null) {
                width += c.minIntrinsicWidth(context);
            }
        }
        return width;
    }

    @Override
    public boolean hasHorizontalIntrinsicDimension() {
        return true;
    }

    @Override
    public void computeWrapSize(
            @NonNull PaintContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight,
            boolean horizontalWrap,
            boolean verticalWrap,
            @NonNull MeasurePass measure,
            @NonNull Size size) {
        computeVisibleChildren(context, maxWidth, maxHeight, horizontalWrap, measure, size);
    }

    @Override
    public void computeSize(
            @NonNull PaintContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight,
            @NonNull MeasurePass measure) {
        computeVisibleChildren(context, maxWidth, maxHeight, false, measure, null);
    }

    @Override
    public void internalLayoutMeasure(@NonNull PaintContext context, @NonNull MeasurePass measure) {
        ComponentMeasure m = measure.get(this);
        computeVisibleChildren(context, m.getW(), m.getH(), false, measure, null);
        super.internalLayoutMeasure(context, measure);
    }

    private void computeVisibleChildren(
            @NonNull PaintContext context,
            float maxWidth,
            float maxHeight,
            boolean horizontalWrap,
            @NonNull MeasurePass measure,
            @Nullable Size size) {
        int visibleChildren = 0;
        ComponentMeasure self = measure.get(this);
        self.addVisibilityOverride(Visibility.OVERRIDE_VISIBLE);
        float currentMaxWidth = maxWidth;
        boolean hasPriorities = false;
        for (Component c : mChildrenComponents) {
            if (c.mNeedsMeasure || !measure.contains(c.getComponentId())) {
                // No need to remeasure here if already done
                if (c instanceof CollapsibleRowLayout) {
                    c.measure(context, 0f, currentMaxWidth, 0f, maxHeight, measure);
                } else if (c instanceof LayoutComponent
                        && ((LayoutComponent) c).getWidthModifier().hasWeight()) {
                    c.measure(context, 0f, currentMaxWidth, 0f, maxHeight, measure);
                } else {
                    c.measure(context, 0f, Float.MAX_VALUE, 0f, maxHeight, measure);
                }
            }
            ComponentMeasure m = measure.get(c);
            if (!m.isGone()) {
                if (size != null) {
                    size.setHeight(Math.max(size.getHeight(), m.getH()));
                    size.setWidth(size.getWidth() + m.getW());
                }
                visibleChildren++;
                currentMaxWidth -= m.getW();
            }
            if (c instanceof LayoutComponent) {
                LayoutComponent lc = (LayoutComponent) c;
                CollapsiblePriorityModifierOperation priority =
                        lc.selfOrModifier(CollapsiblePriorityModifierOperation.class);
                if (priority != null) {
                    hasPriorities = true;
                }
            }
        }
        if (!mChildrenComponents.isEmpty() && size != null) {
            float spacedBy = mSpacedBy;
            if (context.getDensityBehavior() == CoreDocument.DENSITY_BEHAVIOR_DP) {
                spacedBy *= context.getDensity();
            }
            size.setWidth(size.getWidth() + (spacedBy * (visibleChildren - 1)));
        }

        float childrenWidth = 0f;
        float childrenHeight = 0f;

        boolean overflow = false;
        ArrayList<Component> children = mChildrenComponents;
        if (hasPriorities) {
            // TODO: We need to cache this.
            children =
                    CollapsiblePriority.sortWithPriorities(
                            mChildrenComponents, CollapsiblePriority.HORIZONTAL);
        }
        for (Component child : children) {
            ComponentMeasure childMeasure = measure.get(child);
            if (overflow || childMeasure.isGone()) {
                childMeasure.addVisibilityOverride(Visibility.OVERRIDE_GONE);
                continue;
            }
            float childWidth = childMeasure.getW();
            boolean childDoesNotFits = childrenWidth + childWidth > maxWidth;
            if (childDoesNotFits) {
                childMeasure.addVisibilityOverride(Visibility.OVERRIDE_GONE);
                overflow = true;
            } else {
                childrenWidth += childWidth;
                childrenHeight = Math.max(childrenHeight, childMeasure.getH());
                visibleChildren++;
            }
        }
        if (horizontalWrap && size != null) {
            size.setWidth(Math.min(maxWidth, childrenWidth));
        }
        if (visibleChildren == 0 || (size != null && size.getWidth() <= 0f)) {
            self.addVisibilityOverride(Visibility.OVERRIDE_GONE);
        }
    }
}
