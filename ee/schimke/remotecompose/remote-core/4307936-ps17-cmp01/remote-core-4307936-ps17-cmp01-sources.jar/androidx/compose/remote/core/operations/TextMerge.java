/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.VariableSupport;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Operation to deal with Text data */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class TextMerge extends Operation
        implements VariableSupport, ComponentData, Serializable, VariableProvider {
    private static final int OP_CODE = Operations.TEXT_MERGE;
    private static final int MAX_TEXT_LENGTH = 16 * 1024;
    private static final String CLASS_NAME = "TextMerge";
    public int mTextId;
    public int mSrcId1;
    public int mSrcId2;

    @Override
    public int getId() {
        return mTextId;
    }

    @Override
    public void setId(int id) {
        this.mTextId = id;
    }

    public TextMerge(int textId, int srcId1, int srcId2) {
        this.mTextId = textId;
        this.mSrcId1 = srcId1;
        this.mSrcId2 = srcId2;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mTextId, mSrcId1, mSrcId2);
    }

    @NonNull
    @Override
    public String toString() {
        return "TextMerge[" + mTextId + "] = [" + mSrcId1 + " ] + [ " + mSrcId2 + "]";
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * Writes out the operation to the buffer
     *
     * @param buffer buffer to write to
     * @param textId id of the text
     * @param srcId1 source text 1
     * @param srcId2 source text 2
     */
    public static void apply(@NonNull WireBuffer buffer, int textId, int srcId1, int srcId2) {
        buffer.start(OP_CODE);
        buffer.writeInt(textId);
        buffer.writeInt(srcId1);
        buffer.writeInt(srcId2);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.declareId();
        int leftId = buffer.readId();
        int rightId = buffer.readId();
        operations.add(new TextMerge(id, leftId, rightId));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Text Operations", OP_CODE, CLASS_NAME)
                .description("Merge two strings into one")
                .field(DocumentedOperation.INT, "textId", "The ID of the resulting text")
                .field(INT, "srcId1", "The ID of the first source string")
                .field(INT, "srcId2", "The ID of the second source string");
    }

    @Override
    public void apply(@NonNull RemoteContext context) {
        String str1 = context.getText(mSrcId1);
        String str2 = context.getText(mSrcId2);
        String merge = str1 + str2;
        if (merge.length() > MAX_TEXT_LENGTH) {
            throw new RuntimeException("Text too long: " + merge.substring(0, 20) + "...");
        }
        context.loadText(mTextId, merge);
    }

    @Override
    public void updateVariables(@NonNull RemoteContext context) {
        apply(context);
    }

    @Override
    public void registerListening(@NonNull RemoteContext context) {
        context.listensTo(mSrcId1, this);
        context.listensTo(mSrcId2, this);
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + this;
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("id", mTextId)
                .add("leftId", mSrcId1)
                .add("rightId", mSrcId2);
    }
}
