/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.compose.remote.creation.compose.capture

import androidx.annotation.RestrictTo
import androidx.compose.remote.core.RcPlatformServices
import androidx.compose.runtime.Composable
import androidx.compose.runtime.NonRestartableComposable

@Composable
@NonRestartableComposable
public fun RemoteLog(
    message: String,
    category: RcPlatformServices.LogCategory = RcPlatformServices.LogCategory.WARN,
) {
    LocalRemoteComposeCreationState.current.platform.log(category, message)
}

@Composable
@NonRestartableComposable
public fun LogTodo(message: String) {
    LocalRemoteComposeCreationState.current.platform.log(
        RcPlatformServices.LogCategory.TODO,
        message,
    )
}
