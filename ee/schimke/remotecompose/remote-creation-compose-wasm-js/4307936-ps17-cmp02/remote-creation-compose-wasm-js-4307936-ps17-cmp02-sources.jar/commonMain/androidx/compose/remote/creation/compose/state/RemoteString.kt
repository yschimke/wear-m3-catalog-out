/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.state

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.common.TextTransform
import androidx.compose.remote.creation.common.Utils
import androidx.compose.remote.creation.common.AnimatedFloatExpression
import androidx.compose.remote.creation.common.IntegerExpressionEvaluator
import androidx.compose.remote.creation.compose.capture.RemoteComposeCreationContext
import androidx.compose.remote.creation.compose.state.RemoteString.Companion.createNamedRemoteString
import androidx.compose.remote.creation.compose.state.RemoteString.OperationKey
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.annotation.RememberInComposition
import androidx.compose.runtime.remember

/**
 * Abstract base class for all remote string representations.
 *
 * `RemoteString` represents a string value that can be a constant, a named variable, or a dynamic
 * expression (e.g., a concatenation).
 */
@Stable
public abstract class RemoteString internal constructor(cacheKey: RemoteStateCacheKey) :
    BaseRemoteState<String>(cacheKey) {

    internal enum class OperationKey(override val precedence: Int = 100) : RemoteOperation {
        Concat(3),
        Substring,
        Uppercase,
        Lowercase,
        Trim,
        SelectIfLT(0),
        SelectIfLE(0),
        SelectIfGT(0),
        SelectIfGE(0),
        Length,
        IsEmpty,
        IsNotEmpty;

        override fun toDebugString(args: List<RemoteStateCacheKey>): String {
            return when (this) {
                Concat -> args.formatOp("+", precedence)
                Substring -> {
                    val obj = args[0].toOperandString(precedence)
                    val params = args.joinToDebugString(startIndex = 1)
                    "$obj.substring($params)"
                }
                Uppercase -> "${args[0].toOperandString(precedence)}.uppercase()"
                Lowercase -> "${args[0].toOperandString(precedence)}.lowercase()"
                Trim -> "${args[0].toOperandString(precedence)}.trim()"
                Length -> "${args[0].toOperandString(precedence)}.length"
                IsEmpty -> "${args[0].toOperandString(precedence)}.isEmpty"
                IsNotEmpty -> "${args[0].toOperandString(precedence)}.isNotEmpty"
                SelectIfLT -> args.formatSelect("<")
                SelectIfLE -> args.formatSelect("<=")
                SelectIfGT -> args.formatSelect(">")
                SelectIfGE -> args.formatSelect(">=")
            }
        }

        override fun reconstruct(args: List<BaseRemoteState<*>>): BaseRemoteState<*> {
            return when (this) {
                Concat -> (args[0] as RemoteString) + (args[1] as RemoteString)
                Substring -> {
                    val str = args[0] as RemoteString
                    if (args.size == 3) {
                        str.substring(args[1] as RemoteInt, args[2] as RemoteInt)
                    } else {
                        str.substring(args[1] as RemoteInt)
                    }
                }
                Uppercase -> (args[0] as RemoteString).uppercase()
                Lowercase -> (args[0] as RemoteString).lowercase()
                Trim -> (args[0] as RemoteString).trim()
                Length -> (args[0] as RemoteString).length
                IsEmpty -> (args[0] as RemoteString).isEmpty
                IsNotEmpty -> (args[0] as RemoteString).isNotEmpty
                SelectIfLT -> {
                    val a = args[0]
                    val b = args[1]
                    if (a is RemoteInt && b is RemoteInt) {
                        selectIfLt(a, b, args[2] as RemoteString, args[3] as RemoteString)
                    } else {
                        selectIfLt(
                            a as RemoteFloat,
                            b as RemoteFloat,
                            args[2] as RemoteString,
                            args[3] as RemoteString,
                        )
                    }
                }
                SelectIfLE -> {
                    val a = args[0]
                    val b = args[1]
                    if (a is RemoteInt && b is RemoteInt) {
                        selectIfLe(a, b, args[2] as RemoteString, args[3] as RemoteString)
                    } else {
                        selectIfLe(
                            a as RemoteFloat,
                            b as RemoteFloat,
                            args[2] as RemoteString,
                            args[3] as RemoteString,
                        )
                    }
                }
                SelectIfGT -> {
                    val a = args[0]
                    val b = args[1]
                    if (a is RemoteInt && b is RemoteInt) {
                        selectIfGt(a, b, args[2] as RemoteString, args[3] as RemoteString)
                    } else {
                        selectIfGt(
                            a as RemoteFloat,
                            b as RemoteFloat,
                            args[2] as RemoteString,
                            args[3] as RemoteString,
                        )
                    }
                }
                SelectIfGE -> {
                    val a = args[0]
                    val b = args[1]
                    if (a is RemoteInt && b is RemoteInt) {
                        selectIfGe(a, b, args[2] as RemoteString, args[3] as RemoteString)
                    } else {
                        selectIfGe(
                            a as RemoteFloat,
                            b as RemoteFloat,
                            args[2] as RemoteString,
                            args[3] as RemoteString,
                        )
                    }
                }
            }
        }
    }

    public val length: RemoteInt
        @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP) // Restricts operator
        get() {
            constantValueOrNull?.let {
                return RemoteInt(it.length)
            }

            return RemoteIntExpression(
                constantValueOrNull = null,
                cacheKey = RemoteOperationCacheKey.create(OperationKey.Length, this),
            ) { creationState ->
                longArrayOf(
                    0x100000000L +
                        Utils.idFromNan(
                                creationState.writer.textLength(
                                    getIdForCreationState(creationState)
                                )
                            )
                            .toLong()
                )
            }
        }

    public val isEmpty: RemoteBoolean
        get() {
            constantValueOrNull?.let {
                return RemoteBoolean(it.isEmpty())
            }

            return RemoteBoolean(
                RemoteIntExpression(
                    constantValueOrNull = null,
                    cacheKey = RemoteOperationCacheKey.create(OperationKey.IsEmpty, this),
                ) { creationState ->
                    longArrayOf(
                        1,
                        0,
                        0x100000000L +
                            Utils.idFromNan(
                                    creationState.writer.textLength(
                                        getIdForCreationState(creationState)
                                    )
                                )
                                .toLong(),
                        0x100000000L + IntegerExpressionEvaluator.I_IFELSE,
                    )
                }
            )
        }

    public val isNotEmpty: RemoteBoolean
        get() {
            constantValueOrNull?.let {
                return RemoteBoolean(it.isNotEmpty())
            }

            return RemoteBoolean(
                RemoteIntExpression(
                    constantValueOrNull = null,
                    cacheKey = RemoteOperationCacheKey.create(OperationKey.IsNotEmpty, this),
                ) { creationState ->
                    longArrayOf(
                        0,
                        1,
                        0x100000000L +
                            Utils.idFromNan(
                                    creationState.writer.textLength(
                                        getIdForCreationState(creationState)
                                    )
                                )
                                .toLong(),
                        0x100000000L + IntegerExpressionEvaluator.I_IFELSE,
                    )
                }
            )
        }

    /**
     * Concatenates this [RemoteString] with another [RemoteString].
     *
     * @param v The other [RemoteString] to concatenate.
     * @return A new [MutableRemoteString] representing the concatenated string.
     */
    public operator fun plus(v: RemoteString): RemoteString {
        if (constantValueOrNull != null && v.constantValueOrNull != null) {
            return RemoteString(constantValueOrNull!! + v.constantValueOrNull!!)
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Concat, this, v),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                    creationState.writer.textMerge(
                        getIdForCreationState(creationState),
                        v.getIdForCreationState(creationState),
                    )

                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) =
                    mergeSets(
                        this@RemoteString.computeRequiredCodePointSet(creationState),
                        v.computeRequiredCodePointSet(creationState),
                    )
            },
        )
    }

    /**
     * Concatenates this [RemoteString] with a [String].
     *
     * @param v The [String] to concatenate.
     * @return A new [MutableRemoteString] representing the concatenated string.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public operator fun plus(v: String): RemoteString {
        return this + RemoteString(v)
    }

    /**
     * Returns a [RemoteString] that evaluates to a substring of this [RemoteString].
     *
     * @param start The inclusive index of the character at which the substring starts.
     * @return A new [MutableRemoteString] representing the substring.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public fun substring(start: Int): RemoteString {
        constantValueOrNull?.let {
            return RemoteString(it.substring(start))
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Substring, this, start),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                    creationState.writer.textSubtext(
                        getIdForCreationState(creationState),
                        start.toFloat(),
                        -1f,
                    )

                // TODO(b/): This is probably overestimate, consider refactoring.
                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) = this@RemoteString.computeRequiredCodePointSet(creationState)
            },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to a upper case version of this [RemoteString] using
     * the system default locale.
     *
     * @return A new [MutableRemoteString] representing the upper case version of this string.
     */
    public fun uppercase(): RemoteString {
        constantValueOrNull?.let {
            return RemoteString(it.uppercase())
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Uppercase, this),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext): Int {
                    // If the computed code points for this string are already invariant under
                    // uppercase (e.g. digits, symbols, or uppercase characters), then the
                    // transform is a NOP and can be safely elided.
                    val codePoints = this@RemoteString.computeRequiredCodePointSet(creationState)
                    if (codePoints != null && codePoints.all { it.uppercase() == it }) {
                        return this@RemoteString.getIdForCreationState(creationState)
                    }
                    return creationState.writer.textTransform(
                        getIdForCreationState(creationState),
                        0f,
                        -1f,
                        TextTransform.TEXT_TO_UPPERCASE,
                    )
                }

                // Is this correct in all locales?
                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) =
                    this@RemoteString.computeRequiredCodePointSet(creationState)?.mapTo(HashSet()) {
                        it.uppercase()
                    }
            },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to a lower case version of this [RemoteString] using
     * the system default locale.
     *
     * @return A new [MutableRemoteString] representing the lower case version of this string.
     */
    public fun lowercase(): RemoteString {
        constantValueOrNull?.let {
            return RemoteString(it.lowercase())
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Lowercase, this),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext): Int {
                    // If the computed code points for this string are already invariant under
                    // lowercase (e.g. digits, symbols, or lowercase characters), then the
                    // transform is a NOP and can be safely elided.
                    val codePoints = this@RemoteString.computeRequiredCodePointSet(creationState)
                    if (codePoints != null && codePoints.all { it.lowercase() == it }) {
                        return this@RemoteString.getIdForCreationState(creationState)
                    }
                    return creationState.writer.textTransform(
                        getIdForCreationState(creationState),
                        0f,
                        -1f,
                        TextTransform.TEXT_TO_LOWERCASE,
                    )
                }

                // Is this correct in all locales?
                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) =
                    this@RemoteString.computeRequiredCodePointSet(creationState)?.mapTo(HashSet()) {
                        it.lowercase()
                    }
            },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to the trimmed version of this this [RemoteString]
     * where leading and trailing whitespace characters have been removed.
     *
     * @return A new [MutableRemoteString] representing the trimmed version of this string.
     */
    public fun trim(): RemoteString {
        constantValueOrNull?.let {
            return RemoteString(it.trim())
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Trim, this),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                    creationState.writer.textTransform(
                        getIdForCreationState(creationState),
                        0f,
                        -1f,
                        TextTransform.TEXT_TRIM,
                    )

                // This is likely an overestimate, but whitespace glyphs are typically encoded as
                // a space so optimizing doesn't seem worthwhile.
                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) = this@RemoteString.computeRequiredCodePointSet(creationState)
            },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to a substring of this [RemoteString]. The substring
     * starts at a dynamic [start] index (represented by a [RemoteInt]) and extends to the end of
     * the string.
     *
     * @param start The [RemoteInt] representing the inclusive index of the character at which the
     *   substring starts.
     * @return A new [MutableRemoteString] representing the substring.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public fun substring(start: RemoteInt): RemoteString {
        val constV = constantValueOrNull
        val constStart = start.constantValueOrNull
        if (constV != null && constStart != null) {
            return RemoteString(constV.substring(constStart))
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Substring, this, start),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                    creationState.writer.textSubtext(
                        getIdForCreationState(creationState),
                        start.getFloatIdForCreationState(creationState),
                        -1f,
                    )

                // TODO(b/): This is probably overestimate, consider refactoring.
                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) = this@RemoteString.computeRequiredCodePointSet(creationState)
            },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to a substring of this [RemoteString]. The substring
     * starts at a fixed [start] index and ends before a fixed [end] index.
     *
     * @param start The inclusive index of the character at which the substring starts.
     * @param end The exclusive index after the last character of the substring.
     * @return A new [MutableRemoteString] representing the substring.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public fun substring(start: Int, end: Int): RemoteString {
        constantValueOrNull?.let {
            return RemoteString(it.substring(start, end))
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Substring, this, start, end),
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                    creationState.writer.textSubtext(
                        getIdForCreationState(creationState),
                        start.toFloat(),
                        (end - start).toFloat(),
                    )

                // TODO(b/): This is probably overestimate, consider refactoring.
                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) = this@RemoteString.computeRequiredCodePointSet(creationState)
            },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to a substring of this [RemoteString]. The substring
     * starts at a fixed [start] index and ends before a dynamic [end] index.
     *
     * @param start The inclusive index of the character at which the substring starts.
     * @param end The [RemoteInt] representing the exclusive index after the last character of the
     *   substring.
     * @return A new [MutableRemoteString] representing the substring.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public fun substring(start: Int, end: RemoteInt): RemoteString {
        val constV = constantValueOrNull
        val constEnd = end.constantValueOrNull
        if (constV != null && constEnd != null) {
            return RemoteString(constV.substring(start, constEnd))
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Substring, this, start, end),
            lazyRemoteString =
                object : LazyRemoteString {
                    override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                        creationState.writer.textSubtext(
                            getIdForCreationState(creationState),
                            start.getFloatIdForCreationState(creationState),
                            (end - start).getFloatIdForCreationState(creationState),
                        )

                    // TODO(b/): This is probably overestimate, consider refactoring.
                    override fun computeRequiredCodePointSet(
                        creationState: RemoteComposeCreationContext
                    ) = this@RemoteString.computeRequiredCodePointSet(creationState)
                },
        )
    }

    /**
     * Returns a [RemoteString] that evaluates to a substring of this [RemoteString]. Both the
     * [start] and [end] indices are dynamic, represented by [RemoteInt]s.
     *
     * @param start The [RemoteInt] representing the inclusive index of the character at which the
     *   substring starts.
     * @param end The [RemoteInt] representing the exclusive index after the last character of the
     *   substring.
     * @return A new [MutableRemoteString] representing the substring.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public fun substring(start: RemoteInt, end: RemoteInt): RemoteString {
        val constV = constantValueOrNull
        val constStart = start.constantValueOrNull
        val constEnd = end.constantValueOrNull
        if (constV != null && constStart != null && constEnd != null) {
            return RemoteString(constV.substring(constStart, constEnd))
        }

        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Substring, this, start, end),
            lazyRemoteString =
                object : LazyRemoteString {
                    override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                        creationState.writer.textSubtext(
                            getIdForCreationState(creationState),
                            start.getFloatIdForCreationState(creationState),
                            (end - start).getFloatIdForCreationState(creationState),
                        )

                    // TODO(b/): This is probably overestimate, consider refactoring.
                    override fun computeRequiredCodePointSet(
                        creationState: RemoteComposeCreationContext
                    ) = this@RemoteString.computeRequiredCodePointSet(creationState)
                },
        )
    }

    /**
     * Attempts to compute the set of unicode code points that can occur in this string, or null if
     * that can\'t be statically determined (e.g. named strings rely on external state).
     *
     * This is useful if you need to compute the subset of a font that\'s required to render the
     * string.
     *
     * @param creationState The [RemoteComposeCreationContext] context this is being evaluated within.
     * @return The set of unicode code points that can occur in this string, or null if that can\'t
     *   be statically determined .
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public abstract fun computeRequiredCodePointSet(
        creationState: RemoteComposeCreationContext
    ): Set<String>?

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public companion object {
        /**
         * Creates a [RemoteString] instance from a constant [String] literal.
         *
         * @param value The constant [String] value.
         * @return A [MutableRemoteString] representing the constant string.
         */
        @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
        public operator fun invoke(value: String): RemoteString {
            return MutableRemoteString(
                constantValueOrNull = value,
                cacheKey = RemoteConstantCacheKey(value),
                object : LazyRemoteString {
                    override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                        creationState.writer.addText(value)

                    override fun computeRequiredCodePointSet(
                        creationState: RemoteComposeCreationContext
                    ) = value.toCodePointSet()
                },
            )
        }

        /**
         * Creates a [RemoteString] referencing a remote ID.
         *
         * @param id The remote ID.
         * @return A [RemoteString] referencing the ID.
         */
        @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
        public fun createForId(id: Int): RemoteString = MutableRemoteString(id)

        /**
         * Creates a named [RemoteString] with an initial value.
         *
         * @param name A unique name to identify this state within its [domain].
         * @param defaultValue The initial [String] value for the named remote string.
         * @param domain The domain for the named state. Defaults to [RemoteState.Domain.User].
         * @return A [RemoteString] representing the named string.
         */
        public fun createNamedRemoteString(
            name: String,
            defaultValue: String,
            domain: RemoteState.Domain = RemoteState.Domain.User,
        ): RemoteString {
            return MutableRemoteString(
                constantValueOrNull = null,
                cacheKey = RemoteNamedCacheKey(domain, name),
                object : LazyRemoteString {
                    override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                        creationState.writer.addNamedString(domain.prefixed(name), defaultValue)

                    // Named strings can change so we can't statically determine the needed glyphs
                    override fun computeRequiredCodePointSet(
                        creationState: RemoteComposeCreationContext
                    ) = null
                },
            )
        }
    }
}

private class SelectFloatImpl(
    val a: RemoteFloat,
    val b: RemoteFloat,
    val ifTrue: RemoteString,
    val ifFalse: RemoteString,
) : LazyRemoteString {
    override fun reserveTextId(creationState: RemoteComposeCreationContext): Int {
        val select =
            RemoteFloatExpression(
                constantValueOrNull = null,
                cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfLT, a, b),
            ) { creationState2 ->
                floatArrayOf(
                    1f,
                    0f,
                    a.getFloatIdForCreationState(creationState2),
                    b.getFloatIdForCreationState(creationState2),
                    AnimatedFloatExpression.SUB,
                    AnimatedFloatExpression.IFELSE,
                )
            }
        return creationState.writer.textLookup(
            creationState.writer.addIdList(
                intArrayOf(
                    ifFalse.getIdForCreationState(creationState),
                    ifTrue.getIdForCreationState(creationState),
                )
            ),
            select.getIdForCreationState(creationState),
        )
    }

    override fun computeRequiredCodePointSet(
        creationState: RemoteComposeCreationContext
    ): Set<String>? {
        if (a.hasConstantValue && b.hasConstantValue) {
            val selected = if (a.constantValue < b.constantValue) ifTrue else ifFalse
            return selected.computeRequiredCodePointSet(creationState)
        }
        return mergeSets(
            ifTrue.computeRequiredCodePointSet(creationState),
            ifFalse.computeRequiredCodePointSet(creationState),
        )
    }
}

private class SelectIntImpl(
    val a: RemoteInt,
    val b: RemoteInt,
    val ifTrue: RemoteString,
    val ifFalse: RemoteString,
) : LazyRemoteString {
    override fun reserveTextId(creationState: RemoteComposeCreationContext): Int {
        val select =
            RemoteIntExpression(
                constantValueOrNull = null,
                cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfLT, a, b),
            ) { creationState2 ->
                longArrayOf(
                    1,
                    0,
                    0x100000000L + a.getIdForCreationState(creationState2).toLong(),
                    0x100000000L + b.getIdForCreationState(creationState2).toLong(),
                    0x100000000L + IntegerExpressionEvaluator.I_SUB,
                    0x100000000L + IntegerExpressionEvaluator.I_IFELSE,
                )
            }
        return creationState.writer.textLookup(
            creationState.writer.addIdList(
                intArrayOf(
                    ifFalse.getIdForCreationState(creationState),
                    ifTrue.getIdForCreationState(creationState),
                )
            ),
            select.getIdForCreationState(creationState),
        )
    }

    override fun computeRequiredCodePointSet(
        creationState: RemoteComposeCreationContext
    ): Set<String>? {
        if (a.hasConstantValue && b.hasConstantValue) {
            val selected = if (a.constantValue < b.constantValue) ifTrue else ifFalse
            return selected.computeRequiredCodePointSet(creationState)
        }
        return mergeSets(
            ifTrue.computeRequiredCodePointSet(creationState),
            ifFalse.computeRequiredCodePointSet(creationState),
        )
    }
}

/**
 * Returns a [RemoteFloat] that evaluates to [ifTrue] if [a] is less than [b], otherwise returns
 * [ifFalse].
 *
 * @param a The left-hand side [RemoteFloat] for the less-than comparison.
 * @param b The right-hand side [RemoteFloat] for the less-than comparison.
 * @param ifTrue The [RemoteFloat] expression to return if `a < b` evaluates to true.
 * @param ifFalse The [RemoteFloat] expression to return if `a < b` evaluates to false.
 * @return A new [RemoteFloat] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfLt(
    a: RemoteFloat,
    b: RemoteFloat,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA < constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfLT, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectFloatImpl(b, a, ifFalse, ifTrue),
    )
}

/**
 * Returns a [RemoteInt] that evaluates to [ifTrue] if [a] is less than [b], otherwise returns
 * [ifFalse].
 *
 * @param a The left-hand side [RemoteInt] for the less-than comparison.
 * @param b The right-hand side [RemoteInt] for the less-than comparison.
 * @param ifTrue The [RemoteInt] expression to return if `a < b` evaluates to true.
 * @param ifFalse The [RemoteInt] expression to return if `a < b` evaluates to false.
 * @return A new [RemoteInt] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfLt(
    a: RemoteInt,
    b: RemoteInt,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA < constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfLT, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectIntImpl(b, a, ifFalse, ifTrue),
    )
}

/**
 * Returns a [RemoteFloat] that evaluates to [ifTrue] if [a] is less than or equal to [b], otherwise
 * returns [ifFalse].
 *
 * @param a The left-hand side [RemoteFloat] for the comparison.
 * @param b The right-hand side [RemoteFloat] for the comparison.
 * @param ifTrue The [RemoteFloat] expression to return if `a <= b` evaluates to true.
 * @param ifFalse The [RemoteFloat] expression to return if `a <= b` evaluates to false.
 * @return A new [RemoteFloat] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfLe(
    a: RemoteFloat,
    b: RemoteFloat,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA <= constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfLE, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectFloatImpl(a, b, ifTrue, ifFalse),
    )
}

/**
 * Returns a [RemoteInt] that evaluates to [ifTrue] if [a] is less than or equal to [b], otherwise
 * returns [ifFalse].
 *
 * @param a The left-hand side [RemoteInt] for the comparison.
 * @param b The right-hand side [RemoteInt] for the comparison.
 * @param ifTrue The [RemoteInt] expression to return if `a <= b` evaluates to true.
 * @param ifFalse The [RemoteInt] expression to return if `a <= b` evaluates to false.
 * @return A new [RemoteInt] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfLe(
    a: RemoteInt,
    b: RemoteInt,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA <= constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfLE, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectIntImpl(a, b, ifTrue, ifFalse),
    )
}

/**
 * Returns a [RemoteFloat] that evaluates to [ifTrue] if [a] is greater than [b], otherwise returns
 * [RemoteFloat].
 *
 * @param a The left-hand side [RemoteFloat] for the comparison.
 * @param b The right-hand side [RemoteFloat] for the comparison.
 * @param ifTrue The [RemoteFloat] expression to return if `a > b` evaluates to true.
 * @param ifFalse The [RemoteFloat] expression to return if `a > b` evaluates to false.
 * @return A new [RemoteFloat] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfGt(
    a: RemoteFloat,
    b: RemoteFloat,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA > constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfGT, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectFloatImpl(a, b, ifFalse, ifTrue),
    )
}

/**
 * Returns a [RemoteInt] that evaluates to [ifTrue] if [a] is greater than [b], otherwise returns
 * [ifFalse].
 *
 * @param a The left-hand side [RemoteInt] for the comparison.
 * @param b The right-hand side [RemoteInt] for the comparison.
 * @param ifTrue The [RemoteInt] expression to return if `a > b` evaluates to true.
 * @param ifFalse The [RemoteInt] expression to return if `a > b` evaluates to false.
 * @return A new [RemoteInt] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfGt(
    a: RemoteInt,
    b: RemoteInt,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA > constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfGT, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectIntImpl(a, b, ifFalse, ifTrue),
    )
}

/**
 * Returns a [RemoteFloat] that evaluates to [ifTrue] if [a] is greater than or equal to [b],
 * otherwise returns [ifFalse].
 *
 * @param a The left-hand side [RemoteFloat] for the comparison.
 * @param b The right-hand side [RemoteFloat] for the comparison.
 * @param ifTrue The [RemoteFloat] expression to return if `a >= b` evaluates to true.
 * @param ifFalse The [RemoteFloat] expression to return if `a >= b` evaluates to false.
 * @return A new [RemoteFloat] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfGe(
    a: RemoteFloat,
    b: RemoteFloat,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA >= constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfGE, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectFloatImpl(b, a, ifTrue, ifFalse),
    )
}

/**
 * Returns a [RemoteInt] that evaluates to [ifTrue] if [a] is greater than or equal to [b],
 * otherwise returns [ifFalse].
 *
 * @param a The left-hand side [RemoteInt] for the comparison.
 * @param b The right-hand side [RemoteInt] for the comparison.
 * @param ifTrue The [RemoteInt] expression to return if `a >= b` evaluates to true.
 * @param ifFalse The [RemoteInt] expression to return if `a >= b` evaluates to false.
 * @return A new [RemoteInt] representing the selected value, evaluated remotely.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun selectIfGe(
    a: RemoteInt,
    b: RemoteInt,
    ifTrue: RemoteString,
    ifFalse: RemoteString,
): RemoteString {
    val constA = a.constantValueOrNull
    val constB = b.constantValueOrNull
    if (constA != null && constB != null) {
        return if (constA >= constB) {
            ifTrue
        } else {
            ifFalse
        }
    }

    return MutableRemoteString(
        constantValueOrNull = null,
        cacheKey = RemoteOperationCacheKey.create(OperationKey.SelectIfGE, a, b, ifTrue, ifFalse),
        lazyRemoteString = SelectIntImpl(b, a, ifTrue, ifFalse),
    )
}

internal interface LazyRemoteString {
    /**
     * @return The text ID for the RemoteString within the provided [RemoteComposeCreationContext].
     */
    public fun reserveTextId(creationState: RemoteComposeCreationContext): Int

    /**
     * @return The set of unicode code points needed to render this string, or null if that can\'t
     *   be statically determined.
     */
    public fun computeRequiredCodePointSet(creationState: RemoteComposeCreationContext): Set<String>?
}

/** @return The string split up into a set of unicode code points. */
internal fun String.toCodePointSet(): Set<String> {
    val s = HashSet<String>()
    var index = 0
    while (index < length) {
        val first = this[index]
        if (first.isHighSurrogate() && index + 1 < length && this[index + 1].isLowSurrogate()) {
            s.add(substring(index, index + 2))
            index += 2
        } else {
            s.add(first.toString())
            index++
        }
    }
    return s
}

internal fun mergeSets(a: Set<String>?, b: Set<String>?): Set<String>? {
    if (a == null || b == null) {
        return null
    }
    return a + b
}

/** An implementation of [RemoteString] that holds its value in a [MutableState<String>]. */
public class MutableRemoteString
@RememberInComposition
internal constructor(
    @get:Suppress("AutoBoxing") public override val constantValueOrNull: String?,
    cacheKey: RemoteStateCacheKey,
    private val lazyRemoteString: LazyRemoteString,
) : RemoteString(cacheKey), MutableRemoteState<String> {

    /** Create a MutableRemoteString from an existing id. */
    @RememberInComposition
    internal constructor(
        id: Int
    ) : this(
        constantValueOrNull = null,
        cacheKey = RemoteStateIdKey(id),
        lazyRemoteString =
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) = id

                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) = null
            },
    )

    /**
     * Create a MutableRemoteString for a default value.
     *
     * @param value The initial [String] value.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @RememberInComposition
    public constructor(
        value: String
    ) : this(
        constantValueOrNull = null,
        cacheKey = RemoteStateInstanceKey(),
        lazyRemoteString =
            object : LazyRemoteString {
                override fun reserveTextId(creationState: RemoteComposeCreationContext) =
                    creationState.writer.addText(value)

                override fun computeRequiredCodePointSet(
                    creationState: RemoteComposeCreationContext
                ) = null
            },
    )

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public override fun writeToDocument(creationState: RemoteComposeCreationContext): Int =
        lazyRemoteString.reserveTextId(creationState)

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public override fun computeRequiredCodePointSet(
        creationState: RemoteComposeCreationContext
    ): Set<String>? = lazyRemoteString.computeRequiredCodePointSet(creationState)

    public companion object {
        /**
         * Creates a new mutable state (allocates an ID).
         *
         * @param initialValue The initial value for the state.
         * @return A new [MutableRemoteString] instance.
         */
        public operator fun invoke(initialValue: String): MutableRemoteString =
            MutableRemoteString(initialValue)

        /**
         * Maps an existing mutable ID to a state instance.
         *
         * @param id The existing mutable ID.
         * @return A [MutableRemoteString] instance mapping to the ID.
         */
        internal fun createMutableForId(id: Int): MutableRemoteString = MutableRemoteString(id)
    }
}

/**
 * Factory composable for mutable remote string state.
 *
 * @param initialValue The initial [String] value.
 * @return A [MutableRemoteString] instance that will be remembered across recompositions.
 */
@Composable
public fun rememberMutableRemoteString(initialValue: String): MutableRemoteString {
    return remember { MutableRemoteString(initialValue) }
}

/**
 * Remembers a named remote string expression.
 *
 * @param name The unique name for this remote string.
 * @param domain The domain of the named string (defaults to [RemoteState.Domain.User]).
 * @param defaultValue The initial [String] value for this remote string.
 * @return A [RemoteString] representing the named remote string expression.
 */
@Composable
public fun rememberNamedRemoteString(
    name: String,
    defaultValue: String,
    domain: RemoteState.Domain = RemoteState.Domain.User,
): RemoteString {
    return remember(name, domain) { createNamedRemoteString(name, defaultValue, domain) }
}

/** Extension property to convert a [String] to a [RemoteString]. */
public val String.rs: RemoteString
    get() {
        return RemoteString(this)
    }
