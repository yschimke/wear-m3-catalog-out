/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.compose.remote.creation.compose.modifier

import androidx.annotation.RestrictTo
import androidx.compose.foundation.MarqueeSpacing
import androidx.compose.remote.creation.compose.state.RemoteStateScope
import androidx.compose.remote.creation.common.RemoteModifierOperation

/**
 * A modifier that animates the text content to scroll across the screen like a marquee.
 *
 * @param iterations The number of times to repeat the animation. Int.MAX_VALUE will repeat forever,
 *   and 0 will disable animation.
 * @param animationMode Whether the marquee should start animating Immediately or only WhileFocused.
 *   In WhileFocused mode, the modified node or the content must be made focusable. Note that the
 *   initialDelayMillis is part of the animation, so this parameter determines when that initial
 *   delay starts counting down, not when the content starts to actually scroll.
 * @param repeatDelayMillis The duration to wait before starting each subsequent iteration, in
 *   millis.
 * @param initialDelayMillis The duration to wait before starting the first iteration of the
 *   animation, in millis. By default, there will be no initial delay if animationMode is
 *   WhileFocused, otherwise the initial delay will be repeatDelayMillis.
 * @param spacing A [MarqueeSpacing] that specifies how much space to leave at the end of the
 *   content before showing the beginning again.
 * @param velocity The speed of the animation in dps / second.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class MarqueeModifier(
    public val iterations: Int,
    public val animationMode: Int,
    public val repeatDelayMillis: Float,
    public val initialDelayMillis: Float,
    public val spacing: Float,
    public val velocity: Float,
) : RemoteModifier.Element {

    override fun RemoteStateScope.toRemoteModifierOperation(): RemoteModifierOperation =
        RemoteModifierOperation.Marquee(
            iterations,
            animationMode,
            repeatDelayMillis,
            initialDelayMillis,
            spacing,
            velocity,
        )
}

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun RemoteModifier.basicMarquee(
    iterations: Int = Int.MAX_VALUE,
    animationMode: Int = 0,
    repeatDelayMillis: Float = 0f,
    initialDelayMillis: Float = 0f,
    spacing: Float = 0f,
    velocity: Float = 20f,
): RemoteModifier =
    then(
        MarqueeModifier(
            iterations,
            animationMode,
            repeatDelayMillis,
            initialDelayMillis,
            spacing,
            velocity,
        )
    )
