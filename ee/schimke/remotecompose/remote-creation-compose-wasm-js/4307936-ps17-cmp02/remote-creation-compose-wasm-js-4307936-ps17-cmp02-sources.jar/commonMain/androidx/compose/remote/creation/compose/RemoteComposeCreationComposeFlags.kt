/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose

/**
 * This is a collection of flags which are used to guard against regressions in some of the
 * "riskier" refactors or new feature support that is added to this module. These flags are always
 * "off" in the published artifact of this module, however these flags allow end consumers of this
 * module to toggle them "on" in case this new path is causing a regression.
 *
 * These flags are considered temporary, and there should be no expectation for these flags be
 * around for an extended period of time. If you have a regression that one of these flags fixes, it
 * is strongly encouraged for you to file a bug ASAP.
 *
 * **Usage:**
 *
 * In order to turn a feature off in a debug environment, it is recommended to set this to false in
 * as close to the initial loading of the application as possible. Changing this value after compose
 * library code has already been loaded can result in undefined behavior.
 *
 *      class MyApplication : Application() {
 *          override fun onCreate() {
 *              RemoteComposeCreationComposeFlags.SomeFeatureEnabled = true
 *              super.onCreate()
 *          }
 *      }
 *
 * In order to turn this off in a release environment, it is recommended to additionally utilize R8
 * rules which force a single value for the entire build artifact. This can result in the new code
 * paths being completely removed from the artifact, which can often have nontrivial positive
 * performance impact.
 *
 *      -assumevalues class androidx.compose.remote.creation.compose.RemoteComposeCreationComposeFlags {
 *          public static boolean SomeFeatureEnabled return false
 *      }
 */
@ExperimentalRemoteCreationComposeApi
public object RemoteComposeCreationComposeFlags {
    /**
     * When true, stops anything writing to the document (RemoteComposeWriter) before the
     * composition has settled. This ensures that documents are not partially written during
     * recomposition.
     */
    // TODO: b/503644761
    @field:Suppress("MutableBareField")
    public var isEnforceCleanRecompositionEnabled: Boolean = true

    /**
     * When true, it is allowed for empty font axis to be sent when no font variation settings are
     * specified. When false, falls back to a default weight 400 (Normal) to work around a crash.
     */
    // TODO: b/512099041
    @field:Suppress("MutableBareField")
    public var allowSendingEmptyFontAxis: Boolean = true
}
