/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.state

import androidx.compose.remote.creation.common.RemoteContext
import androidx.compose.remote.creation.compose.capture.RemoteComposeCreationContext
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

/**
 * Represents a key used for caching [BaseRemoteState] instances or expressions in
 * [androidx.compose.remote.creation.compose.capture.RemoteComposeCreationContext].
 *
 * Caching based on these keys prevents redundant operations and document writes when the same
 * expression or state is encountered multiple times during document creation.
 */
@Immutable
internal interface RemoteStateCacheKey {
    /** The child argument cache keys of this node in the AST DAG. Empty for leaf nodes. */
    val args: List<RemoteStateCacheKey>
        get() = emptyList()

    fun toDebugString(): String

    /**
     * Traverses this [RemoteStateCacheKey] DAG using the provided [visitor].
     *
     * @param visitor The visitor that inspects each node.
     * @param memo A memoization map to ensure shared DAG nodes are visited once.
     * @return The result of visiting this node.
     */
    fun <R> accept(
        visitor: RemoteStateVisitor<R>,
        memo: MutableMap<RemoteStateCacheKey, R> = mutableMapOf(),
    ): R
}

internal fun List<RemoteStateCacheKey>.joinToDebugString(
    separator: String = ", ",
    startIndex: Int = 0,
): String = buildString {
    for (i in startIndex until this@joinToDebugString.size) {
        if (i > startIndex) {
            append(separator)
        }
        append(this@joinToDebugString[i].toDebugString())
    }
}

internal fun List<RemoteStateCacheKey>.formatOp(opSymbol: String, precedence: Int) =
    this[0].toOperandString(precedence) +
        " $opSymbol " +
        this[1].toOperandString(precedence, isRightOperand = true)

internal fun List<RemoteStateCacheKey>.formatArrayAccess(precedence: Int) =
    this[0].toOperandString(precedence) + "[" + this[1].toDebugString() + "]"

internal fun List<RemoteStateCacheKey>.formatSelect(opSymbol: String): String {
    val cond =
        "${this[0].toOperandString(1)} $opSymbol " +
            this[1].toOperandString(1, isRightOperand = true)
    val trueBranch = this[2].toOperandString(0, isRightOperand = true)
    val falseBranch = this[3].toOperandString(0, isRightOperand = true)
    return "$cond ? $trueBranch : $falseBranch"
}

internal fun List<String>.fastJoinToString(separator: String = ", "): String = buildString {
    for (i in this@fastJoinToString.indices) {
        if (i > 0) {
            append(separator)
        }
        append(this@fastJoinToString[i])
    }
}

internal fun Enum<*>.formatCamelCaseFunction(args: List<RemoteStateCacheKey>): String =
    "${name.replaceFirstChar { it.lowercase() }}(${args.joinToDebugString()})"

/**
 * Interface implemented by remote operation keys (e.g. `RemoteFloat.OperationKey`) to define
 * precedence, custom AST debug formatting (e.g. `user:a + user:b`), and AST node reconstruction.
 */
internal interface RemoteOperation {
    val precedence: Int
        get() = 100

    /** Formats this operation AST using its evaluated operand [args]. */
    fun toDebugString(args: List<RemoteStateCacheKey>): String

    /**
     * Reconstructs the [BaseRemoteState] operation using the new [args].
     *
     * @param args The transformed argument list of [BaseRemoteState] instances.
     * @return The reconstructed [BaseRemoteState] instance.
     */
    fun reconstruct(args: List<BaseRemoteState<*>>): BaseRemoteState<*> =
        throw UnsupportedOperationException("Reconstruction is not supported for $this")
}

/**
 * Formats this cache key as an operand string within an outer operation.
 *
 * If this key represents a nested operation whose [RemoteOperation.precedence] is lower than
 * [parentPrecedence] (or equal, if [isRightOperand] is true), the resulting debug string is wrapped
 * in parentheses to accurately preserve evaluation order and associativity.
 */
internal fun RemoteStateCacheKey.toOperandString(
    parentPrecedence: Int,
    isRightOperand: Boolean = false,
): String {
    val str = toDebugString()
    if (this is RemoteOperationCacheKey) {
        val childOp = op as? RemoteOperation
        if (childOp != null) {
            val needsParentheses =
                childOp.precedence < parentPrecedence ||
                    (childOp.precedence == parentPrecedence && isRightOperand) ||
                    (childOp.precedence == 0 && parentPrecedence == 0)
            if (needsParentheses) {
                return "($str)"
            }
        }
    }
    return str
}

/** Base class for [RemoteStateCacheKey] implementations that provides a memoized [hashCode]. */
internal abstract class BaseRemoteStateCacheKey : RemoteStateCacheKey {
    private var _hashCode: Int = 0

    /**
     * Associated BaseRemoteState instance, used for common sub-expression elimination and DAG
     * traversal. Default implementation returns null. Note to save memory this deliberately doesn't
     * have a backing field because not all sub-classes need it.
     */
    internal open fun getState(): BaseRemoteState<*>? = null

    /**
     * Associates this key with a BaseRemoteState instance. Default implementation is a no-op to
     * avoid allocating backing fields on keys that do not retain state.
     */
    internal open fun setState(state: BaseRemoteState<*>?) {}

    override fun <R> accept(
        visitor: RemoteStateVisitor<R>,
        memo: MutableMap<RemoteStateCacheKey, R>,
    ): R {
        memo[this]?.let {
            return it
        }
        val visitedArgs = ArrayList<R>(args.size)
        for (i in args.indices) {
            visitedArgs.add(args[i].accept(visitor, memo))
        }
        val result = visitor.visit(this, getState(), visitedArgs)
        memo[this] = result
        return result
    }

    final override fun hashCode(): Int {
        if (_hashCode == 0) {
            _hashCode = hashCodeImpl()
            if (_hashCode == 0) _hashCode = 1
        }
        return _hashCode
    }

    protected abstract fun hashCodeImpl(): Int

    abstract override fun equals(other: Any?): Boolean
}

/** A fallback cache key based on the identity of this key instance. */
internal class RemoteStateInstanceKey : BaseRemoteStateCacheKey() {
    private val identity = Any().hashCode()
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun hashCodeImpl(): Int = identity

    override fun equals(other: Any?): Boolean = this === other

    override fun toDebugString(): String = "instance"
}

internal class RemoteStateArrayKey(internal val size: Int) : BaseRemoteStateCacheKey() {
    private val identity = Any().hashCode()
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun hashCodeImpl(): Int = identity

    override fun equals(other: Any?): Boolean = this === other

    override fun toDebugString(): String = "mutableFloatArray(size=$size)"
}

/** A cache key for constant values (primitive types, strings, etc.). */
internal class RemoteConstantCacheKey(internal val value: Any?) : BaseRemoteStateCacheKey() {
    init {
        if (value is Float) {
            check(!value.isNaN()) { "Float constant value cannot be NaN" }
        }
        if (value is Double) {
            check(!value.isNaN()) { "Double constant value cannot be NaN" }
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RemoteConstantCacheKey) return false
        if (value != other.value) return false
        return true
    }

    override fun hashCodeImpl(): Int =
        when (value) {
            // Enums inherit java.lang.Object.hashCode() (identity hash code), which is
            // non-deterministic across JVM executions. We hash the declaring class name and
            // constant name to ensure determinism.
            is Enum<*> -> value::class.simpleName.hashCode() + value.name.hashCode()
            else -> value?.hashCode() ?: 0
        }

    override fun toString(): String = "RemoteConstantCacheKey(value=$value)"

    override fun toDebugString(): String =
        when (value) {
            null -> "null"
            is String -> "\"$value\""
            is Enum<*> -> "${value::class.simpleName}.${value.name}"
            else -> value.toString()
        }
}

/** A cache key for named variables, identified by their [name] and [domain]. */
internal class RemoteNamedCacheKey(
    internal val domain: RemoteState.Domain,
    internal val name: String,
) : BaseRemoteStateCacheKey() {
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RemoteNamedCacheKey) return false
        if (domain != other.domain) return false
        if (name != other.name) return false
        return true
    }

    override fun hashCodeImpl(): Int {
        var result = domain.hashCode()
        result = 31 * result + name.hashCode()
        return result
    }

    override fun toString(): String = "RemoteNamedCacheKey(domain=$domain, name=$name)"

    override fun toDebugString(): String = "${domain.prefix.lowercase()}$name"
}

/**
 * A cache key for themed colors, identified by their [group], [lightModeIndex], [darkModeIndex],
 * [lightFallback], and [darkFallback].
 */
internal class RemoteStateThemeColorKey(
    internal val group: String,
    internal val lightModeIndex: Short,
    internal val darkModeIndex: Short,
    internal val lightFallback: Color,
    internal val darkFallback: Color,
) : BaseRemoteStateCacheKey() {
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RemoteStateThemeColorKey) return false
        if (group != other.group) return false
        if (lightModeIndex != other.lightModeIndex) return false
        if (darkModeIndex != other.darkModeIndex) return false
        if (lightFallback != other.lightFallback) return false
        if (darkFallback != other.darkFallback) return false
        return true
    }

    override fun hashCodeImpl(): Int {
        var result = group.hashCode()
        result = 31 * result + lightModeIndex.hashCode()
        result = 31 * result + darkModeIndex.hashCode()
        result = 31 * result + lightFallback.hashCode()
        result = 31 * result + darkFallback.hashCode()
        return result
    }

    override fun toString(): String =
        "RemoteStateThemeColorKey(group=$group, lightModeIndex=$lightModeIndex, darkModeIndex=$darkModeIndex, lightFallback=$lightFallback, darkFallback=$darkFallback)"

    override fun toDebugString(): String =
        "themeColor($group, light=$lightModeIndex, dark=$darkModeIndex)"
}

/** A cache key for variable by id. */
internal class RemoteStateIdKey(internal val id: Int) : BaseRemoteStateCacheKey() {
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RemoteStateIdKey) return false
        if (id != other.id) return false
        return true
    }

    override fun hashCodeImpl(): Int = id

    override fun toString(): String = "RemoteStateIdKey(id=$id)"

    override fun toDebugString(): String {
        return when (id) {
            RemoteContext.ID_CONTINUOUS_SEC -> "context:continuous_sec"
            RemoteContext.ID_TIME_IN_SEC -> "context:time_in_sec"
            RemoteContext.ID_TIME_IN_MIN -> "context:time_in_min"
            RemoteContext.ID_TIME_IN_HR -> "context:time_in_hr"
            RemoteContext.ID_WINDOW_WIDTH -> "context:window_width"
            RemoteContext.ID_WINDOW_HEIGHT -> "context:window_height"
            RemoteContext.ID_COMPONENT_WIDTH -> "context:component_width"
            RemoteContext.ID_COMPONENT_HEIGHT -> "context:component_height"
            RemoteContext.ID_CALENDAR_MONTH -> "context:calendar_month"
            RemoteContext.ID_OFFSET_TO_UTC -> "context:offset_to_utc"
            RemoteContext.ID_WEEK_DAY -> "context:week_day"
            RemoteContext.ID_DAY_OF_MONTH -> "context:day_of_month"
            RemoteContext.ID_DAY_OF_YEAR -> "context:day_of_year"
            RemoteContext.ID_YEAR -> "context:year"
            RemoteContext.ID_TOUCH_POS_X -> "context:touch_pos_x"
            RemoteContext.ID_TOUCH_POS_Y -> "context:touch_pos_y"
            RemoteContext.ID_TOUCH_VEL_X -> "context:touch_vel_x"
            RemoteContext.ID_TOUCH_VEL_Y -> "context:touch_vel_y"
            RemoteContext.ID_ACCELERATION_X -> "context:acceleration_x"
            RemoteContext.ID_ACCELERATION_Y -> "context:acceleration_y"
            RemoteContext.ID_ACCELERATION_Z -> "context:acceleration_z"
            RemoteContext.ID_GYRO_ROT_X -> "context:gyro_rot_x"
            RemoteContext.ID_GYRO_ROT_Y -> "context:gyro_rot_y"
            RemoteContext.ID_GYRO_ROT_Z -> "context:gyro_rot_z"
            RemoteContext.ID_MAGNETIC_X -> "context:magnetic_x"
            RemoteContext.ID_MAGNETIC_Y -> "context:magnetic_y"
            RemoteContext.ID_MAGNETIC_Z -> "context:magnetic_z"
            RemoteContext.ID_LIGHT -> "context:light"
            RemoteContext.ID_DENSITY -> "context:density"
            RemoteContext.ID_API_LEVEL -> "context:api_level"
            RemoteContext.ID_TOUCH_EVENT_TIME -> "context:touch_event_time"
            RemoteContext.ID_ANIMATION_TIME -> "context:animation_time"
            RemoteContext.ID_ANIMATION_DELTA_TIME -> "context:animation_delta_time"
            RemoteContext.ID_EPOCH_SECOND -> "context:epoch_second"
            RemoteContext.ID_FONT_SIZE -> "context:font_size"
            else -> "context:#$id"
        }
    }
}

/** A synthetic state wrapper for literal [FloatArray] arguments in operations. */
internal class FloatArrayRemoteState(internal val floatArray: FloatArray, key: FloatArrayCacheKey) :
    BaseRemoteState<FloatArray>(key) {
    override val constantValueOrNull: FloatArray
        get() = floatArray

    override fun writeToDocument(creationState: RemoteComposeCreationContext): Int {
        throw UnsupportedOperationException(
            "FloatArrayRemoteState cannot be written directly to document"
        )
    }
}

internal class FloatArrayCacheKey(internal val floatArray: FloatArray) : BaseRemoteStateCacheKey() {
    override fun equals(other: Any?): Boolean {
        return other is FloatArrayCacheKey && floatArray.contentEquals(other.floatArray)
    }

    override fun hashCodeImpl(): Int = floatArray.contentHashCode()

    override fun toDebugString(): String = floatArray.contentToString()
}

/**
 * A cache key for component-specific values (like width/height/center), identified by the
 * [componentId] and the [type] of value.
 */
internal class RemoteComponentCacheKey(internal val componentId: Int, internal val type: String) :
    BaseRemoteStateCacheKey() {
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RemoteComponentCacheKey) return false
        if (componentId != other.componentId) return false
        if (type != other.type) return false
        return true
    }

    override fun hashCodeImpl(): Int {
        var result = componentId
        result = 31 * result + type.hashCode()
        return result
    }

    override fun toString(): String =
        "RemoteComponentCacheKey(componentId=$componentId, type=$type)"

    override fun toDebugString(): String = "component:$componentId.$type"
}

/**
 * A cache key for operations performed on other remote states, identified by the operation [op]
 * (usually an [Enum]) and its [args].
 */
internal class RemoteOperationCacheKey(
    internal val op: Enum<*>,
    override val args: List<RemoteStateCacheKey>,
) : BaseRemoteStateCacheKey() {
    private var state: BaseRemoteState<*>? = null

    override fun getState(): BaseRemoteState<*>? = state

    override fun setState(state: BaseRemoteState<*>?) {
        this.state = state
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RemoteOperationCacheKey) return false
        if (op != other.op) return false
        if (args != other.args) return false
        return true
    }

    override fun hashCodeImpl(): Int {
        // Enums inherit java.lang.Object.hashCode() (identity hash code), which is
        // non-deterministic across JVM executions. We hash the declaring class name and
        // constant name to ensure determinism.
        var result = op::class.simpleName.hashCode() + op.name.hashCode()
        result = 31 * result + args.hashCode()
        return result
    }

    override fun toString(): String = "RemoteOperationCacheKey(op=$op, args=$args)"

    override fun toDebugString(): String {
        return if (op is RemoteOperation) {
            (op as RemoteOperation).toDebugString(args)
        } else {
            "Operation($op, args=[${args.joinToDebugString()}])"
        }
    }

    companion object {
        /** Creates a [RemoteOperationCacheKey] by converting [args] to a list of cache keys. */
        public fun create(op: Enum<*>, vararg args: Any?): RemoteOperationCacheKey =
            RemoteOperationCacheKey(op, toCacheKeyList(args))
    }
}

/**
 * Converts a list of arguments into a list of [RemoteStateCacheKey]s. Any argument that is not
 * already a [RemoteStateCacheKey] is wrapped in a [RemoteConstantCacheKey].
 */
internal fun toCacheKeyList(args: Array<out Any?>): List<RemoteStateCacheKey> {
    return args.map {
        when (it) {
            null -> RemoteConstantCacheKey(null)
            is RemoteConstantCacheKey -> it
            is RemoteState<*> -> it.cacheKey
            is RemoteStateCacheKey -> it
            is Byte,
            is Short,
            is Int,
            is Long,
            is Float,
            is Double,
            is Boolean,
            is Char,
            is String,
            is Enum<*> -> RemoteConstantCacheKey(it)
            else ->
                throw IllegalArgumentException(
                    "Unsupported cache key type: ${it::class}. " +
                        "Only primitives, Strings, Enums and RemoteStates are supported."
                )
        }
    }
}
