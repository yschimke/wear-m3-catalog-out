/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.modifier

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.compose.capture.RemoteDensityBehavior
import androidx.compose.remote.creation.compose.state.RemoteDp
import androidx.compose.remote.creation.compose.state.RemoteFloat
import androidx.compose.remote.creation.compose.state.RemoteStateScope
import androidx.compose.remote.creation.common.RemoteModifierOperation

internal class OffsetModifier(
    public val x: RemoteFloat,
    public val y: RemoteFloat,
    private val xDp: RemoteDp? = null,
    private val yDp: RemoteDp? = null,
) : RemoteModifier.Element {

    public constructor(
        x: RemoteDp,
        y: RemoteDp,
    ) : this(
        x = x.toPx(),
        y = y.toPx(),
        xDp = x,
        yDp = y,
    )

    override fun RemoteStateScope.toRemoteModifierOperation(): RemoteModifierOperation {
        val resolvedX =
            if (densityBehavior == RemoteDensityBehavior.Dp) {
                xDp?.value ?: (x / remoteDensity.density)
            } else x
        val resolvedY =
            if (densityBehavior == RemoteDensityBehavior.Dp) {
                yDp?.value ?: (y / remoteDensity.density)
            } else y
        return RemoteModifierOperation.Offset(resolvedX.floatId, resolvedY.floatId)
    }
}

public fun RemoteModifier.offset(x: RemoteDp, y: RemoteDp): RemoteModifier =
    then(OffsetModifier(x, y))
