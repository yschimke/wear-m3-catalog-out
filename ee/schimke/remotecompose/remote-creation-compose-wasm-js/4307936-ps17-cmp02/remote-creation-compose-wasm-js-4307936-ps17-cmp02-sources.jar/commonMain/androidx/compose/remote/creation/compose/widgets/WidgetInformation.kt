/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.widgets

import androidx.annotation.RestrictTo
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.compositionLocalOf

/** Encapsulate information about the current widget being created */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP) public data class WidgetInformation(val widgetId: Int)

/** Provides the Widget information as a composition local */
internal val LocalWidget: ProvidableCompositionLocal<WidgetInformation> =
    compositionLocalOf<WidgetInformation> {
        WidgetInformation(-1) // Default
    }
