/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:OptIn(androidx.compose.remote.creation.compose.ExperimentalRemoteCreationComposeApi::class)

package androidx.compose.remote.creation.compose.capture

import androidx.compose.remote.creation.common.PaintBundleData
import androidx.compose.remote.creation.compose.RemoteComposeCreationComposeFlags
import androidx.compose.remote.creation.compose.layout.toInt
import androidx.compose.remote.creation.compose.shaders.RemoteShader
import androidx.compose.remote.creation.compose.state.ComposeRemoteColorFilter
import androidx.compose.remote.creation.compose.state.RemoteBlendModeColorFilter
import androidx.compose.remote.creation.compose.state.RemoteColor
import androidx.compose.remote.creation.compose.state.RemoteColorFilter
import androidx.compose.remote.creation.compose.state.RemotePaint
import androidx.compose.remote.creation.compose.text.RemoteTypeface
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontVariation

/** Tracks the state of a [RemotePaint] to optimize serialization by only sending deltas. */
internal class PaintTracker {
    var force: Boolean = false
    var isChanged: Boolean = false
    var remoteColor: RemoteColor? = null
    var colorValue: Int = -1
    var colorIsId: Boolean = false
    var strokeWidth: Float = -1f
    var textSize: Float = -1f
    var strokeCap: Int = -1
    var strokeJoin: Int = -1
    var style: Int = -1
    var typefaceId: Int = -1
    var typefaceWeight: Int = -1
    var typefaceIsItalic: Boolean = false
    var colorFilter: RemoteColorFilter? = null
    var blendMode: BlendMode? = null
    var filterQuality: FilterQuality? = null
    var shader: RemoteShader? = null
    var usingShaderMatrix: Boolean = false
    var fontVariationSettings: FontVariation.Settings? = null

    fun reset(force: Boolean) {
        this.force = force
        this.isChanged = force
    }

    private inline fun updateIfChanged(newValue: Any?, currentValue: Any?, update: () -> Unit) {
        if (force || newValue != currentValue) {
            update()
            isChanged = true
        }
    }

    private inline fun updateFloatIfChanged(
        newValue: Float,
        currentValue: Float,
        update: (Float) -> Unit,
    ): Float {
        if (force || newValue.toRawBits() != currentValue.toRawBits()) {
            update(newValue)
            isChanged = true
        }
        return newValue
    }

    fun updateWithPaint(
        newPaint: RemotePaint,
        paintBundle: PaintBundleData,
        creationState: RemoteComposeCreationContext,
    ) {
        // Color
        val targetRemoteColor = newPaint.color
        val colorVal: Int
        val colorIsId: Boolean
        val constantValue = targetRemoteColor.constantValueOrNull
        if (constantValue != null) {
            colorVal = constantValue.toArgb()
            colorIsId = false
        } else {
            colorVal = targetRemoteColor.getIdForCreationState(creationState)
            colorIsId = true
        }

        if (
            force ||
                this.remoteColor == null ||
                this.colorValue != colorVal ||
                this.colorIsId != colorIsId
        ) {
            this.colorValue = colorVal
            this.colorIsId = colorIsId
            this.remoteColor = targetRemoteColor
            if (colorIsId) {
                paintBundle.setColorId(colorVal)
            } else {
                paintBundle.setColor(colorVal)
            }
            isChanged = true
        }

        strokeWidth =
            updateFloatIfChanged(
                newPaint.strokeWidth.getFloatIdForCreationState(creationState),
                strokeWidth,
            ) {
                paintBundle.setStrokeWidth(it)
            }

        val targetCap = newPaint.strokeCap.remoteInt
        updateIfChanged(targetCap, strokeCap) {
            strokeCap = targetCap
            paintBundle.setStrokeCap(targetCap)
        }

        val targetJoin = newPaint.strokeJoin.remoteInt
        updateIfChanged(targetJoin, strokeJoin) {
            strokeJoin = targetJoin
            paintBundle.setStrokeJoin(targetJoin)
        }

        val targetStyle = newPaint.style.remoteInt
        updateIfChanged(targetStyle, style) {
            style = targetStyle
            paintBundle.setStyle(targetStyle)
        }

        textSize =
            updateFloatIfChanged(
                newPaint.textSize.getFloatIdForCreationState(creationState),
                textSize,
            ) {
                paintBundle.setTextSize(it)
            }

        val paintTypeface = newPaint.typeface
        val targetTypefaceId = getTypefaceId(paintTypeface, creationState)
        val targetWeight =
            when (paintTypeface) {
                RemoteTypeface.DefaultBold -> 700
                is RemoteTypeface.Named -> paintTypeface.weight
                else -> 400
            }
        val targetIsItalic =
            if (paintTypeface is RemoteTypeface.Named) paintTypeface.isItalic else false
        if (
            force ||
                typefaceId != targetTypefaceId ||
                typefaceWeight != targetWeight ||
                typefaceIsItalic != targetIsItalic
        ) {
            typefaceId = targetTypefaceId
            typefaceWeight = targetWeight
            typefaceIsItalic = targetIsItalic
            paintBundle.setTextStyle(targetTypefaceId, targetWeight, targetIsItalic)
            isChanged = true
        }

        val targetFontVariationSettings = newPaint.fontVariationSettings
        val settingsToUse =
            if (RemoteComposeCreationComposeFlags.allowSendingEmptyFontAxis) {
                targetFontVariationSettings
            } else {
                targetFontVariationSettings
                    ?: FontVariation.Settings(FontVariation.weight(DEFAULT_FONT_WEIGHT))
            }
        updateIfChanged(settingsToUse, fontVariationSettings) {
            fontVariationSettings = settingsToUse
            if (settingsToUse != null) {
                val (fontAxisNames, fontAxisValues) = extractFontSettings(settingsToUse.settings)
                if (fontAxisNames != null && fontAxisValues != null) {
                    val axisTags =
                        IntArray(fontAxisNames.size) { i ->
                            creationState.writer.addText(fontAxisNames[i])
                        }
                    paintBundle.setFontAxes(axisTags, fontAxisValues)
                }
            } else {
                paintBundle.setFontAxes(intArrayOf(), floatArrayOf())
            }
        }

        val targetColorFilter = newPaint.colorFilter
        updateIfChanged(targetColorFilter, colorFilter) {
            val wasSet = colorFilter != null
            colorFilter = targetColorFilter
            when (targetColorFilter) {
                null -> {
                    if (wasSet || force) {
                        paintBundle.clearColorFilter()
                    }
                }
                is RemoteBlendModeColorFilter -> {
                    val constantColor = targetColorFilter.color.constantValueOrNull
                    if (constantColor != null) {
                        paintBundle.setColorFilter(
                            constantColor.toArgb(),
                            targetColorFilter.blendMode.toInt(),
                        )
                    } else {
                        val colorId = targetColorFilter.color.getIdForCreationState(creationState)
                        paintBundle.setColorFilterId(colorId, targetColorFilter.blendMode.toInt())
                    }
                }

                is ComposeRemoteColorFilter -> paintBundle.setComposeColorFilter(targetColorFilter)
            }
        }

        val composeBlendMode = newPaint.blendMode
        updateIfChanged(composeBlendMode, blendMode) {
            blendMode = composeBlendMode
            paintBundle.setBlendMode(composeBlendMode.toInt())
        }

        val targetFilterQuality = newPaint.filterQuality
        updateIfChanged(targetFilterQuality, filterQuality) {
            filterQuality = targetFilterQuality
            paintBundle.setFilterBitmap(targetFilterQuality != FilterQuality.None)
        }

        val targetShader = newPaint.shader
        if (force || this.shader != targetShader) {
            this.shader = targetShader
            if (targetShader != null) {
                targetShader.apply(creationState, paintBundle)
                val remoteMatrix3x3 = targetShader.remoteMatrix3x3
                when {
                    !remoteMatrix3x3.isIdentity -> {
                        paintBundle.setShaderMatrix(
                            remoteMatrix3x3.getFloatIdForCreationState(creationState)
                        )
                        usingShaderMatrix = true
                    }
                    usingShaderMatrix -> {
                        paintBundle.setShaderMatrix(0f)
                        usingShaderMatrix = false
                    }
                }
            } else {
                paintBundle.setShader(0)
            }
            isChanged = true
        }
    }

    private fun getTypefaceId(
        paintTypeface: RemoteTypeface?,
        creationState: RemoteComposeCreationContext,
    ): Int {
        return when (paintTypeface) {
            null -> PaintBundleData.FONT_TYPE_DEFAULT
            RemoteTypeface.Default -> PaintBundleData.FONT_TYPE_DEFAULT
            RemoteTypeface.DefaultBold -> PaintBundleData.FONT_TYPE_DEFAULT
            RemoteTypeface.Serif -> PaintBundleData.FONT_TYPE_SERIF
            RemoteTypeface.SansSerif -> PaintBundleData.FONT_TYPE_SANS_SERIF
            RemoteTypeface.Monospace -> PaintBundleData.FONT_TYPE_MONOSPACE
            is RemoteTypeface.Named -> {
                when (paintTypeface.name.lowercase()) {
                    "sans-serif" -> PaintBundleData.FONT_TYPE_SANS_SERIF
                    "serif" -> PaintBundleData.FONT_TYPE_SERIF
                    "monospace" -> PaintBundleData.FONT_TYPE_MONOSPACE
                    "default" -> PaintBundleData.FONT_TYPE_DEFAULT
                    else -> creationState.writer.addText(paintTypeface.name)
                }
            }
        }
    }

    private fun extractFontSettings(
        settings: List<FontVariation.Setting>?
    ): Pair<Array<String>?, FloatArray?> {
        val size = settings?.size ?: return Pair(null, null)

        val fontAxisNames = Array(size) { settings[it].axisName }
        val fontAxisValues = FloatArray(size) { settings[it].toVariationValue(null) }

        return Pair(fontAxisNames, fontAxisValues)
    }

    private companion object {
        const val DEFAULT_FONT_WEIGHT = 400
    }
}

private val StrokeCap.remoteInt: Int
    get() =
        when (this) {
            StrokeCap.Butt -> 0
            StrokeCap.Round -> 1
            StrokeCap.Square -> 2
            else -> 0
        }

private val StrokeJoin.remoteInt: Int
    get() =
        when (this) {
            StrokeJoin.Miter -> 0
            StrokeJoin.Round -> 1
            StrokeJoin.Bevel -> 2
            else -> 0
        }

private val PaintingStyle.remoteInt: Int
    get() = if (this == PaintingStyle.Stroke) 1 else 0
