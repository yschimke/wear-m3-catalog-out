/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.state

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.compose.capture.RemoteComposeCreationContext
import androidx.compose.remote.creation.compose.capture.RemoteDensity
import androidx.compose.remote.creation.compose.layout.RemoteComposable
import androidx.compose.remote.creation.compose.state.RemoteDp.Companion.createNamedRemoteDp
import androidx.compose.remote.creation.compose.state.RemoteFloat.Companion.createNamedRemoteFloat
import androidx.compose.remote.creation.compose.state.RemoteFloat.Companion.createNamedRemoteFloatExpression
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified

/**
 * Represents a Density-independent pixel (Dp) value.
 *
 * `RemoteDp` represents a Dp value that can be a constant, a named variable, or a dynamic
 * expression.
 */
@Stable
public class RemoteDp
internal constructor(
    @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP) public val value: RemoteFloat
) : BaseRemoteState<Dp>(RemoteStateInstanceKey()) {
    internal override val cacheKey: RemoteStateCacheKey
        get() = toPx().cacheKey

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    override fun toDebugString(): String {
        val valKey = value.cacheKey
        if (valKey is RemoteOperationCacheKey && valKey.op == OperationKey.ToDp) {
            return "${valKey.args[0].toOperandString(100)}.toDp()"
        }
        return "${valKey.toOperandString(100)}.dp"
    }

    internal enum class OperationKey : RemoteOperation {
        ToPx,
        ToDp;

        override fun toDebugString(args: List<RemoteStateCacheKey>): String {
            return when (this) {
                ToPx -> "${args[0].toOperandString(100)}.toPx()"
                ToDp -> "${args[0].toOperandString(100)}.toDp()"
            }
        }

        override fun reconstruct(args: List<BaseRemoteState<*>>): BaseRemoteState<*> {
            return when (this) {
                ToPx -> RemoteDp(args[0] as RemoteFloat).toPx()
                ToDp -> (args[0] as RemoteFloat).toRemoteDp().value
            }
        }
    }

    override val constantValueOrNull: Dp?
        get() = value.constantValueOrNull?.dp

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    override fun writeToDocument(creationState: RemoteComposeCreationContext): Int {
        return toPx().writeToDocument(creationState)
    }

    /**
     * Function to convert this [RemoteDp] to a density-independent pixel value. It multiplies the
     * current float value by the screen\'s density.
     */
    public fun toPx(density: RemoteDensity): RemoteFloat {
        return density.density * value
    }

    /** Converts a RemoteDp to a RemoteFloat Px using the [RemoteDensity]. */
    public fun toPx(): RemoteFloat {
        return RemoteFloatExpression(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.ToPx, value),
        ) { creationState ->
            val density = creationState.remoteDensity
            (value * density.density).arrayForCreationState(creationState)
        }
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    override fun getFloatIdForCreationState(creationState: RemoteComposeCreationContext): Float {
        return toPx().getFloatIdForCreationState(creationState)
    }

    /** Add two [RemoteDp]s together. */
    public operator fun plus(other: RemoteDp): RemoteDp = RemoteDp(this.value + other.value)

    /** Subtract a [RemoteDp] from another one. */
    public operator fun minus(other: RemoteDp): RemoteDp = RemoteDp(this.value - other.value)

    /** This is the same as multiplying the Dp by -1.0. */
    public operator fun unaryMinus(): RemoteDp = RemoteDp(-this.value)

    /** Divide a [RemoteDp] by a scalar. */
    public operator fun div(other: Float): RemoteDp = RemoteDp(this.value / other)

    /** Divide a [RemoteDp] by a scalar. */
    public operator fun div(other: Int): RemoteDp = RemoteDp(this.value / other.toFloat())

    /** Divide a [RemoteDp] by a [RemoteFloat]. */
    public operator fun div(other: RemoteFloat): RemoteDp = RemoteDp(this.value / other)

    /** Divide a [RemoteDp] by a [RemoteInt]. */
    public operator fun div(other: RemoteInt): RemoteDp =
        RemoteDp(this.value / other.toRemoteFloat())

    /** Divide by another [RemoteDp] to get a scalar. */
    public operator fun div(other: RemoteDp): RemoteFloat = this.value / other.value

    /** Multiply a [RemoteDp] by a scalar. */
    public operator fun times(other: Float): RemoteDp = RemoteDp(this.value * other)

    /** Multiply a [RemoteDp] by a scalar. */
    public operator fun times(other: Int): RemoteDp = RemoteDp(this.value * other.toFloat())

    /** Multiply a [RemoteDp] by a [RemoteFloat]. */
    public operator fun times(other: RemoteFloat): RemoteDp = RemoteDp(this.value * other)

    /** Multiply a [RemoteDp] by a [RemoteInt]. */
    public operator fun times(other: RemoteInt): RemoteDp =
        RemoteDp(this.value * other.toRemoteFloat())

    /** Check if this [RemoteDp] is less than [other]. */
    public fun isLessThan(other: RemoteDp): RemoteBoolean = this.value.isLessThan(other.value)

    /** Check if this [RemoteDp] is less than or equal to [other]. */
    public fun isLessThanOrEqualTo(other: RemoteDp): RemoteBoolean =
        this.value.isLessThanOrEqualTo(other.value)

    /** Check if this [RemoteDp] is greater than [other]. */
    public fun isGreaterThan(other: RemoteDp): RemoteBoolean = this.value.isGreaterThan(other.value)

    /** Check if this [RemoteDp] is greater than or equal to [other]. */
    public fun isGreaterThanOrEqualTo(other: RemoteDp): RemoteBoolean =
        this.value.isGreaterThanOrEqualTo(other.value)

    /** Check if this [RemoteDp] is equal to [other]. */
    public fun isEqualTo(other: RemoteDp): RemoteBoolean = this.value.isEqualTo(other.value)

    /** Check if this [RemoteDp] is not equal to [other]. */
    public fun isNotEqualTo(other: RemoteDp): RemoteBoolean = this.value.isNotEqualTo(other.value)

    public companion object {
        /**
         * Creates a [RemoteDp] from a literal [Dp] value.
         *
         * @param value The [Dp] value.
         * @return A [RemoteDp] representing the constant Dp.
         */
        public operator fun invoke(value: Dp): RemoteDp = value.asRdp()

        /**
         * Creates a [RemoteDp] referencing a remote ID.
         *
         * @param id The remote ID (stored as a [RemoteFloat]).
         * @return A [RemoteDp] referencing the ID.
         */
        internal fun createForId(id: RemoteFloat): RemoteDp = RemoteDp(id)

        /**
         * Creates a named [RemoteDp] with an initial value.
         *
         * Named remote Dps can be set via AndroidRemoteContext.setNamedFloat.
         *
         * @param name A unique name to identify this state within its [domain].
         * @param defaultValue The initial [Dp] value for the named remote Dp.
         * @param domain The domain for the named state. Defaults to [RemoteState.Domain.User].
         * @return A [RemoteDp] representing the named Dp.
         */
        public fun createNamedRemoteDp(
            name: String,
            defaultValue: Dp,
            domain: RemoteState.Domain = RemoteState.Domain.User,
        ): RemoteDp {
            return RemoteDp(
                createNamedRemoteFloat(
                    name = name,
                    defaultValue = defaultValue.value,
                    domain = domain,
                )
            )
        }

        @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
        public fun createNamedRemoteDp(
            name: String,
            domain: RemoteState.Domain = RemoteState.Domain.User,
            value: () -> RemoteDp,
        ): RemoteDp {
            val remoteDp = value()
            return RemoteDp(createNamedRemoteFloatExpression(name, domain) { remoteDp.value })
        }
    }
}

/** Extension property to convert an [Int] to a [RemoteDp]. */
public val Int.rdp: RemoteDp
    get() {
        return RemoteDp(this.rf)
    }

/** Extension property to convert a [Float] to a [RemoteDp]. */
public val Float.rdp: RemoteDp
    get() {
        return RemoteDp(this.rf)
    }

/** Extension property to convert a [Dp] to a [RemoteDp]. */
public fun Dp.asRdp(): RemoteDp {
    check(isSpecified) { "Dp conversion not possible for unspecified Dp" }
    return RemoteDp(this.value.rf)
}

/** Converts this [RemoteFloat] to a [RemoteDp] directly (1:1) */
public fun RemoteFloat.asRemoteDp(): RemoteDp {
    return RemoteDp(this)
}

/** Converts this [RemoteFloat] representing pixels to a [RemoteDp] by dividing by density. */
public fun RemoteFloat.toRemoteDp(): RemoteDp {
    // TODO: Optimize for constant values when value and density are constants
    return RemoteDp(
        RemoteFloatExpression(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(RemoteDp.OperationKey.ToDp, this),
        ) { creationState ->
            val density = creationState.remoteDensity
            (this / density.density).arrayForCreationState(creationState)
        }
    )
}

/**
 * Remembers a named remote Dp expression.
 *
 * @param name The unique name for this remote Dp.
 * @param domain The domain of the named Dp (defaults to [RemoteState.Domain.User]).
 * @param value A lambda that provides the [RemoteDp] expression.
 * @return A [RemoteDp] representing the named remote Dp expression.
 */
@Composable
@RemoteComposable
public fun rememberNamedRemoteDp(
    name: String,
    domain: RemoteState.Domain = RemoteState.Domain.User,
    value: () -> RemoteDp,
): RemoteDp {
    return remember(name, domain) { createNamedRemoteDp(name, domain, value) }
}

/** Returns the smaller of two [RemoteDp] values. */
public fun min(a: RemoteDp, b: RemoteDp): RemoteDp = RemoteDp(min(a.value, b.value))

/** Returns the greater of two [RemoteDp] values. */
public fun max(a: RemoteDp, b: RemoteDp): RemoteDp = RemoteDp(max(a.value, b.value))
