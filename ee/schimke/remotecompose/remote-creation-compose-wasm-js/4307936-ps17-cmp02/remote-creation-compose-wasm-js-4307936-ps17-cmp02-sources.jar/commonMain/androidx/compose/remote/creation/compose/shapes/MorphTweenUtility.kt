/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.shapes

import androidx.compose.remote.creation.common.Utils
import androidx.graphics.shapes.Cubic
import androidx.graphics.shapes.RoundedPolygon

internal object MorphTweenUtility {
    fun cubicsToPathData(cubics: List<Cubic>): FloatArray {
        if (cubics.isEmpty()) return floatArrayOf()
        // Path format: MOVE (3) + CUBIC (9 * N) + CLOSE (1)
        val data = FloatArray(3 + cubics.size * 9 + 1)
        var i = 0
        val first = cubics[0]
        data[i++] = Utils.asNan(10)
        data[i++] = first.anchor0X
        data[i++] = first.anchor0Y

        for (j in cubics.indices) {
            val cubic = cubics[j]
            data[i++] = Utils.asNan(14)
            data[i++] = 0f // padding
            data[i++] = 0f // padding
            data[i++] = cubic.control0X
            data[i++] = cubic.control0Y
            data[i++] = cubic.control1X
            data[i++] = cubic.control1Y
            data[i++] = cubic.anchor1X
            data[i++] = cubic.anchor1Y
        }
        data[i++] = Utils.asNan(15)
        return data
    }
}
