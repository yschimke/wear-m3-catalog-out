/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.layout

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.compose.capture.LocalRemoteDensity
import androidx.compose.remote.creation.compose.capture.RemoteComposeCreationState
import androidx.compose.remote.creation.compose.capture.WriterOp
import androidx.compose.remote.creation.compose.capture.RemoteDensity
import androidx.compose.remote.creation.compose.modifier.RemoteModifier
import androidx.compose.remote.creation.compose.modifier.drawWithContent
import androidx.compose.remote.creation.compose.modifier.hasDrawWithContent
import androidx.compose.remote.creation.compose.modifier.toRemoteModifierData
import androidx.compose.remote.creation.compose.state.RemoteStateScope
import androidx.compose.remote.creation.common.RemoteModifierData
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ComposeNode
import androidx.compose.runtime.DisallowComposableCalls
import androidx.compose.runtime.Updater
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.util.fastForEach
import androidx.compose.ui.util.fastForEachReversed

internal abstract class RemoteComposeNode {
    val children = mutableListOf<RemoteComposeNode>()
    var modifier: RemoteModifier = RemoteModifier
    var remoteDensity: RemoteDensity = RemoteDensity.Host
    private var renderedComponentId: Int = 0

    fun overriddenScope(creationState: RemoteComposeCreationState): RemoteStateScope {
        return OverriddenScope(creationState, remoteDensity, creationState.layoutDirection)
    }

    abstract fun render(creationState: RemoteComposeCreationState, remoteCanvas: RemoteCanvas)

    fun resolveModifier(
        scope: RemoteStateScope,
        creationState: RemoteComposeCreationState,
    ): RemoteModifierData {
        renderedComponentId = creationState.allocateComponentId()
        return scope.toRemoteModifierData(modifier).apply { componentId = renderedComponentId }
    }

    fun renderChildren(
        creationState: RemoteComposeCreationState,
        remoteCanvas: RemoteCanvas,
        reversed: Boolean = false,
    ) {
        val previousComponent = creationState.enterComponentScope(renderedComponentId)
        try {
            if (modifier.hasDrawWithContent()) {
                remoteCanvas.internalCanvas.recordRenderingOp(WriterOp.StartCanvasOperations)
                modifier.drawWithContent(remoteCanvas) {
                    remoteCanvas.internalCanvas.drawComponentContent()
                }
                remoteCanvas.internalCanvas.recordRenderingOp(WriterOp.EndCanvasOperations)
            }

            if (!reversed) {
                children.fastForEach { it.render(creationState, remoteCanvas) }
            } else {
                children.fastForEachReversed { it.render(creationState, remoteCanvas) }
            }
        } finally {
            creationState.restoreComponentScope(previousComponent)
        }
    }
}

internal class RemoteRootNode : RemoteComposeNode() {
    override fun render(creationState: RemoteComposeCreationState, remoteCanvas: RemoteCanvas) {
        remoteCanvas.internalCanvas.recordRenderingOp(WriterOp.StartRoot)
        renderChildren(creationState, remoteCanvas)
        remoteCanvas.internalCanvas.recordRenderingOp(WriterOp.EndRoot)
    }
}

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@Composable
internal inline fun <T : RemoteComposeNode> RemoteComposeNode(
    noinline factory: () -> T,
    update: @DisallowComposableCalls Updater<T>.() -> Unit,
) {
    val remoteDensity = LocalRemoteDensity.current
    ComposeNode<T, RemoteComposeApplier>(factory) {
        update()
        set(remoteDensity) { this.remoteDensity = it }
    }
}

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@Composable
internal inline fun <T : RemoteComposeNode> RemoteComposeNode(
    noinline factory: () -> T,
    update: @DisallowComposableCalls Updater<T>.() -> Unit,
    content: @Composable @RemoteComposable () -> Unit,
) {
    val remoteDensity = LocalRemoteDensity.current
    ComposeNode<T, RemoteComposeApplier>(
        factory,
        {
            update()
            set(remoteDensity) { this.remoteDensity = it }
        },
        content,
    )
}

internal fun shouldReverse(
    horizontalArrangement: RemoteArrangement.Horizontal,
    layoutDirection: LayoutDirection,
): Boolean =
    if (layoutDirection == LayoutDirection.Rtl) {
        when (horizontalArrangement) {
            is HorizontalArrangement -> !horizontalArrangement.isAbsolute()

            is RemoteSpacedAbsoluteHorizontalArrangement,
            is RemoteFloatSpacedAbsoluteHorizontalArrangement -> false

            else -> true
        }
    } else {
        false
    }

internal class OverriddenScope(
    override val parentScope: RemoteStateScope,
    override val remoteDensity: RemoteDensity,
    override val layoutDirection: LayoutDirection,
) : RemoteStateScope
