/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.state

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.common.Utils
import androidx.compose.remote.creation.common.MatrixOperations
import androidx.compose.remote.creation.compose.capture.RemoteComposeCreationContext

/** Represents a 3x3 transformation matrix. */
public class RemoteMatrix3x3
internal constructor(
    private val arrayProvider: (creationState: RemoteComposeCreationContext) -> FloatArray,
    cacheKey: RemoteStateCacheKey,
) : BaseRemoteState<Any>(cacheKey) {

    internal enum class OperationKey(override val precedence: Int = 100) : RemoteOperation {
        IDENTITY {
            override fun toDebugString(args: List<RemoteStateCacheKey>) = "identity()"
        },
        ROTATE {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "rotate(${args[0].toDebugString()})"
        },
        TRANSLATE_X {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "translateX(${args[0].toDebugString()})"
        },
        TRANSLATE_Y {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "translateY(${args[0].toDebugString()})"
        },
        TRANSLATE_XY {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "translate(${args[0].toDebugString()}, ${args[1].toDebugString()})"
        },
        SCALE_X {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "scaleX(${args[0].toDebugString()})"
        },
        SCALE_Y {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "scaleY(${args[0].toDebugString()})"
        },
        ROTATION_AROUND {
            override fun toDebugString(args: List<RemoteStateCacheKey>): String {
                val params = args.joinToDebugString()
                return "rotateAround($params)"
            }
        },
        MUL(3) {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                args.formatOp("*", precedence)
        };

        override fun reconstruct(args: List<BaseRemoteState<*>>): BaseRemoteState<*> {
            return when (this) {
                IDENTITY -> createIdentity()
                ROTATE -> createRotate(args[0] as RemoteFloat)
                TRANSLATE_X -> createTranslateX(args[0] as RemoteFloat)
                TRANSLATE_Y -> createTranslateY(args[0] as RemoteFloat)
                TRANSLATE_XY -> createTranslateXy(args[0] as RemoteFloat, args[1] as RemoteFloat)
                SCALE_X -> createScaleX(args[0] as RemoteFloat)
                SCALE_Y -> createScaleY(args[0] as RemoteFloat)
                ROTATION_AROUND ->
                    createRotationAround(
                        args[0] as RemoteFloat,
                        args[1] as RemoteFloat,
                        args[2] as RemoteFloat,
                    )
                MUL -> (args[0] as RemoteMatrix3x3) * (args[1] as RemoteMatrix3x3)
            }
        }
    }

    override val constantValueOrNull: Any?
        get() = null

    internal val isIdentity: Boolean
        get() = (cacheKey as? RemoteOperationCacheKey)?.op == OperationKey.IDENTITY

    /**
     * Creates a new [RemoteMatrix3x3] that represents the multiplication of this matrix by another.
     *
     * @param v The [RemoteMatrix3x3] to multiply with this one (this * v).
     * @return A new [RemoteMatrix3x3] representing the multiplication.
     */
    public operator fun times(v: RemoteMatrix3x3): RemoteMatrix3x3 {
        val key = RemoteOperationCacheKey.create(OperationKey.MUL, this, v)
        return RemoteMatrix3x3(
            cacheKey = key,
            arrayProvider = { creationState ->
                floatArrayOf(
                    // Note there is an implicit MatrixOperations.IDENTITY for the first entry,
                    // see MatrixOperations#eval.
                    *this@RemoteMatrix3x3.arrayProvider(creationState),
                    MatrixOperations.IDENTITY,
                    *v.arrayProvider(creationState),
                    MatrixOperations.MUL,
                )
            },
        )
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public override fun writeToDocument(creationState: RemoteComposeCreationContext): Int =
        Utils.idFromNan(creationState.writer.matrixExpression(*arrayProvider(creationState)))

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public companion object {
        /** Creates a [RemoteMatrix3x3] representing an identity matrix. */
        public fun createIdentity(): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.IDENTITY),
                arrayProvider = { _ ->
                    // Note there is an implicit MatrixOperations.IDENTITY for the first entry,
                    // see MatrixOperations#eval.
                    floatArrayOf()
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that rotates around the Z-axis.
         *
         * @param angle The angle of rotation.
         */
        public fun createRotate(angle: RemoteFloat): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.ROTATE, angle),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        angle.getFloatIdForCreationState(creationState),
                        MatrixOperations.ROT_Z,
                    )
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that translates along the X-axis.
         *
         * @param x The distance to translate along the X-axis.
         */
        public fun createTranslateX(x: RemoteFloat): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.TRANSLATE_X, x),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        x.getFloatIdForCreationState(creationState),
                        MatrixOperations.TRANSLATE_X,
                    )
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that translates along the Y-axis.
         *
         * @param y The distance to translate along the Y-axis.
         */
        public fun createTranslateY(y: RemoteFloat): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.TRANSLATE_Y, y),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        y.getFloatIdForCreationState(creationState),
                        MatrixOperations.TRANSLATE_Y,
                    )
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that translates along the X-axis and the Y-axis.
         *
         * @param x The distance to translate along the X-axis.
         * @param y The distance to translate along the Y-axis.
         */
        public fun createTranslateXy(x: RemoteFloat, y: RemoteFloat): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.TRANSLATE_XY, x, y),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        x.getFloatIdForCreationState(creationState),
                        y.getFloatIdForCreationState(creationState),
                        MatrixOperations.TRANSLATE2,
                    )
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that scales along the X-axis.
         *
         * @param scale The scaling factor.
         */
        public fun createScaleX(scale: RemoteFloat): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.SCALE_X, scale),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        scale.getFloatIdForCreationState(creationState),
                        MatrixOperations.SCALE_X,
                    )
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that scales along the Y-axis.
         *
         * @param scale The scaling factor.
         */
        public fun createScaleY(scale: RemoteFloat): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey = RemoteOperationCacheKey.create(OperationKey.SCALE_Y, scale),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        scale.getFloatIdForCreationState(creationState),
                        MatrixOperations.SCALE_Y,
                    )
                },
            )

        /**
         * Creates a [RemoteMatrix3x3] that rotates around a pivot point on the Z-plane.
         *
         * @param angle The angle of rotation.
         * @param centerX The X-coordinate of the pivot point.
         * @param centerY The Y-coordinate of the pivot point.
         */
        public fun createRotationAround(
            angle: RemoteFloat,
            centerX: RemoteFloat,
            centerY: RemoteFloat,
        ): RemoteMatrix3x3 =
            RemoteMatrix3x3(
                cacheKey =
                    RemoteOperationCacheKey.create(
                        OperationKey.ROTATION_AROUND,
                        angle,
                        centerX,
                        centerY,
                    ),
                arrayProvider = { creationState ->
                    floatArrayOf(
                        angle.getFloatIdForCreationState(creationState),
                        centerX.getFloatIdForCreationState(creationState),
                        centerY.getFloatIdForCreationState(creationState),
                        MatrixOperations.ROT_PZ,
                    )
                },
            )
    }
}
