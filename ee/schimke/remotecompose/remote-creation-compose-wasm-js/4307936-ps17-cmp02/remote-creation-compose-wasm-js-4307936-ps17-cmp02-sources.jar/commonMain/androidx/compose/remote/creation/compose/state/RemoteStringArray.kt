/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.compose.remote.creation.compose.state

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.common.Utils
import androidx.compose.remote.creation.compose.capture.RemoteComposeCreationContext
import androidx.compose.ui.util.fastForEach
import androidx.compose.ui.util.fastMap

/** Represents an array of remote strings. */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class RemoteStringArray
internal constructor(
    public override val constantValueOrNull: List<RemoteString>?,
    internal override val cacheKey: RemoteStateCacheKey,
) : BaseRemoteState<List<RemoteString>>(cacheKey) {

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public constructor(
        constantValueOrNull: List<RemoteString>?
    ) : this(
        constantValueOrNull,
        constantValueOrNull?.let { values ->
            RemoteOperationCacheKey.create(OperationKey.Create, *values.toTypedArray())
        } ?: RemoteStateInstanceKey(),
    )

    internal enum class OperationKey : RemoteOperation {
        Create {
            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                "arrayOf(${args.joinToDebugString()})"

            override fun reconstruct(args: List<BaseRemoteState<*>>): BaseRemoteState<*> =
                RemoteStringArray(args.fastMap { it as RemoteString })
        },
        Get {
            override val precedence: Int
                get() = 100

            override fun toDebugString(args: List<RemoteStateCacheKey>) =
                args.formatArrayAccess(precedence)

            override fun reconstruct(args: List<BaseRemoteState<*>>): BaseRemoteState<*> =
                (args[0] as RemoteStringArray)[args[1] as RemoteInt]
        },
    }

    override fun writeToDocument(creationState: RemoteComposeCreationContext): Int {
        // If this instance represents an existing allocated ID (e.g. a formal parameter in a
        // pattern definition), return that ID directly instead of writing to the document.
        if (cacheKey is RemoteStateIdKey) {
            return (cacheKey as RemoteStateIdKey).id
        }
        val ids =
            constantValueOrNull!!.fastMap { it.getIdForCreationState(creationState) }.toIntArray()
        val nanId = creationState.writer.addIdList(ids)
        return Utils.idFromNan(nanId)
    }

    /** Array access operator for [RemoteStringArray] with an [Int] index. */
    public operator fun get(v: Int): RemoteString = constantValueOrNull?.get(v) ?: get(RemoteInt(v))

    /** Array access operator for [RemoteStringArray] with a [RemoteInt] index. */
    public operator fun get(v: RemoteInt): RemoteString {
        val constArray = constantValueOrNull
        val constIndex = v.constantValueOrNull
        if (constArray != null && constIndex != null) {
            return constArray[constIndex]
        }
        return MutableRemoteString(
            constantValueOrNull = null,
            cacheKey = RemoteOperationCacheKey.create(OperationKey.Get, this, v),
            lazyRemoteString = StringArrayDerefImpl(this, v),
        )
    }
}

private class StringArrayDerefImpl(val array: RemoteStringArray, val index: RemoteInt) :
    LazyRemoteString {
    override fun reserveTextId(creationState: RemoteComposeCreationContext): Int {
        val arrayId = Utils.asNan(array.getIdForCreationState(creationState))
        val indexId = index.getIdForCreationState(creationState)
        return creationState.writer.textLookup(arrayId, indexId)
    }

    override fun computeRequiredCodePointSet(
        creationState: RemoteComposeCreationContext
    ): Set<String>? {
        val constIndex = index.constantValueOrNull
        if (constIndex != null && array.constantValueOrNull != null) {
            return array.constantValueOrNull[constIndex].computeRequiredCodePointSet(creationState)
        }
        if (array.constantValueOrNull != null) {
            var merged: Set<String>? = HashSet()
            array.constantValueOrNull.fastForEach { str ->
                merged = mergeSets(merged, str.computeRequiredCodePointSet(creationState))
            }
            return merged
        }
        return null
    }
}
