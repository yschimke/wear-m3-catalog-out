// Generated from AndroidX Wear Compose by tools/transform.py — DO NOT EDIT.
// Re-run scripts/regenerate.sh; make changes in transform-rules.json or patches/.
/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.wear.compose.material3

import androidx.annotation.VisibleForTesting
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.wear.compose.foundation.ArcPaddingValues
import androidx.wear.compose.foundation.CurvedAlignment
import androidx.wear.compose.foundation.CurvedDirection
import androidx.wear.compose.foundation.CurvedLayout
import androidx.wear.compose.foundation.CurvedModifier
import androidx.wear.compose.foundation.CurvedScope
import androidx.wear.compose.foundation.CurvedTextStyle
import androidx.wear.compose.foundation.background
import androidx.wear.compose.foundation.basicCurvedText
import androidx.wear.compose.foundation.clearAndSetSemantics
import androidx.wear.compose.foundation.curvedRow
import androidx.wear.compose.foundation.padding
import androidx.wear.compose.foundation.sizeIn
import androidx.wear.compose.material3.TimeTextDefaults.timeFormat
import androidx.wear.compose.material3.TimeTextDefaults.timeTextStyle
import androidx.wear.compose.materialcore.currentTimeMillis
import androidx.wear.compose.materialcore.is24HourFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn

/**
 * Layout to show the current time and a label, they will be drawn in a curve, following the top
 * edge of the screen.
 *
 * Note that Wear Material UX guidance recommends that time text should not be larger than
 * [TimeTextDefaults.MaxSweepAngle] of the screen edge, which is enforced by default. It is
 * recommended that additional content, if any, is limited to short status messages before the time
 * using the MaterialTheme.colorScheme.primary color.
 *
 * For more information, see the
 * [Curved Text](https://developer.android.com/training/wearables/components/curved-text) guide.
 *
 * A simple [TimeText] which shows the current time:
 *
 * @sample androidx.wear.compose.material3.samples.TimeTextClockOnly
 *
 * ![TimeTextClockOnly Composite
 * Image](https://developer.android.com/wear/images/design/WearComposeM3_TimeTextClockOnly_CompositeImage.png)
 *
 * A [TimeText] with a short app status message shown:
 *
 * @sample androidx.wear.compose.material3.samples.TimeTextWithStatus
 *
 * ![TimeTextWithStatus Composite
 * Image](https://developer.android.com/wear/images/design/WearComposeM3_TimeTextWithStatus_CompositeImage.png)
 *
 * A [TimeText] with a long status message, that needs ellipsizing:
 *
 * @sample androidx.wear.compose.material3.samples.TimeTextWithStatusEllipsized
 *
 * ![TimeTextWithStatusEllipsized Composite
 * Image](https://developer.android.com/wear/images/design/WearComposeM3_TimeTextWithStatusEllipsized_CompositeImage.png)
 *
 * @param modifier The modifier to be applied to the component.
 * @param curvedModifier The [CurvedModifier] used to restrict the arc in which [TimeText] is drawn.
 * @param maxSweepAngle The default maximum sweep angle in degrees.
 * @param backgroundColor The background color of the arc drawn behind the [TimeText].
 * @param timeSource [TimeSource] which retrieves the current time and formats it.
 * @param contentPadding The spacing values between the container and the content.
 * @param content The content of the [TimeText] - displays the current time by default. This lambda
 *   receives the current time as a String and should display it using curvedText. Note that if long
 *   curved text is included here, it should specify [androidx.wear.compose.foundation.weight] on it
 *   so that the space available is suitably allocated.
 */
@Composable
public fun TimeText(
    modifier: Modifier = Modifier,
    curvedModifier: CurvedModifier = CurvedModifier,
    maxSweepAngle: Float = TimeTextDefaults.MaxSweepAngle,
    backgroundColor: Color = TimeTextDefaults.backgroundColor(),
    timeSource: TimeSource = TimeTextDefaults.rememberTimeSource(timeFormat()),
    contentPadding: PaddingValues = TimeTextDefaults.ContentPadding,
    content: CurvedScope.(String) -> Unit = { time -> timeTextCurvedText(time) },
) {
    val currentTime = timeSource.currentTime()

    CurvedLayout(modifier = modifier) {
        curvedRow(
            modifier =
                curvedModifier
                    .sizeIn(maxSweepDegrees = maxSweepAngle)
                    .padding(contentPadding.toArcPadding())
                    .background(backgroundColor, StrokeCap.Round),
            radialAlignment = CurvedAlignment.Radial.Center,
        ) {
            content(currentTime)
        }
    }
}

/** Contains the default values used by [TimeText]. */
public object TimeTextDefaults {
    /** The default padding from the edge of the screen. */
    private val Padding = PaddingDefaults.edgePadding

    /** Default format for 24h clock. */
    public val TimeFormat24Hours: String = "HH:mm"

    /** Default format for 12h clock. */
    public val TimeFormat12Hours: String = "h:mm"

    /**
     * The default maximum sweep angle in degrees used by [TimeText].
     *
     * This is calculated by keeping the length of the corresponding chord on the circle to be
     * approximately 57% of the screen width.
     */
    public val MaxSweepAngle: Float = 70f

    /** The default content padding used by [TimeText]. */
    public val ContentPadding: PaddingValues = PaddingValues(top = Padding)

    /**
     * Retrieves default timeFormat for the device. Depending on settings, it can be either 12h or
     * 24h format.
     */
    @Composable
    public fun timeFormat(): String {
        // Upstream asks Android for the locale's best pattern for "Hm"/"hm" and strips the
        // am/pm marker out of it. `platformTimePattern` answers the same question without a
        // locale database; see its TODO about the separator.
        return ee.schimke.wearcmp.port.platformTimePattern(is24HourFormat())
    }

    /**
     * Creates a [CurvedTextStyle] with default parameters used for showing time. By default a copy
     * of MaterialTheme.typography.arcMedium style is created.
     *
     * @param background The background color.
     * @param color The main color.
     * @param fontSize The font size.
     */
    @Composable
    public fun timeTextStyle(
        background: Color = Color.Unspecified,
        color: Color = MaterialTheme.colorScheme.onBackground.setLuminance(80f),
        fontSize: TextUnit = TextUnit.Unspecified,
    ): CurvedTextStyle =
        MaterialTheme.typography.arcMedium +
            CurvedTextStyle(color = color, background = background, fontSize = fontSize)

    /**
     * Creates a default implementation of [TimeSource] and remembers it. Once the system time
     * changes, it triggers an update of the [TimeSource.currentTime] which is formatted using
     * [timeFormat] param.
     *
     * [DefaultTimeSource] for Android uses [android.text.format.DateFormat] [timeFormat] should
     * follow the standard
     * [Date and Time patterns](https://developer.android.com/reference/java/text/SimpleDateFormat#date-and-time-patterns)
     * Examples: "h:mm a" - 12:08 PM "yyyy.MM.dd HH:mm:ss" - 2021.11.01 14:08:56 More examples can
     * be found [here](https://developer.android.com/reference/java/text/SimpleDateFormat#examples).
     *
     * @param timeFormat Date and time string pattern.
     */
    @Composable
    public fun rememberTimeSource(timeFormat: String): TimeSource =
        remember(timeFormat) { DefaultTimeSource(timeFormat) }

    /**
     * The recommended background color to use when displaying curved text so it is visible on top
     * of other content.
     */
    @Composable public fun backgroundColor(): Color = CurvedTextDefaults.backgroundColor()
}

/**
 * Default curved text to use in a [TimeText], for displaying the time
 *
 * @param time The time to display.
 * @param style A [CurvedTextStyle] to override the style used.
 */
public fun CurvedScope.timeTextCurvedText(time: String, style: CurvedTextStyle? = null) {
    // TimeText is intended to be hidden from TalkBack, so we clear semantics.
    basicCurvedText(time, modifier = CurvedModifier.clearAndSetSemantics {}) {
        style?.let { timeTextStyle() + it } ?: timeTextStyle()
    }
}

/**
 * A default implementation of Separator, to be shown between any text/composable and the time.
 *
 * @param curvedTextStyle A [CurvedTextStyle] for the separator.
 * @param contentArcPadding [ArcPaddingValues] for the separator text.
 */
public fun CurvedScope.timeTextSeparator(
    curvedTextStyle: CurvedTextStyle? = null,
    contentArcPadding: ArcPaddingValues = ArcPaddingValues(angular = 4.dp),
) {
    // TimeText is intended to be hidden from TalkBack, so we clear semantics.
    curvedText(
        text = "·",
        style = curvedTextStyle,
        modifier = CurvedModifier.padding(contentArcPadding).clearAndSetSemantics {},
    )
}

public interface TimeSource {

    /**
     * A method responsible for returning updated time string.
     *
     * @return Formatted time string.
     */
    @Composable public fun currentTime(): String
}

/*
 * `DefaultTimeSource`, `currentTime` and the `TimeBroadcastReceiver` and `formatTime` that sat at
 * the end of this file are replaced by `src/commonPort/.../TimeText.kt`: they were
 * `java.util.Calendar`, `android.text.format.DateFormat`, and a broadcast receiver listening for
 * ACTION_TIME_TICK. `TimeSource` itself — upstream's interface, above — is untouched, and is the
 * seam a host overrides to drive the clock itself.
 */

/** An extension function, which converts [PaddingValues] into [ArcPaddingValues]. */
private fun PaddingValues.toArcPadding() =
    object : ArcPaddingValues {
        override fun calculateOuterPadding(radialDirection: CurvedDirection.Radial) =
            calculateTopPadding()

        override fun calculateInnerPadding(radialDirection: CurvedDirection.Radial) =
            calculateBottomPadding()

        override fun calculateAfterPadding(
            layoutDirection: LayoutDirection,
            angularDirection: CurvedDirection.Angular,
        ) = calculateRightPadding(layoutDirection)

        override fun calculateBeforePadding(
            layoutDirection: LayoutDirection,
            angularDirection: CurvedDirection.Angular,
        ) = calculateLeftPadding(layoutDirection)
    }
