// Generated from AndroidX Wear Compose by tools/transform.py — DO NOT EDIT.
// Re-run scripts/regenerate.sh; make changes in transform-rules.json or patches/.
/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.wear.compose.foundation

import kotlin.jvm.JvmField

/**
 * This is a collection of flags which are used to guard against regressions in some of the
 * "riskier" refactors or new feature support that is added to this module. These flags are always
 * "on" in the published artifact of this module, however these flags allow end consumers of this
 * module to toggle them "off" in case this new path is causing a regression.
 *
 * These flags are considered temporary, and there should be no expectation for these flags being
 * around for an extended period of time. If you have a regression that one of these flags fixes, it
 * is strongly encouraged for you to file a bug ASAP.
 *
 * **Usage:**
 *
 * In order to turn a feature off in a debug environment, it is recommended to set this to false in
 * as close to the initial loading of the application as possible. Changing this value after compose
 * library code has already been loaded can result in undefined behavior.
 *
 *      class MyApplication : Application() {
 *          override fun onCreate() {
 *              WearComposeFoundationFlags.SomeFeatureEnabled = false
 *              super.onCreate()
 *          }
 *      }
 *
 * In order to turn this off in a release environment, it is recommended to additionally utilize R8
 * rules which force a single value for the entire build artifact. This can result in the new code
 * paths being completely removed from the artifact, which can often have nontrivial positive
 * performance impact.
 *
 *      -assumevalues class androidx.wear.compose.foundation.WearComposeFoundationFlags {
 *          public static boolean SomeFeatureEnabled return false
 *      }
 */
@ExperimentalWearFoundationApi
public object WearComposeFoundationFlags {
    /**
     * Whether to use the new clickability threshold in
     * [androidx.wear.compose.foundation.lazy.TransformingLazyColumn]. When true, the clickability
     * threshold ignores clicks in the top or bottom 20dp of the layout, to avoid accidental clicks
     * on small items that are partially shown due to fading/scaling in the TransformingLazyColumn.
     * If false, all clicks will be recognized instead
     */
    // TODO: b/485988796
    @field:Suppress("MutableBareField")
    @JvmField
    public var isTransformingLazyColumnClickableThresholdEnabled: Boolean = true

    /**
     * Whether to wrap items in [androidx.wear.compose.foundation.lazy.TransformingLazyColumn] with
     * a pinnable container. When true, items support pinning behavior (e.g. for focus). If false,
     * items will not be pinnable.
     */
    // TODO: b/533029222
    @field:Suppress("MutableBareField")
    @JvmField
    public var isTransformingLazyColumnPinnableContainerEnabled: Boolean = true

    /**
     * Whether to use warped curved text, true by default. Warping provides higher quality rendering
     * for curved text, specially for cursive fonts, but can have a slight performance impact for
     * big curved text.
     */
    // TODO: b/455602158
    @field:Suppress("MutableBareField")
    @JvmField
    public var isWarpingCurvedTextEnabled: Boolean = true
}
